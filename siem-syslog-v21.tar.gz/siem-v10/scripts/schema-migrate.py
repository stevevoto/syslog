#!/usr/bin/env python3
import json
import sqlite3
import sys
from pathlib import Path

cfg_path = Path(sys.argv[1] if len(sys.argv) > 1 else "/etc/siem-syslog/config.json")
db_path = Path("/var/lib/siem-syslog/events.db")

try:
    cfg = json.loads(cfg_path.read_text())
    db_path = Path(cfg.get("database", {}).get("path", str(db_path)))
except Exception:
    pass

db_path.parent.mkdir(parents=True, exist_ok=True)

conn = sqlite3.connect(str(db_path))
cur = conn.cursor()

cur.executescript("""
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  ts_epoch INTEGER NOT NULL,
  host TEXT NOT NULL DEFAULT 'unknown',
  source_ip TEXT NOT NULL DEFAULT '',
  facility TEXT NOT NULL DEFAULT 'user',
  severity TEXT NOT NULL DEFAULT 'INFO',
  sev_num INTEGER NOT NULL DEFAULT 6,
  program TEXT NOT NULL DEFAULT '',
  pid TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL DEFAULT '',
  country TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  lat REAL,
  lon REAL,
  tags TEXT NOT NULL DEFAULT '',
  raw TEXT NOT NULL DEFAULT '',
  ecs_category TEXT NOT NULL DEFAULT '',
  ecs_type TEXT NOT NULL DEFAULT '',
  ecs_outcome TEXT NOT NULL DEFAULT '',
  ecs_action TEXT NOT NULL DEFAULT '',
  user_name TEXT NOT NULL DEFAULT '',
  dest_ip TEXT NOT NULL DEFAULT '',
  dest_port INTEGER,
  protocol TEXT NOT NULL DEFAULT '',
  risk_score INTEGER NOT NULL DEFAULT 0,
  anomaly_score REAL DEFAULT 0,
  anomaly_flags TEXT NOT NULL DEFAULT '',
  ioc_match INTEGER NOT NULL DEFAULT 0,
  ioc_type TEXT NOT NULL DEFAULT '',
  ioc_value TEXT NOT NULL DEFAULT '',
  authentication TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS alerts (
  id TEXT PRIMARY KEY,
  ts TEXT NOT NULL,
  rule_name TEXT NOT NULL,
  severity TEXT NOT NULL,
  host TEXT NOT NULL,
  message TEXT NOT NULL,
  event_id INTEGER,
  notified INTEGER NOT NULL DEFAULT 0,
  risk_score INTEGER NOT NULL DEFAULT 0,
  mitre_id TEXT NOT NULL DEFAULT '',
  mitre_tactic TEXT NOT NULL DEFAULT '',
  case_id TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS stats_hourly (
  bucket_hour INTEGER PRIMARY KEY,
  total INTEGER NOT NULL DEFAULT 0,
  crit INTEGER NOT NULL DEFAULT 0,
  warn INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cases (
  id TEXT PRIMARY KEY,
  ts_created TEXT NOT NULL,
  ts_updated TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  priority TEXT NOT NULL DEFAULT 'medium',
  assignee TEXT NOT NULL DEFAULT '',
  external_ref TEXT NOT NULL DEFAULT '',
  external_system TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS admin_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  username TEXT NOT NULL DEFAULT '',
  actor TEXT NOT NULL DEFAULT '',
  target TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL DEFAULT '',
  object_type TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  result TEXT NOT NULL DEFAULT '',
  remote_ip TEXT NOT NULL DEFAULT ''
);
""")


# Create additional tables needed by SIEM features (idempotent)
cur.executescript("""
CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hostname TEXT NOT NULL DEFAULT '',
  ip_address TEXT NOT NULL DEFAULT '',
  asset_type TEXT NOT NULL DEFAULT 'server',
  owner TEXT NOT NULL DEFAULT '',
  business_unit TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  environment TEXT NOT NULL DEFAULT 'production',
  criticality INTEGER NOT NULL DEFAULT 5,
  os TEXT NOT NULL DEFAULT '',
  tags TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT '',
  raw_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS identities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL DEFAULT '',
  display_name TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT '',
  risk_score INTEGER NOT NULL DEFAULT 0,
  mfa_enabled INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS saved_searches (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  query TEXT NOT NULL DEFAULT '',
  filters TEXT NOT NULL DEFAULT '{}',
  description TEXT NOT NULL DEFAULT '',
  owner TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS agent_commands (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL DEFAULT '',
  command TEXT NOT NULL DEFAULT '',
  params TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT '',
  acked_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS webhook_dead_letter (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  webhook_id TEXT NOT NULL DEFAULT '',
  webhook_name TEXT NOT NULL DEFAULT '',
  payload TEXT NOT NULL DEFAULT '{}',
  failed_at TEXT NOT NULL DEFAULT '',
  attempts INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS analyst_history (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL DEFAULT '',
  messages TEXT NOT NULL DEFAULT '[]',
  ts TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS pipeline_stats (
  ts INTEGER PRIMARY KEY,
  processed INTEGER NOT NULL DEFAULT 0,
  dropped INTEGER NOT NULL DEFAULT 0,
  routed INTEGER NOT NULL DEFAULT 0,
  tagged INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS cmdb_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS cmdb_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  status TEXT NOT NULL DEFAULT '',
  imported INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  ts TEXT NOT NULL DEFAULT (datetime('now'))
);
""")


def table_exists(table: str) -> bool:
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
    return cur.fetchone() is not None

def ensure_column(table: str, name: str, decl: str) -> None:
    if not table_exists(table):
        return  # table does not exist yet — server will create it on first start
    cur.execute(f"PRAGMA table_info({table})")
    cols = {row[1] for row in cur.fetchall()}
    if name not in cols:
        try:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")
        except Exception as e:
            print(f"[WARN] Could not add {table}.{name}: {e}", flush=True)

ensure_column("events", "authentication", "TEXT NOT NULL DEFAULT ''")
ensure_column("admin_audit", "actor", "TEXT NOT NULL DEFAULT ''")
ensure_column("admin_audit", "target", "TEXT NOT NULL DEFAULT ''")
ensure_column("alerts", "risk_score", "INTEGER NOT NULL DEFAULT 0")
ensure_column("alerts", "mitre_id", "TEXT NOT NULL DEFAULT ''")
ensure_column("alerts", "mitre_tactic", "TEXT NOT NULL DEFAULT ''")
ensure_column("alerts", "case_id", "TEXT NOT NULL DEFAULT ''")
ensure_column("stats_hourly", "warn", "INTEGER NOT NULL DEFAULT 0")
ensure_column("cases", "external_ref", "TEXT NOT NULL DEFAULT ''")
ensure_column("cases", "external_system", "TEXT NOT NULL DEFAULT ''")

# assets table — full column set for CMDB sync (v1.4.7)
ensure_column("assets", "hostname",      "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "ip_address",    "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "asset_type",    "TEXT NOT NULL DEFAULT 'server'")
ensure_column("assets", "owner",         "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "business_unit", "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "department",    "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "environment",   "TEXT NOT NULL DEFAULT 'production'")
ensure_column("assets", "criticality",   "INTEGER NOT NULL DEFAULT 5")
ensure_column("assets", "os",            "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "tags",          "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "notes",         "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "source",        "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "raw_json",      "TEXT NOT NULL DEFAULT '{}'")
ensure_column("assets", "created_at",    "TEXT NOT NULL DEFAULT ''")
ensure_column("assets", "updated_at",    "TEXT NOT NULL DEFAULT ''")

# admin_audit status column
ensure_column("admin_audit", "status", "TEXT NOT NULL DEFAULT 'ok'")

cur.executescript("""
CREATE INDEX IF NOT EXISTS idx_ts ON events (ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_sev ON events (severity, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_host ON events (host, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_src_ip ON events (source_ip);
CREATE INDEX IF NOT EXISTS idx_risk ON events (risk_score DESC, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_user ON events (user_name, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_ioc ON events (ioc_match, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_alert_ts ON alerts (ts DESC);
CREATE INDEX IF NOT EXISTS idx_alert_case ON alerts (case_id);
""")

# Pipeline tagging column (added in v1.4.7)
ensure_column("events", "pipeline_tags", "TEXT NOT NULL DEFAULT ''")

# Cloud demo source tracking
ensure_column("events", "cloud_provider", "TEXT NOT NULL DEFAULT ''")
ensure_column("events", "cloud_source",   "TEXT NOT NULL DEFAULT ''")

# Identity enrichment columns
ensure_column("events", "user_department",   "TEXT NOT NULL DEFAULT ''")
ensure_column("events", "user_title",        "TEXT NOT NULL DEFAULT ''")
ensure_column("events", "user_role",         "TEXT NOT NULL DEFAULT ''")
ensure_column("events", "user_risk_score",   "INTEGER NOT NULL DEFAULT 0")
ensure_column("events", "user_mfa_enabled",  "INTEGER NOT NULL DEFAULT 0")
ensure_column("events", "identity_source",   "TEXT NOT NULL DEFAULT ''")


# Saved searches table (persistent)
cur.execute("""
  CREATE TABLE IF NOT EXISTS saved_searches (
    id         TEXT PRIMARY KEY,
    name       TEXT NOT NULL DEFAULT '',
    query      TEXT NOT NULL DEFAULT '',
    filters    TEXT NOT NULL DEFAULT '{}',
    description TEXT NOT NULL DEFAULT '',
    owner      TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  )
""")

# Agent commands queue (push commands to agents)
cur.execute("""
  CREATE TABLE IF NOT EXISTS agent_commands (
    id         TEXT PRIMARY KEY,
    agent_id   TEXT NOT NULL DEFAULT '',
    command    TEXT NOT NULL DEFAULT '',
    params     TEXT NOT NULL DEFAULT '{}',
    status     TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT '',
    acked_at   TEXT NOT NULL DEFAULT ''
  )
""")

# Webhook dead letter queue
cur.execute("""
  CREATE TABLE IF NOT EXISTS webhook_dead_letter (
    id          TEXT PRIMARY KEY,
    webhook_id  TEXT NOT NULL DEFAULT '',
    webhook_name TEXT NOT NULL DEFAULT '',
    payload     TEXT NOT NULL DEFAULT '{}',
    failed_at   TEXT NOT NULL DEFAULT '',
    attempts    INTEGER NOT NULL DEFAULT 0
  )
""")

# Alert ack expiry
ensure_column("alerts", "ack_expires_at", "TEXT NOT NULL DEFAULT ''")

conn.commit()
conn.close()
print(f"Schema migration OK: {db_path}")
