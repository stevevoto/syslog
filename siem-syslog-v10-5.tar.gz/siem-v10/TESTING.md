# SIEM Syslog Command Center v10.0.0 — Complete Test Reference

Copyright (c) 2026 svoto · MIT License (test infrastructure only)

---

## Quick Reference

```bash
# Fastest — 5 checks, ~10 seconds
siem-test smoke

# Standard — core features, ~60 seconds  
siem-test quick

# Full regression — all 83 checks, ~5 minutes
ADMIN_USER=admin ADMIN_PASS=<pass> siem-test full

# Everything — smoke + full + worm + corpus, ~20 minutes
ADMIN_USER=admin ADMIN_PASS=<pass> siem-test all
```

---

## Test Suites

### 1. Smoke Test (~10s)
**Command:** `siem-test smoke`  
**What it checks:**
- Service is running and reachable on port 18080
- `/api/health` returns `ok: true`
- Admin login succeeds
- Version matches `10.0.0`
- At least one syslog port is listening

```bash
siem-test smoke
siem-test smoke --host http://10.0.0.16 --port 18080
```

---

### 2. Quick Test (~60s)
**Command:** `siem-test quick`  
**What it checks:**
- All smoke checks
- UDP/TCP/TLS syslog ingest
- Event storage and retrieval
- Alerts API
- Case creation
- Backup list

```bash
siem-test quick
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test quick
```

---

### 3. Full Regression (~5 min)
**Command:** `siem-test full`  
**83 checks across 22 sections:**

| Section | Checks |
|---|---|
| 01 · Version consistency | package.json = 10.0.0, API version |
| 02 · Service & port health | :18080 TCP, :601 TCP, :6514 TCP, :514 UDP |
| 03 · Public health endpoint | /api/health (no auth) |
| 04 · Authentication + RBAC | Login, /me, bad password, analyst role, unauth |
| 05 · Syslog ingest UDP/TCP/TLS | Events stored, malformed frame stability |
| 06 · API inject & cloud ingest | Structured inject, cloud agentKey, bad key |
| 07 · CMDB sync | Configure, test, sync, asset import, inline |
| 08 · Stats, events, alerts, UEBA, MITRE | All analytics APIs |
| 09 · GeoIP enrichment | Geo clusters, event geolocation |
| 10 · Case management | Create, status update, close, list |
| 11 · Reports & exports | Compliance, CSV, NDJSON, PDF |
| 12 · Demo mode | Start, generates events, stop |
| 13 · Admin routes | Health, diagnostics, audit, version |
| 14 · Backup & restore | Trigger backup, list backups |
| 15 · v11 extensions | OCSF, Sigma, entity risk, assets |
| 16 · Threat intel / IOC | Add IOC, list IOCs |
| 17 · Notifications | Email+Slack settings |
| 18 · URL token auth | Token generate, tail access |
| 19 · Phase 12 foundations | Federated search, provenance, peer groups, GenAI, HA/DR |
| 20 · Session persistence | SQLite-backed sessions survive |
| 21 · Live reset & logout | Reset, logout, session invalidated |
| 22 · Destructive tests | SKIP (requires DESTRUCTIVE=true) |

```bash
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test full

# Save results to file
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test full --out /tmp/regress-results.json

# Stop on first failure
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test full --fail-fast
```

**Expected result:** `PASS: 82  FAIL: 0  SKIP: 1`

---

### 4. WORM Tamper Test
**Command:** `siem-test worm`  
**What it checks:**
- Injects a test event and seals it in the WORM chain
- Directly modifies the DB record (simulated tampering)
- Verifies the chain detects the modification
- Confirms tampered records are flagged in `/api/v2/worm/verify`

```bash
siem-test worm
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test worm

# Or run directly:
ADMIN_USER=admin ADMIN_PASS=128tRoutes bash tests/test-worm-tamper.sh
```

---

### 5. Golden Corpus Parser Test
**Command:** `siem-test corpus`  
**What it checks:**
- 14 vendor log formats parsed correctly
- Cisco ASA, Palo Alto, Fortinet, Windows Event, AWS CloudTrail
- Linux auth, nginx, Apache, Docker, Kubernetes, sshd
- Verifies correct field extraction (host, severity, message, timestamp)
- Regression guards against parser regressions

```bash
siem-test corpus
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test corpus

# Or directly:
ADMIN_USER=admin ADMIN_PASS=128tRoutes bash tests/test-golden-corpus.sh
```

---

### 6. HTTPS / TLS Test
**Command:** `siem-test https`  
**What it checks:**
- HTTPS dashboard reachable on :8443
- Self-signed cert present and valid structure
- TLS 1.2+ enforced
- HTTP→HTTPS redirect (if nginx configured)

```bash
siem-test https
siem-test https --host 10.0.0.16
```

---

### 7. API Surface Spot-check
**Command:** `siem-test api`  
**What it checks:**
- All documented API endpoints return expected status codes
- Auth-gated endpoints reject unauthenticated requests
- JSON response structure validation
- Rate limiter active

```bash
siem-test api
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test api
```

---

### 8. Feature Drill (Demo Data)
**Command:** `bash tests/test-feature-drill.sh`  
**What it does:**
- Injects realistic multi-vendor demo events
- Triggers CVE-2021-44228 (Log4Shell) and CVE-2023-23397 simulation
- Exercises all detection rules
- Validates UEBA anomaly generation
- Confirms MITRE ATT&CK technique mapping

```bash
ADMIN_USER=admin ADMIN_PASS=128tRoutes bash tests/test-feature-drill.sh
```

---

### 9. Browser UI E2E (Playwright)
**Command:** `bash tests/test-ui-e2e.sh`  
**Requires:** `npm install -g playwright @playwright/test && npx playwright install chromium`  
**What it checks:**
- Splash screen resolves within 6 seconds
- Login form appears and accepts credentials
- All 42 nav panels render without JS errors
- Feature test runner shows 38 green tests
- CVE intel panel loads
- Tail window opens

```bash
# Install playwright first (one time)
npm install -g playwright @playwright/test
npx playwright install chromium

# Run E2E tests
SIEM_URL=http://10.0.0.16:18080 \
ADMIN_USER=admin ADMIN_PASS=128tRoutes \
bash tests/test-ui-e2e.sh
```

---

### 10. In-Browser Feature Tests
**How:** Open browser → click **🧪 Tests** → click **Run All Tests**  
**38 independent tests covering:**

| Category | Tests |
|---|---|
| Core | Health, Auth, Events, Stats, Inject |
| Detection | Alerts, IOC, UEBA, MITRE |
| Enrichment | GeoIP, CMDB, CVE, Entity Risk |
| Normalization | OCSF, Sigma |
| Operations | Cases, Reports, Compliance, Backup, Diagnostics, Pipeline |
| Integrations | Webhooks, Log Forwarding, Notifications, Cloud |
| AI | GenAI Analyst |
| Identity | LDAP, OIDC, MFA, Session |
| Compliance | WORM |
| Response | Playbooks, SOAR |
| Collection | Agents |
| Infrastructure | HTTPS, Network, OpenAPI, Storage, URL Tokens |

Each card turns **green** (pass) or **red** (fail) with a status message.

---

### 11. Destructive Tests
**Command:** `DESTRUCTIVE=true siem-test full`  
**⚠ WARNING: Wipes runtime data. Do not run on production.**

```bash
# Only on a test/dev instance!
DESTRUCTIVE=true ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test full
```

---

### 12. Upgrade Test
**Command:** `bash tests/test-upgrade.sh`  
**What it checks:**
- Install from tarball
- Verify version
- Run smoke test
- Upgrade to new version
- Verify data preserved
- Run smoke test again

```bash
bash tests/test-upgrade.sh --from-pkg siem-syslog-10.0.0.tar.gz
```

---

## Manual API Tests

```bash
# Health (public, no auth)
curl http://localhost:18080/api/health

# Version (public, no auth)
curl http://localhost:18080/api/version

# Login
curl -c /tmp/c.txt -X POST http://localhost:18080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"128tRoutes"}'

# Inject a syslog event
curl -b /tmp/c.txt -X POST http://localhost:18080/api/inject \
  -H 'Content-Type: application/json' \
  -d '{"host":"test-host","severity":"CRIT","message":"CVE-2021-44228 exploit attempt"}'

# Query events
curl -b /tmp/c.txt 'http://localhost:18080/api/events?limit=10'

# Get threat intel
curl -b /tmp/c.txt http://localhost:18080/api/threatintel

# Check CVE feed
curl -b /tmp/c.txt http://localhost:18080/api/cve/feed/status

# Machine ID (for licensing)
curl -b /tmp/c.txt http://localhost:18080/api/admin/license/machine-id

# License status
curl -b /tmp/c.txt http://localhost:18080/api/admin/license

# Run backup
curl -b /tmp/c.txt -X POST http://localhost:18080/api/admin/backup/run \
  -H 'Content-Type: application/json' -d '{}'

# OCSF mapping test  
curl -b /tmp/c.txt -X POST http://localhost:18080/api/admin/ocsf/map-sample \
  -H 'Content-Type: application/json' \
  -d '{"message":"Failed password for root from 185.220.101.45","severity":"CRIT"}'
```

---

## Syslog Send Tests

```bash
# UDP syslog
logger -n 127.0.0.1 -P 514 --udp "sshd: Failed password for root from 185.220.101.45 port 22"

# TCP syslog
echo "<130>1 $(date -u +%Y-%m-%dT%H:%M:%SZ) my-server sshd - - Failed password for admin" | \
  nc -w2 127.0.0.1 601

# TLS syslog
echo "<130>1 $(date -u +%Y-%m-%dT%H:%M:%SZ) my-server sshd - - CVE-2021-44228 exploit" | \
  timeout 4 openssl s_client -connect 127.0.0.1:6514 -quiet -ign_eof 2>/dev/null

# Cloud agent ingest
curl -X POST http://localhost:18080/api/ingest/cloud \
  -H 'Content-Type: application/json' \
  -H "X-Agent-Key: $(python3 -c "import json; print(json.load(open('/etc/siem-syslog/config.json')).get('phase2',{}).get('agentSharedKey',''))")" \
  -d '{"events":[{"host":"cloud-server","severity":"WARN","message":"unusual login from new country"}]}'
```

---

## Performance Tests

```bash
# Load test: 1000 events via API inject
for i in $(seq 1 1000); do
  curl -s -b /tmp/c.txt -X POST http://localhost:18080/api/inject \
    -H 'Content-Type: application/json' \
    -d "{\"host\":\"load-test-$i\",\"severity\":\"INFO\",\"message\":\"load test event $i\"}" \
    > /dev/null &
  [[ $((i % 50)) -eq 0 ]] && wait
done
wait
echo "Done. Check: curl -b /tmp/c.txt 'http://localhost:18080/api/stats'"

# Sustained syslog flood (use carefully)
# seq 1 500 | xargs -P10 -I{} logger -n 127.0.0.1 -P 514 --udp "perf-test event {}"
```

---

## Service Health Commands

```bash
# Service status
systemctl status siem-syslog

# Live logs
journalctl -u siem-syslog -f

# Last 50 log lines
journalctl -u siem-syslog -n 50 --no-pager

# Port check
ss -tlnp | grep -E '18080|8443|601|6514'
ss -ulnp | grep 514

# Database size
du -sh /var/lib/siem-syslog/siem.db

# Backup disk usage
du -sh /var/backups/siem-syslog/

# Restart
sudo systemctl restart siem-syslog
```

---

## Run Everything

```bash
# Complete test suite (run as: admin / your_password)
ADMIN_USER=admin ADMIN_PASS=128tRoutes siem-test all
```

This runs in order: **smoke → full regression → WORM tamper → parser corpus → HTTPS check**  
Total time: ~20 minutes. All results saved to `artifacts/regress/`.
