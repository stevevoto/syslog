# SIEM Syslog Command Center v10.0.0

**Enterprise-grade Security Information and Event Management**

> Copyright (c) 2026 svoto  
> License: MIT — see [LICENSE](LICENSE)

---

## Features

- **Syslog Ingest** — UDP :514, TCP :601, TLS :6514 (RFC 3164/5424/5425)
- **Threat Detection** — Correlation rules, IOC matching, UEBA, MITRE ATT&CK
- **Enrichment** — GeoIP, CVE intelligence (NVD feed), entity risk scoring, CMDB
- **Normalization** — OCSF mapping, Sigma rule engine, ECS fields
- **Compliance** — SOC2, ISO 27001, NIS2, DORA, HIPAA, PCI-DSS, GDPR
- **Case Management** — Create, assign, track, export security incidents
- **Identity** — Local auth, LDAP/AD, OIDC/Okta, SAML SSO, MFA/TOTP, WebAuthn
- **Response** — Playbook engine, SOAR actions, webhook notifications
- **AI** — GenAI analyst assistant (requires Anthropic API key)
- **API** — Full REST API, WebSocket live stream, SSE tail, OpenAPI/Swagger docs

## Quick Start

```bash
tar xzf siem-syslog-10.0.0.tar.gz
cd siem-v10
sudo bash install.sh
```

Then open `http://<server-ip>:18080` in your browser.

## Running Regression Tests

```bash
# Auto-detect credentials from install summary
siem-test full

# Or pass explicitly
ADMIN_USER=admin ADMIN_PASS=<password> siem-test full
```

Expected result: **82 PASS, 0 FAIL, 1 SKIP** (destructive tests skipped by default).

## Architecture

```
┌─────────────────────────────────────────────┐
│            Browser Dashboard                 │
│  42 config panels · 38 feature tests        │
└────────────────┬────────────────────────────┘
                 │ HTTP/WebSocket/SSE
┌────────────────▼────────────────────────────┐
│         server-v3.js (Node.js)              │
│  Express · better-sqlite3 · WAL mode        │
│  Rate limiting · gzip · Security headers    │
└──┬──────────┬──────────┬───────────────────┘
   │          │          │
 UDP:514  TCP:601  TLS:6514   ← Syslog ingest
```

## Ports

| Port  | Protocol | Purpose           |
|-------|----------|-------------------|
| 18080 | HTTP     | Dashboard & API   |
| 8443  | HTTPS    | TLS dashboard     |
| 514   | UDP      | Syslog RFC 3164   |
| 601   | TCP      | Syslog RFC 5424   |
| 6514  | TLS      | Syslog RFC 5425   |

## License

MIT — see [LICENSE](LICENSE) for full terms.

Copyright (c) 2026 svoto
