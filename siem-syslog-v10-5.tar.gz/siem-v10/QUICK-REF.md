# SIEM Syslog Command Center v10.0.0 — Quick Reference Card
**Copyright (c) 2026 svoto · MIT License (test tools) · Proprietary (core engine)**

---

## 🚀 Install

| Platform | Command |
|---|---|
| **Linux**   | `sudo bash install.sh` |
| **macOS**   | Double-click **siem-syslog-10.0.0-macos.dmg** → drag to Applications → run **Install SIEM.command** |
| **Windows** | Right-click **siem-syslog-10.0.0-setup.exe** → Run as Administrator |

**Default dashboard:** `http://<server-ip>:18080`  
**Default credentials:** Set during install (check `/var/log/siem-syslog/install-summary.txt`)

---

## 🔨 Build

```bash
# All platforms — binaries + installers
bash build-protected.sh

# Linux only (from source)
cd app && node server-v3.js

# macOS DMG (run on a Mac)
bash packaging/macos/build-dmg.sh

# Windows .exe (requires NSIS)
makensis packaging/windows/siem-installer.nsi

# .deb / .rpm package
bash packaging/build-native-packages.sh [deb|rpm|auto]
```

**Build outputs:**
```
dist/binaries/
  siem-server-10.0.0-linux-x64        # Linux x64 binary
  siem-server-10.0.0-linux-arm64      # Linux ARM64 (Pi, cloud)
  siem-server-10.0.0-macos-x64        # Intel Mac
  siem-server-10.0.0-macos-arm64      # Apple Silicon
  siem-server-10.0.0-windows-x64.exe  # Windows binary
dist/
  siem-syslog-10.0.0-setup.exe        # Windows installer (NSIS)
  siem-syslog-10.0.0-macos.dmg        # macOS disk image
  siem-syslog-10.0.0.deb              # Debian/Ubuntu package
  siem-syslog-10.0.0.rpm              # RHEL/Rocky/Fedora package
```

---

## 🧪 Tests

### One-liners
```bash
siem-test smoke                                              # 5 checks, ~10s
siem-test quick                                              # core checks, ~60s
ADMIN_USER=admin ADMIN_PASS=<pw> siem-test full             # 83 checks, ~5min
ADMIN_USER=admin ADMIN_PASS=<pw> siem-test worm             # tamper detection
ADMIN_USER=admin ADMIN_PASS=<pw> siem-test corpus           # 14-vendor parser test
siem-test https                                              # TLS check
ADMIN_USER=admin ADMIN_PASS=<pw> siem-test api              # API surface check
ADMIN_USER=admin ADMIN_PASS=<pw> siem-test all              # everything, ~20min
```

### Browser tests
```
http://<server>:18080  → click 🧪 Tests → Run All Tests
```
38 feature tests, each card goes green/red live.

### Direct test scripts
```bash
bash tests/test-smoke.sh
bash tests/test-worm-tamper.sh
bash tests/test-golden-corpus.sh
bash tests/test-feature-drill.sh
bash tests/test-ui-e2e.sh            # requires: npm i -g playwright
DESTRUCTIVE=true bash tests/test-destructive.sh   # ⚠ wipes data
```

### Save results
```bash
ADMIN_USER=admin ADMIN_PASS=<pw> siem-test full --out results.json
```

---

## 📡 Send Syslog

```bash
# UDP
logger -n <server-ip> -P 514 --udp "sshd: Failed password for root"

# TCP
echo "<130>1 $(date -u +%Y-%m-%dT%H:%M:%SZ) myhost sshd - - test" | nc -w2 <server> 601

# TLS
echo "<130>1 $(date -u +%Y-%m-%dT%H:%M:%SZ) myhost sshd - - test" | \
  timeout 4 openssl s_client -connect <server>:6514 -quiet -ign_eof 2>/dev/null

# API inject (curl)
curl -b /tmp/c.txt -X POST http://<server>:18080/api/inject \
  -H 'Content-Type: application/json' \
  -d '{"host":"myhost","severity":"CRIT","message":"CVE-2021-44228 exploit attempt"}'

# Cloud agent ingest
curl -X POST http://<server>:18080/api/ingest/cloud \
  -H 'Content-Type: application/json' \
  -H "X-Agent-Key: <agentSharedKey>" \
  -d '{"events":[{"host":"cloud-srv","severity":"WARN","message":"anomaly detected"}]}'
```

---

## 🔑 Auth & License

```bash
# Login (saves session cookie)
curl -c /tmp/c.txt -X POST http://<server>:18080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"<pw>"}'

# Get machine ID (for license key request)
curl -b /tmp/c.txt http://<server>:18080/api/admin/license/machine-id

# Check license status
curl -b /tmp/c.txt http://<server>:18080/api/admin/license

# Activate license key
curl -b /tmp/c.txt -X POST http://<server>:18080/api/admin/license/activate \
  -H 'Content-Type: application/json' \
  -d '{"key":"<license-key-line1>\n<signature-line2>"}'
```

---

## 🛠 Service Management

```bash
# Linux
sudo systemctl start|stop|restart|status siem-syslog
journalctl -u siem-syslog -f                          # live logs
journalctl -u siem-syslog -n 50 --no-pager           # last 50 lines

# macOS
sudo launchctl start|stop com.svoto.siem-syslog
tail -f "/Library/Logs/siem-syslog/siem.log"

# Windows (PowerShell as Admin)
Start-Service SIEMSyslog
Stop-Service  SIEMSyslog
Get-Service   SIEMSyslog
Get-Content "$env:APPDATA\siem-syslog\logs\siem.log" -Wait   # live logs
```

---

## 🔍 Health Checks

```bash
# Service alive?
curl http://localhost:18080/api/health

# Version?
curl http://localhost:18080/api/version

# Ports listening?
ss -tlnp | grep -E '18080|8443|601|6514'    # Linux/macOS
netstat -ano | findstr "18080 601 6514"      # Windows

# Database size
du -sh /var/lib/siem-syslog/siem.db          # Linux
```

---

## 📋 Ports

| Port | Protocol | Purpose |
|---|---|---|
| **18080** | TCP | Dashboard & REST API |
| **8443** | TCP | Dashboard HTTPS |
| **514** | UDP | Syslog RFC 3164 (legacy) |
| **601** | TCP | Syslog RFC 5424 |
| **6514** | TCP/TLS | Syslog RFC 5425 (encrypted) |

---

## 📁 Key Paths

| | Linux | macOS | Windows |
|---|---|---|---|
| Config | `/etc/siem-syslog/` | `/Library/Application Support/siem-syslog/config/` | `%APPDATA%\siem-syslog\config\` |
| Data/DB | `/var/lib/siem-syslog/` | `…/data/` | `%APPDATA%\siem-syslog\data\` |
| Logs | `/var/log/siem-syslog/` | `/Library/Logs/siem-syslog/` | `%APPDATA%\siem-syslog\logs\` |
| Backups | `/var/backups/siem-syslog/` | `…/backups/` | `%APPDATA%\siem-syslog\backups\` |
| License | `/etc/siem-syslog/license.key` | `…/config/license.key` | `%APPDATA%\siem-syslog\config\license.key` |
| Install summary | `/var/log/siem-syslog/install-summary.txt` | `/Library/Logs/siem-syslog/install-summary.txt` | `%APPDATA%\siem-syslog\logs\install-summary.txt` |

---

## 🆘 Troubleshooting

```bash
# Splash screen stuck?
# → Check server is running: curl http://localhost:18080/api/health

# Login not working?
# → Check credentials in install summary
cat /var/log/siem-syslog/install-summary.txt

# Port conflict?
ss -tlnp | grep -E '18080|601|514|6514'
# Change port: edit /etc/siem-syslog/config.json → "httpPort": 18081

# Reset admin password
node /opt/siem-syslog/add-admin.js <newpassword>
# or:
sudo siem-syslog-add-admin <newpassword>

# Full reinstall (preserves data)
sudo bash install.sh --upgrade
```

---
*Full test docs: see TESTING.md · Full API: http://localhost:18080/api/docs*
