# Proprietary Source Code Notice

**SIEM Syslog Command Center v10.0.0**  
Copyright (c) 2026 svoto — All Rights Reserved

---

## What is open source (MIT License)

The following components are released under the MIT License:

| Component | License |
|---|---|
| Install script (`install.sh`) | MIT |
| Regression test runner (`siem-test`) | MIT |
| Test suite (`tests/test-all-regress.sh`) | MIT |
| `scripts/schema-migrate.py` | MIT |
| `README.md`, `NOTICE` | MIT |
| CVE intelligence module (`lib/cve-intel.js`) | MIT |

## What is NOT open source (Proprietary)

The following core components are **proprietary** and protected:

| Component | Protection |
|---|---|
| `app/server-v3.js` | Compiled to V8 bytecode (`.jsc`) in distribution |
| `app/lib/v11-extensions.js` | Compiled / obfuscated |
| `app/lib/sigma-engine.js` | Compiled / obfuscated |
| `app/lib/entity-risk.js` | Compiled / obfuscated |
| `app/lib/playbook-engine.js` | Compiled / obfuscated |
| `app/lib/worm-chain.js` | Compiled / obfuscated |
| `app/lib/event-parser.js` | Compiled / obfuscated |
| `app/lib/license.js` | Compiled / obfuscated |
| `app/public/index.html` (JS) | Obfuscated in distribution |

## Distribution Policy

- You may **install and run** this software on licensed servers
- You may **NOT** redistribute, resell, or sublicense without written permission
- You may **NOT** reverse-engineer, decompile, or extract source code
- You may **NOT** remove or alter copyright notices

## License Keys

Each installation requires a valid license key tied to the machine's hardware fingerprint.

- **Trial:** 30 days, no key required
- **Standard:** Annual subscription, 1 server
- **Enterprise:** Perpetual or annual, unlimited servers

To obtain a license key:
1. Run `siem-test smoke` to get your Machine ID
2. Contact svoto with your Machine ID and desired tier

## Third-Party Components

Third-party open-source components (listed in `NOTICE`) retain their respective licenses and are not affected by this proprietary notice.
