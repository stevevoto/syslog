#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/opt/siem-syslog}"
APP_USER="${APP_USER:-siem-syslog}"
APP_GROUP="${APP_GROUP:-siem-syslog}"
BUNDLE_DIR="${BUNDLE_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SYNC_DELETE="${SYNC_DELETE:-true}"
if [[ ${EUID} -ne 0 ]]; then echo "Run as root."; exit 1; fi
mkdir -p "$APP_DIR" "$APP_DIR/public" "$APP_DIR/lib" "$APP_DIR/tests" "$APP_DIR/scripts" "$APP_DIR/docs" "$APP_DIR/compliance" "$APP_DIR/LICENSES" "$APP_DIR/extras"
# best-effort group/user presence
getent group "$APP_GROUP" >/dev/null 2>&1 || true
id -u "$APP_USER" >/dev/null 2>&1 || true
sync_dir() {
  local src="$1" dst="$2"
  [[ -d "$src" ]] || return 0
  if command -v rsync >/dev/null 2>&1; then
    local delargs=()
    [[ "$SYNC_DELETE" == "true" ]] && delargs+=(--delete)
    rsync -a "${delargs[@]}" "$src/" "$dst/"
  else
    mkdir -p "$dst"
    cp -a "$src/." "$dst/"
  fi
}
sync_file() {
  local src="$1" dst="$2" mode="${3:-0644}"
  [[ -f "$src" ]] || return 0
  install -D -m "$mode" "$src" "$dst"
}
# map bundle -> live layout
sync_dir  "$BUNDLE_DIR/app/public" "$APP_DIR/public"
sync_dir  "$BUNDLE_DIR/app/lib"    "$APP_DIR/lib"
sync_dir  "$BUNDLE_DIR/tests"      "$APP_DIR/tests"
sync_dir  "$BUNDLE_DIR/scripts"    "$APP_DIR/scripts"
sync_dir  "$BUNDLE_DIR/docs"       "$APP_DIR/docs"
sync_dir  "$BUNDLE_DIR/compliance" "$APP_DIR/compliance"
sync_dir  "$BUNDLE_DIR/LICENSES"   "$APP_DIR/LICENSES"
sync_dir  "$BUNDLE_DIR/extras"     "$APP_DIR/extras"
sync_file "$BUNDLE_DIR/app/server-v3.js"      "$APP_DIR/server-v3.js" 0755
sync_file "$BUNDLE_DIR/app/dashboard-v3.html" "$APP_DIR/dashboard-v3.html" 0644
sync_file "$BUNDLE_DIR/app/package.json"      "$APP_DIR/package.json" 0644
sync_file "$BUNDLE_DIR/app/add-admin.js"      "$APP_DIR/add-admin.js" 0755
sync_file "$BUNDLE_DIR/app/public/tail.html"  "$APP_DIR/public/tail.html" 0644
sync_file "$BUNDLE_DIR/app/openapi.yaml"      "$APP_DIR/openapi.yaml" 0644
sync_file "$BUNDLE_DIR/wipe-data.sh"          "$APP_DIR/wipe-data.sh" 0755
sync_file "$BUNDLE_DIR/siem-test"              "$APP_DIR/siem-test" 0755
sync_dir  "$BUNDLE_DIR/windows"               "$APP_DIR/windows"
for f in README.md README_DOWNLOAD_FIRST.md README_DOWNLOAD_FIRST.md.legacy ENTERPRISE_PORT_PROFILES.md ENTERPRISE_PORTS.md PROPRIETARY_NOTICE.md OPEN_SOURCE_COMPLIANCE.md COMPLIANCE_RELEASE_GUIDE.md COMMERCIAL_SCOPE.md ENTERPRISE_IMPLEMENTATION_MATRIX.md CVE_HANDLING.md RAW_LOGGING_SERVER.md GA_SIGNOFF_v1.4.7.md RELEASE_NOTES_v1.4.7-fixed.md FIXES_APPLIED_v10.md INSTALL_NOTES_v10.txt HOTFIX_NOTES_v10.1.txt ; do
  sync_file "$BUNDLE_DIR/$f" "$APP_DIR/$f" 0644
done
if command -v chown >/dev/null 2>&1 && getent passwd "$APP_USER" >/dev/null 2>&1 && getent group "$APP_GROUP" >/dev/null 2>&1; then
  chown -R "$APP_USER:$APP_GROUP" "$APP_DIR" || true
fi
chmod 755 "$APP_DIR/tests/test-all-regress.sh" "$APP_DIR/scripts/run-post-install-validation.sh" \
  "$APP_DIR/wipe-data.sh" "$APP_DIR/siem-test" \
  "$APP_DIR/scripts/release-gate.sh" 2>/dev/null || true
[[ -f "/usr/local/bin/siem-test" ]] || { [[ -f "$APP_DIR/siem-test" ]] && ln -sf "$APP_DIR/siem-test" /usr/local/bin/siem-test 2>/dev/null || true; }
echo "Synced bundle from $BUNDLE_DIR into $APP_DIR"
