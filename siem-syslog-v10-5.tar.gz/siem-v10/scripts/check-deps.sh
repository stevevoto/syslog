#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  SIEM Syslog Command Center v10.0.0 — Dependency Pre-flight Checker
#  Run before install or build to verify all OS dependencies are present
#  Works on: Linux (Debian/Ubuntu/RHEL), macOS, Windows (Git Bash/WSL)
#  Copyright (c) 2026 svoto — MIT License
# ═══════════════════════════════════════════════════════════════════════
set -euo pipefail

PLATFORM="$(uname -s)"
ARCH="$(uname -m)"
PASS=0; FAIL=0; WARN=0
declare -a MISSING=()
declare -a OPTIONAL_MISSING=()

ok()   { echo "  ✓ $*"; PASS=$((PASS+1)); }
fail() { echo "  ✗ $*"; FAIL=$((FAIL+1)); MISSING+=("$*"); }
warn() { echo "  ⚠ $*"; WARN=$((WARN+1)); OPTIONAL_MISSING+=("$*"); }
chk()  { command -v "$1" >/dev/null 2>&1; }

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   SIEM v10.0.0 — Dependency Pre-flight Checker          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo "  Platform: $PLATFORM | Arch: $ARCH"
echo ""

# ── Universal checks (all platforms) ─────────────────────────────────
echo "── Universal ───────────────────────────────────────────────────"

# Node.js
if chk node; then
  NODE_MAJ=$(node -v 2>/dev/null | sed 's/^v//' | cut -d. -f1)
  if [[ "${NODE_MAJ:-0}" -ge 18 ]]; then
    ok "Node.js $(node -v) (≥18 required)"
  else
    fail "Node.js $(node -v) is too old — need v18 or newer. Install: nodejs.org"
  fi
else
  fail "Node.js not found — install from nodejs.org or use nvm"
fi

# npm
chk npm && ok "npm $(npm -v)" || fail "npm not found (install with Node.js)"

# Python 3 (for node-gyp / better-sqlite3 native build)
if chk python3; then
  PY_VER=$(python3 --version 2>&1 | awk '{print $2}')
  ok "Python 3 $PY_VER"
elif chk python; then
  PY_VER=$(python --version 2>&1 | awk '{print $2}')
  [[ "$PY_VER" == 3* ]] && ok "Python 3 $PY_VER" || fail "Python 2 found — need Python 3"
else
  fail "Python 3 not found — needed by node-gyp for native module compilation"
fi

# OpenSSL
if chk openssl; then
  ok "openssl $(openssl version | awk '{print $2}')"
else
  fail "openssl not found — required for TLS certificate generation"
fi

# curl
chk curl && ok "curl $(curl --version | head -1 | awk '{print $2}')" || \
  fail "curl not found — required for downloads and health checks"

# ── Linux-specific ────────────────────────────────────────────────────
if [[ "$PLATFORM" == "Linux" ]]; then
  echo ""
  echo "── Linux ───────────────────────────────────────────────────────"

  # C compiler (for better-sqlite3 native build)
  chk gcc && ok "gcc $(gcc --version | head -1 | awk '{print $3}')" || \
    fail "gcc not found — run: sudo apt install build-essential  OR  sudo dnf install gcc gcc-c++ make"

  chk g++ && ok "g++" || \
    fail "g++ not found — run: sudo apt install g++  OR  sudo dnf install gcc-c++"

  chk make && ok "make $(make --version | head -1 | awk '{print $3}')" || \
    fail "make not found — run: sudo apt install build-essential  OR  sudo dnf install make"

  # setcap (for binding port 514 without root)
  if chk setcap; then
    ok "setcap (libcap2-bin) — enables binding port 514 without running as root"
  else
    warn "setcap not found — SIEM will need to run as root OR use port >1024 for syslog UDP"
    warn "  Fix: sudo apt install libcap2-bin  OR  sudo dnf install libcap"
  fi

  # systemd
  if chk systemctl; then
    ok "systemd (systemctl)"
  else
    warn "systemd not found — service management will use init.d / manual start"
  fi

  # nginx (optional reverse proxy)
  if chk nginx; then
    ok "nginx $(nginx -v 2>&1 | awk -F/ '{print $2}')"
  else
    warn "nginx not installed — SIEM will serve HTTP directly (no TLS termination at nginx level)"
    warn "  Install: sudo apt install nginx  OR  sudo dnf install nginx"
  fi

  # ca-certificates
  if [[ -d /etc/ssl/certs && -n "$(ls /etc/ssl/certs/*.pem 2>/dev/null | head -1)" ]]; then
    ok "CA certificates present (/etc/ssl/certs/)"
  else
    warn "CA certificates may be missing — run: sudo apt install ca-certificates"
  fi

  # Firewall
  if chk ufw; then
    ok "ufw firewall"
  elif chk firewall-cmd; then
    ok "firewalld"
  elif chk iptables; then
    ok "iptables"
  else
    warn "No firewall tool detected — ensure ports 514/UDP 601/TCP 6514/TCP 18080/TCP are accessible"
  fi

  # Package manager
  if chk apt-get; then
    ok "apt-get (Debian/Ubuntu)"
  elif chk dnf; then
    ok "dnf (RHEL/Rocky/Fedora)"
  elif chk yum; then
    ok "yum (CentOS/older RHEL)"
  else
    warn "No recognised package manager — manual dependency installation required"
  fi

  # Architecture
  if [[ "$ARCH" == "x86_64" || "$ARCH" == "aarch64" ]]; then
    ok "Architecture: $ARCH (supported)"
  else
    warn "Architecture: $ARCH — untested, may require source build"
  fi
fi

# ── macOS-specific ────────────────────────────────────────────────────
if [[ "$PLATFORM" == "Darwin" ]]; then
  echo ""
  echo "── macOS ───────────────────────────────────────────────────────"

  # Xcode CLI tools
  if xcode-select -p &>/dev/null; then
    ok "Xcode CLI tools ($(xcode-select -p))"
  else
    fail "Xcode CLI tools not installed — run: xcode-select --install"
  fi

  # Architecture
  if [[ "$ARCH" == "arm64" ]]; then
    ok "Apple Silicon (M1/M2/M3) — native ARM64 binary available"
  elif [[ "$ARCH" == "x86_64" ]]; then
    ok "Intel Mac — x64 binary available"
    # Check if Rosetta 2 is installed (for running ARM64 builds if needed)
    if /usr/bin/pgrep -q oahd 2>/dev/null; then
      ok "Rosetta 2 installed"
    else
      warn "Rosetta 2 not installed — only native x64 binary will work"
      warn "  Install: softwareupdate --install-rosetta --agree-to-license"
    fi
  fi

  # macOS version
  MAC_VER=$(sw_vers -productVersion 2>/dev/null || echo "unknown")
  MAC_MAJ=$(echo "$MAC_VER" | cut -d. -f1)
  if [[ "${MAC_MAJ:-0}" -ge 11 ]]; then
    ok "macOS $MAC_VER (≥11 required)"
  else
    fail "macOS $MAC_VER is too old — need macOS 11 Big Sur or newer"
  fi

  # codesign
  chk codesign && ok "codesign (code signing available)" || \
    warn "codesign not found — install Xcode CLI tools"

  # create-dmg (optional)
  if chk create-dmg; then
    ok "create-dmg (styled DMG builds available)"
  else
    warn "create-dmg not installed — plain DMG will be used"
    warn "  Install: brew install create-dmg"
  fi

  # Homebrew (optional but useful)
  if chk brew; then
    ok "Homebrew $(brew --version | head -1 | awk '{print $2}')"
  else
    warn "Homebrew not installed — optional but recommended for dev tools"
    warn "  Install: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
  fi

  # Port 514 requires root on macOS (ports <1024)
  if [[ "$(id -u)" -eq 0 ]]; then
    ok "Running as root — low port (514) binding allowed"
  else
    warn "Not root — port 514 (UDP syslog) requires sudo or port forwarding"
    warn "  The launchd service installs as root and handles this automatically"
  fi
fi

# ── Windows (Git Bash / WSL detection) ───────────────────────────────
if [[ "$PLATFORM" == "MINGW"* || "$PLATFORM" == "CYGWIN"* ]] || grep -qi microsoft /proc/version 2>/dev/null; then
  echo ""
  echo "── Windows (Git Bash / WSL) ────────────────────────────────────"

  if grep -qi microsoft /proc/version 2>/dev/null; then
    ok "Running in WSL (Windows Subsystem for Linux)"
    warn "For native Windows service install, use the .exe installer instead"
  fi

  # NSIS for building .exe installer
  chk makensis && ok "NSIS (makensis) — can build Windows .exe installer" || \
    warn "NSIS not installed — cannot build .exe installer from this host"
    
  warn "VC++ 2022 Redistributable: verify manually in Windows Add/Remove Programs"
  warn "Windows Firewall: .exe installer configures this automatically via netsh"
fi

# ── npm package check (runs on any platform) ─────────────────────────
echo ""
echo "── npm Packages ────────────────────────────────────────────────"
if chk npm && [[ -d "$( cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/app/node_modules" ]]; then
  APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/app"
  # Check each runtime dependency
  for pkg in express better-sqlite3 ws compression geoip-lite pdfkit nodemailer; do
    if [[ -d "$APP_DIR/node_modules/$pkg" ]]; then
      VER=$(node -e "try{console.log(require('$APP_DIR/node_modules/$pkg/package.json').version)}catch(e){console.log('?')}" 2>/dev/null)
      ok "$pkg@$VER"
    else
      fail "$pkg not installed — run: cd app && npm install"
    fi
  done
else
  warn "node_modules not found — run: cd app && npm install"
fi

# ── Build tools (for binary compilation) ─────────────────────────────
echo ""
echo "── Build Tools (for binary compilation) ────────────────────────"
SIEM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

chk bytenode || \
  warn "bytenode not installed — JS→bytecode compilation unavailable (build-protected.sh installs it)"

PKG_BIN="$SIEM_DIR/app/node_modules/.bin/pkg"
[[ -x "$PKG_BIN" ]] && ok "pkg (@yao-pkg/pkg) — binary bundler ready" || \
  warn "pkg not installed — binary builds unavailable (build-protected.sh installs it)"

chk makensis && ok "NSIS makensis — Windows .exe builder ready" || \
  warn "NSIS not installed — Windows .exe installer cannot be built"

if [[ "$PLATFORM" == "Darwin" ]]; then
  chk create-dmg && ok "create-dmg — styled macOS DMG ready" || \
    warn "create-dmg not installed: brew install create-dmg"
fi

# ── Summary ───────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════════"
echo "  PASS: $PASS  FAIL: $FAIL  WARN: $WARN"
echo ""
if [[ $FAIL -eq 0 ]]; then
  echo "  ✓ All required dependencies present"
  if [[ $WARN -gt 0 ]]; then
    echo "  ⚠ $WARN optional items missing (see warnings above)"
  fi
else
  echo "  ✗ $FAIL required dependencies missing:"
  for m in "${MISSING[@]}"; do echo "    - $m"; done
  echo ""
  echo "  Install missing deps and re-run this script."
fi
echo "════════════════════════════════════════════════════════════"
echo ""
[[ $FAIL -eq 0 ]]   # exit 1 if any required dep missing
