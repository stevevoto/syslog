#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  SIEM Syslog Command Center v10.0.0 — macOS DMG Builder
#  Produces: siem-syslog-10.0.0-macos.dmg
#  Requires: macOS build host with Xcode CLI tools
#  Copyright (c) 2026 svoto — PROPRIETARY
# ═══════════════════════════════════════════════════════════════════════
set -euo pipefail

VERSION="10.0.0"
APP_NAME="SIEM Syslog Command Center"
BUNDLE_ID="com.svoto.siem-syslog"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
DIST_DIR="$ROOT_DIR/dist"
DMG_DIR="$DIST_DIR/dmg-staging"
DMG_OUT="$DIST_DIR/siem-syslog-${VERSION}-macos.dmg"
APP_BUNDLE="$DMG_DIR/${APP_NAME}.app"

mkdir -p "$DMG_DIR"

echo "═══════════════════════════════════════════════════════"
echo "  Building macOS DMG for SIEM v${VERSION}"
echo "═══════════════════════════════════════════════════════"

# ── Step 1: Create .app bundle structure ─────────────────────────────
echo "[1/5] Creating .app bundle..."
mkdir -p "$APP_BUNDLE/Contents/MacOS"
mkdir -p "$APP_BUNDLE/Contents/Resources"
mkdir -p "$APP_BUNDLE/Contents/Library/LaunchDaemons"

# ── Check macOS build dependencies ───────────────────────────────────
echo "Checking build dependencies..."
# Xcode CLI tools (needed for codesign, notarytool, lipo)
if ! xcode-select -p &>/dev/null; then
  echo "  Installing Xcode Command Line Tools..."
  xcode-select --install 2>/dev/null || true
  echo "  Re-run this script after Xcode CLI tools finish installing."
  exit 1
fi
echo "  ✓ Xcode CLI tools"

# Check for create-dmg (optional, for styled DMG)
if ! command -v create-dmg &>/dev/null; then
  echo "  ⚠ create-dmg not found — plain DMG will be created"
  echo "  Install for styled DMG: brew install create-dmg"
  echo "    (Homebrew: /bin/bash -c "\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)")"
else
  echo "  ✓ create-dmg"
fi

# Detect architecture and attempt universal binary
ARCH=$(uname -m)
BINARY_X64="$DIST_DIR/binaries/siem-server-${VERSION}-macos-x64"
BINARY_ARM="$DIST_DIR/binaries/siem-server-${VERSION}-macos-arm64"
BINARY_SRC=""

# Try to build a Universal Binary (runs natively on both Intel and Apple Silicon)
if [[ -f "$BINARY_X64" && -f "$BINARY_ARM" ]]; then
  echo "  Building Universal Binary (Intel + Apple Silicon)..."
  BINARY_UNIVERSAL="$DIST_DIR/binaries/siem-server-${VERSION}-macos-universal"
  lipo -create -output "$BINARY_UNIVERSAL" "$BINARY_X64" "$BINARY_ARM" 2>/dev/null && {
    BINARY_SRC="$BINARY_UNIVERSAL"
    echo "  ✓ Universal binary created via lipo"
  } || {
    echo "  ⚠ lipo failed (binaries may already be universal or incompatible) — using arch-specific"
    BINARY_SRC=""
  }
fi

# Fall back to arch-specific binary
if [[ -z "$BINARY_SRC" ]]; then
  if [[ "$ARCH" == "arm64" ]] && [[ -f "$BINARY_ARM" ]]; then
    BINARY_SRC="$BINARY_ARM"
    echo "  Using Apple Silicon binary"
  elif [[ -f "$BINARY_X64" ]]; then
    BINARY_SRC="$BINARY_X64"
    echo "  Using Intel x64 binary"
  fi
fi

if [[ -z "$BINARY_SRC" || ! -f "$BINARY_SRC" ]]; then
  echo "ERROR: No macOS binary found in $DIST_DIR/binaries/"
  echo "Run: bash build-protected.sh first"
  exit 1
fi
echo "  ✓ Binary: $(basename "$BINARY_SRC")"

# Copy binary as the app launcher
cp "$BINARY_SRC" "$APP_BUNDLE/Contents/MacOS/siem-server"
chmod +x "$APP_BUNDLE/Contents/MacOS/siem-server"

# Create launch wrapper (GUI launcher opens browser after start)
cat > "$APP_BUNDLE/Contents/MacOS/SIEM Syslog" << 'LAUNCHER'
#!/usr/bin/env bash
# SIEM .app launcher
SIEM_BIN="$(dirname "$0")/siem-server"
LOG_DIR="/Library/Application Support/siem-syslog/logs"
mkdir -p "$LOG_DIR"

# Start the server daemon if not running
if ! pgrep -f "siem-server" > /dev/null 2>&1; then
  nohup "$SIEM_BIN" >> "$LOG_DIR/siem.log" 2>&1 &
  sleep 3
fi

# Open dashboard in browser
open "http://localhost:18080"
LAUNCHER
chmod +x "$APP_BUNDLE/Contents/MacOS/SIEM Syslog"

# Info.plist
cat > "$APP_BUNDLE/Contents/Info.plist" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key>                  <string>SIEM Syslog</string>
  <key>CFBundleDisplayName</key>           <string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key>            <string>${BUNDLE_ID}</string>
  <key>CFBundleVersion</key>               <string>${VERSION}</string>
  <key>CFBundleShortVersionString</key>    <string>${VERSION}</string>
  <key>CFBundleExecutable</key>            <string>SIEM Syslog</string>
  <key>CFBundleIconFile</key>              <string>AppIcon</string>
  <key>CFBundlePackageType</key>           <string>APPL</string>
  <key>CFBundleSignature</key>             <string>SIEM</string>
  <key>LSMinimumSystemVersion</key>        <string>11.0</string>
  <key>LSUIElement</key>                   <true/>
  <key>NSHumanReadableCopyright</key>
    <string>Copyright © 2026 svoto. All rights reserved.</string>
  <key>SMPrivilegedExecutables</key>
  <dict>
    <key>${BUNDLE_ID}.helper</key>
    <string>anchor apple generic and identifier...</string>
  </dict>
</dict>
</plist>
PLIST

# Copy docs
cp "$ROOT_DIR/LICENSE" "$APP_BUNDLE/Contents/Resources/"
cp "$ROOT_DIR/NOTICE"  "$APP_BUNDLE/Contents/Resources/"
cp "$ROOT_DIR/README.md" "$APP_BUNDLE/Contents/Resources/"
cp "$ROOT_DIR/TESTING.md" "$APP_BUNDLE/Contents/Resources/"

# LaunchDaemon plist (installs as system service)
cat > "$APP_BUNDLE/Contents/Library/LaunchDaemons/${BUNDLE_ID}.plist" << LDPLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
    <string>${BUNDLE_ID}</string>
  <key>ProgramArguments</key>
    <array>
      <string>/Library/Application Support/siem-syslog/siem-server</string>
    </array>
  <key>RunAtLoad</key>    <true/>
  <key>KeepAlive</key>    <true/>
  <key>StandardOutPath</key>
    <string>/Library/Logs/siem-syslog/siem.log</string>
  <key>StandardErrorPath</key>
    <string>/Library/Logs/siem-syslog/siem-error.log</string>
  <key>EnvironmentVariables</key>
    <dict>
      <key>NODE_ENV</key><string>production</string>
    </dict>
  <key>SoftResourceLimits</key>
    <dict>
      <key>NumberOfFiles</key><integer>65536</integer>
    </dict>
</dict>
</plist>
LDPLIST

echo "  ✓ .app bundle created"

# ── Step 2: Create installer script inside DMG ───────────────────────
echo "[2/5] Adding installer..."
cat > "$DMG_DIR/Install SIEM.command" << 'INSTALL'
#!/usr/bin/env bash
# SIEM Syslog Command Center macOS Installer
APP="$(dirname "$0")/SIEM Syslog Command Center.app"
DEST="/Library/Application Support/siem-syslog"
LAUNCHD="/Library/LaunchDaemons/com.svoto.siem-syslog.plist"

echo "Installing SIEM Syslog Command Center v10.0.0..."

sudo mkdir -p "$DEST" "/Library/Logs/siem-syslog"
sudo cp "$APP/Contents/MacOS/siem-server" "$DEST/siem-server"
sudo chmod +x "$DEST/siem-server"
sudo cp "$APP/Contents/Library/LaunchDaemons/com.svoto.siem-syslog.plist" "$LAUNCHD"
sudo launchctl load "$LAUNCHD"
sudo launchctl start com.svoto.siem-syslog

sleep 3
echo ""
echo "✓ SIEM installed and running!"
echo ""
echo "If macOS blocks the app with a security warning:"
echo "  1. Open System Settings → Privacy & Security"
echo "  2. Click 'Allow Anyway' next to the siem-server entry"
echo "  OR run: sudo xattr -rd com.apple.quarantine /Library/Application Support/siem-syslog/siem-server"
echo "  Dashboard: http://localhost:18080"
open "http://localhost:18080"
INSTALL
chmod +x "$DMG_DIR/Install SIEM.command"

cat > "$DMG_DIR/Uninstall SIEM.command" << 'UNINSTALL'
#!/usr/bin/env bash
echo "Uninstalling SIEM Syslog Command Center..."
sudo launchctl stop  com.svoto.siem-syslog 2>/dev/null || true
sudo launchctl unload /Library/LaunchDaemons/com.svoto.siem-syslog.plist 2>/dev/null || true
sudo rm -f /Library/LaunchDaemons/com.svoto.siem-syslog.plist
sudo rm -f "/Library/Application Support/siem-syslog/siem-server"
echo "Uninstalled. Data in /Library/Application Support/siem-syslog/ preserved."
UNINSTALL
chmod +x "$DMG_DIR/Uninstall SIEM.command"

echo "  ✓ Installer scripts added"

# ── Step 3: Optional code signing (requires Apple Developer account) ──
echo "[3/5] Code signing..."
if [[ -n "${APPLE_TEAM_ID:-}" && -n "${CERT_NAME:-}" ]]; then
  codesign --deep --force --verify --verbose \
    --sign "$CERT_NAME" \
    --identifier "$BUNDLE_ID" \
    --options runtime \
    --entitlements "$SCRIPT_DIR/entitlements.plist" \
    "$APP_BUNDLE"
  echo "  ✓ Signed with: $CERT_NAME"
else
  echo "  ⚠ Skipping signing (set APPLE_TEAM_ID and CERT_NAME to sign)"
  echo "  Users will need to: right-click → Open on first launch"
fi

# ── Step 4: Build DMG ────────────────────────────────────────────────
echo "[4/5] Building DMG..."

if command -v create-dmg &>/dev/null; then
  # create-dmg gives a beautiful installer window
  create-dmg \
    --volname "$APP_NAME $VERSION" \
    --volicon "$SCRIPT_DIR/siem-icon.icns" \
    --window-pos 200 120 \
    --window-size 800 400 \
    --icon-size 100 \
    --icon "$APP_NAME.app" 200 190 \
    --hide-extension "$APP_NAME.app" \
    --app-drop-link 600 185 \
    --background "$SCRIPT_DIR/dmg-background.png" \
    --no-internet-enable \
    "$DMG_OUT" \
    "$DMG_DIR" 2>/dev/null \
  && echo "  ✓ DMG with background art created" \
  || fallback_dmg
else
  fallback_dmg
fi

fallback_dmg(){
  # Plain DMG without create-dmg
  hdiutil create -volname "$APP_NAME $VERSION" \
    -srcfolder "$DMG_DIR" \
    -ov -format UDZO \
    "$DMG_OUT"
  echo "  ✓ Plain DMG created (install create-dmg for styled DMG)"
}

# ── Step 5: Optional notarization ────────────────────────────────────
echo "[5/5] Notarization..."
if [[ -n "${APPLE_ID:-}" && -n "${APPLE_PASSWORD:-}" && -n "${APPLE_TEAM_ID:-}" ]]; then
  xcrun notarytool submit "$DMG_OUT" \
    --apple-id "$APPLE_ID" \
    --password "$APPLE_PASSWORD" \
    --team-id "$APPLE_TEAM_ID" \
    --wait
  xcrun stapler staple "$DMG_OUT"
  echo "  ✓ Notarized and stapled"
else
  echo "  ⚠ Skipping notarization (set APPLE_ID, APPLE_PASSWORD, APPLE_TEAM_ID)"
fi

echo ""
echo "═══════════════════════════════════════════════════════"
SIZE=$(du -sh "$DMG_OUT" 2>/dev/null | cut -f1)
echo "  ✓ $DMG_OUT ($SIZE)"
echo ""
echo "  To sign:      CERT_NAME='Developer ID: svoto' bash build-dmg.sh"
echo "  To notarize:  APPLE_ID=you@email.com APPLE_PASSWORD=app-pw"
echo "                APPLE_TEAM_ID=XXXXXXXX bash build-dmg.sh"
echo "═══════════════════════════════════════════════════════"
