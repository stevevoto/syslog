#!/usr/bin/env bash
# SIEM v10.0.0 — Destructive tests (wipe/reset)
# Must explicitly set DESTRUCTIVE=true to run
set -Eeuo pipefail
if [[ "${DESTRUCTIVE:-false}" != "true" ]]; then echo "Set DESTRUCTIVE=true to run"; exit 0; fi
BASE="${BASE:-https://127.0.0.1}"; APP_PORT="${APP_PORT:-18080}"
ADMIN_USER="${ADMIN_USER:-}"; ADMIN_PASS="${ADMIN_PASS:-}"
PASS=0; FAIL=0
GR='\033[0;32m'; RD='\033[0;31m'; NC='\033[0m'
ok(){ PASS=$((PASS+1)); echo -e "  ${GR}PASS${NC} $*"; }
fail(){ FAIL=$((FAIL+1)); echo -e "  ${RD}FAIL${NC} $*"; }
if [[ -z "$ADMIN_USER" ]]; then read -e -r -p "Admin user [admin]: " ADMIN_USER; ADMIN_USER="${ADMIN_USER:-admin}"; fi
if [[ -z "$ADMIN_PASS" ]]; then read -e -r -s -p "Admin pass: " ADMIN_PASS; echo; fi
COOKIE="/tmp/siem-dest-$$.cookies"
api(){ curl -sk -c "$COOKIE" -b "$COOKIE" -H "Content-Type: application/json" -w '\n__S:%{http_code}' --max-time 15 "${@}" 2>/dev/null; }
hcode(){ grep -oP '__S:\K\d+' <<< "$1" | tail -1; }
echo "=== SIEM Destructive Tests ==="
api -X POST "${BASE}:${APP_PORT}/api/auth/login" -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}" >/dev/null
BAD=$(api -X POST "${BASE}:${APP_PORT}/api/admin/fresh-start/runtime" -d '{"confirm":"WRONG"}')
[[ "$(hcode "$BAD")" -ge 400 ]] && ok "Runtime wipe: wrong phrase rejected" || fail "Runtime wipe accepted wrong phrase"
GOOD=$(api -X POST "${BASE}:${APP_PORT}/api/admin/fresh-start/runtime" -d '{"confirm":"CLEAR RUNTIME"}')
[[ "$(hcode "$GOOD")" -lt 400 ]] && ok "Runtime wipe: correct phrase accepted" || fail "Runtime wipe failed"
api -X POST "${BASE}:${APP_PORT}/api/auth/logout" >/dev/null 2>&1 || true
rm -f "$COOKIE"
echo ""; echo "Destructive: PASS=${PASS} FAIL=${FAIL}"
[[ $FAIL -eq 0 ]] && exit 0 || exit 1
