#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  SIEM Syslog Command Center v10.0.0 — Multi-Platform Protected Build
#  Builds self-contained binaries for Linux, macOS (Intel+ARM), Windows
#  Copyright (c) 2026 svoto — PROPRIETARY
# ═══════════════════════════════════════════════════════════════════════
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

SIEM_VERSION="10.0.0"
APP_DIR="$(pwd)/app"
DIST_DIR="$(pwd)/dist"
BUILD_LOG="$DIST_DIR/build.log"

mkdir -p "$DIST_DIR"
echo "Build started: $(date)" > "$BUILD_LOG"

banner(){
  echo ""
  echo "══════════════════════════════════════════════════════════"
  echo "  SIEM Syslog Command Center v${SIEM_VERSION}"
  echo "  Multi-Platform Protected Build"
  echo "══════════════════════════════════════════════════════════"
  echo ""
}

log(){ echo "  $*" | tee -a "$BUILD_LOG"; }
ok(){  echo "  ✓ $*" | tee -a "$BUILD_LOG"; }
warn(){ echo "  ⚠ $*" | tee -a "$BUILD_LOG"; }
fail(){ echo "  ✗ $*" | tee -a "$BUILD_LOG"; }

banner

# ── Check Node.js version ─────────────────────────────────────────────
NODE_VER=$(node --version 2>/dev/null | grep -oP '\d+' | head -1 || echo 0)
[[ "$NODE_VER" -ge 18 ]] || { fail "Node.js 18+ required (got $NODE_VER)"; exit 1; }
ok "Node.js $(node --version)"

cd "$APP_DIR"

# ── Step 1: Install build dependencies ───────────────────────────────
echo ""
log "Step 1/5: Installing build tools..."

install_tool(){ 
  local pkg="$1"
  local bin="$APP_DIR/node_modules/.bin/$pkg"
  if [[ ! -x "$bin" ]]; then
    log "Installing $pkg..."
    npm install --save-dev "$pkg" --silent 2>>"$BUILD_LOG" || warn "$pkg install failed"
  else
    ok "$pkg already installed"
  fi
}

install_tool "bytenode"
install_tool "@yao-pkg/pkg"          # modern pkg fork supporting Node 22
install_tool "javascript-obfuscator"
install_tool "pkg-fetch"             # prebuilt Node binaries for cross-compilation

BYTENODE="$APP_DIR/node_modules/.bin/bytenode"
PKG="$APP_DIR/node_modules/.bin/pkg"
OBFUSCATOR="$APP_DIR/node_modules/.bin/javascript-obfuscator"

# ── Step 2: Compile JS → V8 bytecode ─────────────────────────────────
echo ""
log "Step 2/5: Compiling to V8 bytecode..."

BYTECODE_DIR="$DIST_DIR/bytecode"
mkdir -p "$BYTECODE_DIR/lib"

compile_file(){
  local src="$1" dst="$2"
  if [[ -x "$BYTENODE" ]]; then
    "$BYTENODE" --compile "$src" --output "$dst" 2>>"$BUILD_LOG" \
      && ok "$(basename "$src") → $(basename "$dst")" \
      || { warn "bytenode failed for $(basename "$src"), using obfuscation"; obfuscate_file "$src" "${dst%.jsc}.js"; }
  else
    obfuscate_file "$src" "${dst%.jsc}.js"
  fi
}

obfuscate_file(){
  local src="$1" dst="$2"
  if [[ -x "$OBFUSCATOR" ]]; then
    "$OBFUSCATOR" "$src" --output "$dst" \
      --compact true \
      --control-flow-flattening true \
      --control-flow-flattening-threshold 0.75 \
      --dead-code-injection true \
      --dead-code-injection-threshold 0.4 \
      --string-array true \
      --string-array-encoding 'rc4' \
      --string-array-threshold 0.75 \
      --rotate-string-array true \
      --self-defending true \
      --identifier-names-generator 'mangled' \
      2>>"$BUILD_LOG" && ok "$(basename "$src") obfuscated" || warn "obfuscation failed for $(basename "$src")"
  else
    cp "$src" "$dst"
    warn "No build tools for $(basename "$src") — copied as-is"
  fi
}

# Compile server and all libs
compile_file "$APP_DIR/server-v3.js" "$BYTECODE_DIR/server-v3.jsc"
for f in "$APP_DIR/lib/"*.js; do
  name="$(basename "$f" .js)"
  compile_file "$f" "$BYTECODE_DIR/lib/${name}.jsc"
done

# Write the universal bytecode loader
cat > "$BYTECODE_DIR/server.js" << 'LOADER'
'use strict';
/**
 * SIEM Syslog Command Center v10.0.0
 * Copyright (c) 2026 svoto — PROPRIETARY
 * Bytecode loader — do not modify
 */
const path = require('path');
const Module = require('module');
const bytenode = require('bytenode');

// Patch require() to resolve .jsc files
const origResolve = Module._resolveFilename.bind(Module);
Module._resolveFilename = function(req, parent, isMain, opts) {
  const resolved = origResolve(req, parent, isMain, opts);
  const jsc = resolved.replace(/\.js$/, '.jsc');
  const fs = require('fs');
  if (resolved.endsWith('.js') && fs.existsSync(jsc)) return jsc;
  return resolved;
};

// Boot
bytenode.runBytecodeFile(path.join(__dirname, 'server-v3.jsc'));
LOADER
ok "Bytecode loader written"

# ── Step 3: pkg configuration ─────────────────────────────────────────
echo ""
log "Step 3/5: Configuring pkg targets..."

# Create pkg manifest
cat > "$APP_DIR/package-pkg.json" << PKGJSON
{
  "name": "siem-syslog",
  "version": "${SIEM_VERSION}",
  "bin": "server-v3.js",
  "pkg": {
    "scripts": [],
    "assets": [
      "public/**/*",
      "lib/*.jsc",
      "*.jsc"
    ],
    "targets": [
      "node22-linux-x64",
      "node22-linux-arm64",
      "node22-macos-x64",
      "node22-macos-arm64",
      "node22-win-x64"
    ],
    "outputPath": "${DIST_DIR}/binaries"
  }
}
PKGJSON

# ── Step 4: Build binaries for all platforms ──────────────────────────
echo ""
log "Step 4/5: Building platform binaries..."
mkdir -p "$DIST_DIR/binaries"

declare -A TARGETS=(
  ["linux-x64"]="node22-linux-x64"
  ["linux-arm64"]="node22-linux-arm64"
  ["macos-x64"]="node22-macos-x64"
  ["macos-arm64"]="node22-macos-arm64"
  ["windows-x64"]="node22-win-x64"
)

declare -A EXTENSIONS=(
  ["linux-x64"]=""
  ["linux-arm64"]=""
  ["macos-x64"]=""
  ["macos-arm64"]=""
  ["windows-x64"]=".exe"
)

if [[ -x "$PKG" ]]; then
  for platform in "${!TARGETS[@]}"; do
    TARGET="${TARGETS[$platform]}"
    EXT="${EXTENSIONS[$platform]}"
    OUT="$DIST_DIR/binaries/siem-server-${SIEM_VERSION}-${platform}${EXT}"
    
    log "Building $platform..."
    if "$PKG" "$APP_DIR/server-v3.js" \
        --target "$TARGET" \
        --output "$OUT" \
        --public \
        2>>"$BUILD_LOG"; then
      size=$(du -sh "$OUT" 2>/dev/null | cut -f1)
      ok "siem-server-${SIEM_VERSION}-${platform}${EXT} ($size)"
    else
      warn "$platform build failed — check $BUILD_LOG"
    fi
  done
else
  warn "pkg not available — skipping binary builds"
  warn "Install manually: npm install -g @yao-pkg/pkg"
fi

# ── Step 5: Create platform-specific installers ───────────────────────
echo ""
log "Step 5/5: Creating platform installers..."

# --- Linux installer (systemd service) ---
LINUX_DIR="$DIST_DIR/installers/linux"
mkdir -p "$LINUX_DIR"
cp "$DIST_DIR/binaries/siem-server-${SIEM_VERSION}-linux-x64" "$LINUX_DIR/siem-server" 2>/dev/null || true
chmod +x "$LINUX_DIR/siem-server" 2>/dev/null || true
cp "$(pwd)/LICENSE" "$(pwd)/NOTICE" "$(pwd)/README.md" "$LINUX_DIR/" 2>/dev/null || true

cat > "$LINUX_DIR/install.sh" << 'LINUXINSTALL'
#!/usr/bin/env bash
set -euo pipefail
SIEM_VERSION="10.0.0"
BIN="$(dirname "${BASH_SOURCE[0]}")/siem-server"
[[ -f "$BIN" ]] || { echo "ERROR: siem-server binary not found"; exit 1; }
install -D -m 0755 "$BIN" /usr/local/bin/siem-server
mkdir -p /etc/siem-syslog /var/lib/siem-syslog /var/log/siem-syslog /var/backups/siem-syslog

cat > /etc/systemd/system/siem-syslog.service << 'SVC'
[Unit]
Description=SIEM Syslog Command Center v10.0.0
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/siem-server
Restart=always
RestartSec=5
User=root
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
SVC

systemctl daemon-reload
systemctl enable siem-syslog
systemctl start siem-syslog
echo "SIEM v${SIEM_VERSION} installed. Open http://$(hostname -I | awk '{print $1}'):18080"
LINUXINSTALL
chmod +x "$LINUX_DIR/install.sh"
ok "Linux installer created"

# --- macOS installer (launchd) ---
MAC_DIR="$DIST_DIR/installers/macos"
mkdir -p "$MAC_DIR"
cp "$DIST_DIR/binaries/siem-server-${SIEM_VERSION}-macos-arm64" "$MAC_DIR/siem-server" 2>/dev/null || \
cp "$DIST_DIR/binaries/siem-server-${SIEM_VERSION}-macos-x64"   "$MAC_DIR/siem-server" 2>/dev/null || true
chmod +x "$MAC_DIR/siem-server" 2>/dev/null || true

cat > "$MAC_DIR/install.sh" << 'MACINSTALL'
#!/usr/bin/env bash
set -euo pipefail
SIEM_VERSION="10.0.0"
BIN="$(dirname "${BASH_SOURCE[0]}")/siem-server"
[[ -f "$BIN" ]] || { echo "ERROR: siem-server binary not found"; exit 1; }

INSTALL_DIR="/Library/Application Support/siem-syslog"
mkdir -p "$INSTALL_DIR/bin" "$INSTALL_DIR/data" "$INSTALL_DIR/logs" \
         "$INSTALL_DIR/config" "$INSTALL_DIR/backups"
cp "$BIN" "$INSTALL_DIR/bin/siem-server"
chmod +x "$INSTALL_DIR/bin/siem-server"

# Create launchd plist
cat > /Library/LaunchDaemons/com.svoto.siem-syslog.plist << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.svoto.siem-syslog</string>
  <key>ProgramArguments</key>
  <array>
    <string>/Library/Application Support/siem-syslog/bin/siem-server</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>/Library/Application Support/siem-syslog/logs/siem.log</string>
  <key>StandardErrorPath</key>
  <string>/Library/Application Support/siem-syslog/logs/siem-error.log</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>NODE_ENV</key>
    <string>production</string>
  </dict>
</dict>
</plist>
PLIST

launchctl load /Library/LaunchDaemons/com.svoto.siem-syslog.plist 2>/dev/null || true
launchctl start com.svoto.siem-syslog 2>/dev/null || true
echo "SIEM v${SIEM_VERSION} installed."
echo "Dashboard: http://localhost:18080"
echo "Config: /Library/Application Support/siem-syslog/config/"
MACINSTALL
chmod +x "$MAC_DIR/install.sh"
ok "macOS installer created"

# Build proper DMG (macOS only)
if [[ "$(uname -s)" == "Darwin" ]]; then
  log 'Building macOS DMG...'
  bash "$SCRIPT_DIR/packaging/macos/build-dmg.sh" \
    && ok 'siem-syslog-${SIEM_VERSION}-macos.dmg built' \
    || warn 'DMG build failed - check packaging/macos/build-dmg.sh'
else
  warn 'DMG build requires macOS host - run packaging/macos/build-dmg.sh on a Mac'
  warn 'Using shell installer: dist/installers/macos/install.sh'
fi

# --- Windows installer (PowerShell + NSSM service) ---
WIN_DIR="$DIST_DIR/installers/windows"
mkdir -p "$WIN_DIR"
cp "$DIST_DIR/binaries/siem-server-${SIEM_VERSION}-windows-x64.exe" \
   "$WIN_DIR/siem-server.exe" 2>/dev/null || true

cat > "$WIN_DIR/Install-SIEM.ps1" << 'WININSTALL'
# SIEM Syslog Command Center v10.0.0 - Windows Installer
# Run as Administrator: powershell -ExecutionPolicy Bypass -File Install-SIEM.ps1

param([string]$InstallDir = "$env:ProgramFiles\SIEM-Syslog")

$ErrorActionPreference = "Stop"
$Version = "10.0.0"

Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  SIEM Syslog Command Center v$Version" -ForegroundColor Cyan
Write-Host "  Windows Installer" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan

# Create directories
$dirs = @(
  "$InstallDir",
  "$env:ProgramData\siem-syslog\data",
  "$env:ProgramData\siem-syslog\config",
  "$env:ProgramData\siem-syslog\logs",
  "$env:ProgramData\siem-syslog\backups"
)
foreach ($dir in $dirs) {
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  Write-Host "  ✓ Created: $dir"
}

# Copy binary
$BinSrc = Join-Path $PSScriptRoot "siem-server.exe"
$BinDst = Join-Path $InstallDir "siem-server.exe"
Copy-Item -Force $BinSrc $BinDst
Write-Host "  ✓ Installed: $BinDst"

# Install as Windows Service using sc.exe
Write-Host "  Installing Windows service..."
$svcName = "SIEMSyslog"
sc.exe delete $svcName 2>$null
sc.exe create $svcName `
  binPath= "`"$BinDst`"" `
  DisplayName= "SIEM Syslog Command Center" `
  start= auto `
  obj= LocalSystem | Out-Null

sc.exe description $svcName "SIEM Syslog Command Center v$Version by svoto" | Out-Null

# Configure recovery (restart on failure)
sc.exe failure $svcName reset= 60 actions= restart/5000/restart/10000/restart/30000 | Out-Null

# Set environment
New-ItemProperty -Force -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$svcName" `
  -Name Environment -Value @("NODE_ENV=production") | Out-Null

# Add firewall rules
$ports = @(
  @{Port=18080; Name="SIEM Dashboard HTTP"},
  @{Port=8443;  Name="SIEM Dashboard HTTPS"},
  @{Port=514;   Name="SIEM Syslog UDP"; Proto="UDP"},
  @{Port=601;   Name="SIEM Syslog TCP"},
  @{Port=6514;  Name="SIEM Syslog TLS"}
)
foreach ($rule in $ports) {
  $proto = if ($rule.Proto) { $rule.Proto } else { "TCP" }
  netsh advfirewall firewall add rule `
    name=$rule.Name `
    dir=in action=allow protocol=$proto `
    localport=$rule.Port | Out-Null
  Write-Host "  ✓ Firewall: $($rule.Name) :$($rule.Port)/$proto"
}

# Start service
Start-Service -Name $svcName
Write-Host ""
Write-Host "  ✓ SIEM v$Version installed and running!" -ForegroundColor Green
Write-Host ""
Write-Host "  Dashboard:  http://localhost:18080" -ForegroundColor Yellow
Write-Host "  Config dir: $env:ProgramData\siem-syslog\config\" -ForegroundColor Yellow
Write-Host "  Log dir:    $env:ProgramData\siem-syslog\logs\" -ForegroundColor Yellow
Write-Host ""
WININSTALL

cat > "$WIN_DIR/Uninstall-SIEM.ps1" << 'WINUNINSTALL'
# SIEM Uninstaller
Stop-Service -Name SIEMSyslog -ErrorAction SilentlyContinue
sc.exe delete SIEMSyslog
Remove-Item -Recurse -Force "$env:ProgramFiles\SIEM-Syslog" -ErrorAction SilentlyContinue
Write-Host "SIEM uninstalled. Data in $env:ProgramData\siem-syslog\ was preserved."
WINUNINSTALL

ok "Windows installer (PowerShell) created"

# Build proper .exe installer with NSIS (if available)
if command -v makensis &>/dev/null; then
  log 'Building Windows .exe installer with NSIS...'
  cd "$SCRIPT_DIR/packaging/windows"
  cp "$DIST_DIR/binaries/siem-server-${SIEM_VERSION}-windows-x64.exe" ./siem-server.exe 2>/dev/null || true
  makensis siem-installer.nsi >>'$BUILD_LOG' 2>&1 \
    && { mv siem-syslog-*-setup.exe "$DIST_DIR/" 2>/dev/null || true
         ok "siem-syslog-${SIEM_VERSION}-setup.exe built"; } \
    || warn 'NSIS build failed - use Install-SIEM.ps1 instead'
  cd "$SCRIPT_DIR"
else
  warn 'NSIS not found - .exe installer skipped (install: apt install nsis)'
  warn 'Using PowerShell installer: dist/installers/windows/Install-SIEM.ps1'
fi

# ── Summary ───────────────────────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════════════════"
echo "  BUILD COMPLETE"
echo ""
echo "  Binaries:"
ls -lh "$DIST_DIR/binaries/" 2>/dev/null | grep "siem-server" | \
  awk '{print "    " $5 "  " $9}' || echo "    (none built — see build.log)"
echo ""
echo "  Installers:"
echo "    dist/installers/linux/     install.sh (systemd)"
echo "    dist/installers/macos/     install.sh (launchd)"
echo "    dist/installers/windows/   Install-SIEM.ps1"
echo ""
echo "  Log: $BUILD_LOG"
echo "══════════════════════════════════════════════════════════"
