; SIEM Syslog Command Center v10.0.0 — Windows NSIS Installer
; Copyright (c) 2026 svoto — PROPRIETARY
; Requires: NSIS (makensis) + siem-server.exe in same directory
; Output: siem-syslog-10.0.0-setup.exe

Unicode True

!define APP_NAME     "SIEM Syslog Command Center"
!define APP_VERSION  "10.0.0"
!define APP_AUTHOR   "svoto"
!define APP_URL      "https://github.com/svoto/siem-syslog"
!define SVC_NAME     "SIEMSyslog"
!define INSTALL_DIR  "$PROGRAMFILES64\SIEM-Syslog"
!define DATA_DIR     "$APPDATA\siem-syslog"
!define REG_KEY      "Software\svoto\SIEM-Syslog"

Name "${APP_NAME} ${APP_VERSION}"
OutFile "siem-syslog-${APP_VERSION}-setup.exe"
InstallDir "${INSTALL_DIR}"
RequestExecutionLevel admin
ShowInstDetails show
ShowUnInstDetails show
SetCompressor /SOLID lzma

!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "WinMessages.nsh"


; UI Settings
!define MUI_ABORTWARNING
; Icon file — place siem-icon.ico in same directory as this .nsi script
!define MUI_ICON   "${__FILEDIR__}\siem-icon.ico"
!define MUI_UNICON "${__FILEDIR__}\siem-icon.ico"
!define MUI_WELCOMEPAGE_TITLE "SIEM Syslog Command Center v${APP_VERSION}"
!define MUI_WELCOMEPAGE_TEXT "This will install ${APP_NAME} v${APP_VERSION} as a Windows service.$\r$\n$\r$\nAll 5 syslog ports will be opened in Windows Firewall automatically.$\r$\n$\r$\nClick Next to continue."
!define MUI_FINISHPAGE_RUN ""
!define MUI_FINISHPAGE_TEXT "Installation complete!$\r$\n$\r$\nDashboard: http://localhost:18080$\r$\n$\r$\nThe service starts automatically on boot."
!define MUI_FINISHPAGE_LINK "Open Dashboard"
!define MUI_FINISHPAGE_LINK_LOCATION "http://localhost:18080"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "..\..\LICENSE"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; Version info for the .exe
VIProductVersion "${APP_VERSION}.0"
VIAddVersionKey "ProductName"      "${APP_NAME}"
VIAddVersionKey "ProductVersion"   "${APP_VERSION}"
VIAddVersionKey "CompanyName"      "${APP_AUTHOR}"
VIAddVersionKey "LegalCopyright"   "Copyright (c) 2026 ${APP_AUTHOR}"
VIAddVersionKey "FileDescription"  "${APP_NAME} Installer"
VIAddVersionKey "FileVersion"      "${APP_VERSION}"

; ── Install ─────────────────────────────────────────────────────────
Section "Main" SecMain
  SectionIn RO

  ; ── Check Visual C++ Redistributable ────────────────────────────────
  ; The bundled siem-server.exe includes Node.js runtime.
  ; If the service fails to start, install VC++ 2022 Redistributable (x64) from:
  ;   https://aka.ms/vs/17/release/vc_redist.x64.exe
  ReadRegDWORD $0 HKLM "SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\X64" "Installed"
  ${If} $0 != 1
    DetailPrint "NOTE: Visual C++ 2022 Redistributable (x64) not detected."
    DetailPrint "If the service fails to start, download it from:"
    DetailPrint "  https://aka.ms/vs/17/release/vc_redist.x64.exe"
  ${Else}
    DetailPrint "Visual C++ Redistributable already installed."
  ${EndIf}

  ; ── Note: Node.js is BUNDLED inside siem-server.exe ─────────────────
  ; No separate Node.js installation is required. The binary is self-contained.
  DetailPrint "Note: Node.js runtime is bundled inside siem-server.exe — no separate install needed."

  SetOutPath "$INSTDIR"

  ; Stop existing service if running
  ExecWait 'sc stop "${SVC_NAME}"' $0
  Sleep 2000

  ; Copy files
  File "siem-server.exe"
  File "..\..\LICENSE"
  File "..\..\NOTICE"
  File "..\..\README.md"
  File "..\..\TESTING.md"

  ; Create data directories
  CreateDirectory "$APPDATA\siem-syslog\data"
  CreateDirectory "$APPDATA\siem-syslog\config"
  CreateDirectory "$APPDATA\siem-syslog\logs"
  CreateDirectory "$APPDATA\siem-syslog\backups"
  CreateDirectory "$APPDATA\siem-syslog\config\ssl"

  ; Install as Windows Service
  ExecWait 'sc delete "${SVC_NAME}"' $0
  ExecWait 'sc create "${SVC_NAME}" binPath= "$INSTDIR\siem-server.exe" DisplayName= "${APP_NAME}" start= auto obj= LocalSystem' $0
  ExecWait 'sc description "${SVC_NAME}" "${APP_NAME} v${APP_VERSION} by ${APP_AUTHOR}"' $0
  ExecWait 'sc failure "${SVC_NAME}" reset= 60 actions= restart/5000/restart/10000/restart/30000' $0

  ; Firewall rules
  ExecWait 'netsh advfirewall firewall delete rule name="SIEM Dashboard"' $0
  ExecWait 'netsh advfirewall firewall add rule name="SIEM Dashboard HTTP"  dir=in action=allow protocol=TCP localport=18080' $0
  ExecWait 'netsh advfirewall firewall add rule name="SIEM Dashboard HTTPS" dir=in action=allow protocol=TCP localport=8443' $0
  ExecWait 'netsh advfirewall firewall add rule name="SIEM Syslog UDP"      dir=in action=allow protocol=UDP localport=514' $0
  ExecWait 'netsh advfirewall firewall add rule name="SIEM Syslog TCP"      dir=in action=allow protocol=TCP localport=601' $0
  ExecWait 'netsh advfirewall firewall add rule name="SIEM Syslog TLS"      dir=in action=allow protocol=TCP localport=6514' $0

  ; Start the service
  ExecWait 'sc start "${SVC_NAME}"' $0

  ; Registry for uninstaller
  WriteRegStr HKLM "${REG_KEY}" "InstallDir" "$INSTDIR"
  WriteRegStr HKLM "${REG_KEY}" "Version"    "${APP_VERSION}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "DisplayName"    "${APP_NAME}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "DisplayVersion" "${APP_VERSION}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "Publisher"      "${APP_AUTHOR}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "UninstallString" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "URLInfoAbout"   "${APP_URL}"
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "NoModify" 1
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}" \
    "NoRepair" 1

  ; Write uninstaller
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  ; Start menu shortcut
  CreateDirectory "$SMPROGRAMS\${APP_NAME}"
  CreateShortCut  "$SMPROGRAMS\${APP_NAME}\Dashboard.lnk" \
    "http://localhost:18080" "" "$INSTDIR\siem-server.exe" 0
  CreateShortCut  "$SMPROGRAMS\${APP_NAME}\Uninstall.lnk" \
    "$INSTDIR\Uninstall.exe"

SectionEnd

; ── Uninstall ────────────────────────────────────────────────────────
Section "Uninstall"
  ExecWait 'sc stop "${SVC_NAME}"'
  Sleep 2000
  ExecWait 'sc delete "${SVC_NAME}"'

  ; Remove firewall rules
  ExecWait 'netsh advfirewall firewall delete rule name="SIEM Dashboard HTTP"'
  ExecWait 'netsh advfirewall firewall delete rule name="SIEM Dashboard HTTPS"'
  ExecWait 'netsh advfirewall firewall delete rule name="SIEM Syslog UDP"'
  ExecWait 'netsh advfirewall firewall delete rule name="SIEM Syslog TCP"'
  ExecWait 'netsh advfirewall firewall delete rule name="SIEM Syslog TLS"'

  Delete "$INSTDIR\siem-server.exe"
  Delete "$INSTDIR\LICENSE"
  Delete "$INSTDIR\NOTICE"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\TESTING.md"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir  "$INSTDIR"

  ; Remove Start Menu
  Delete "$SMPROGRAMS\${APP_NAME}\Dashboard.lnk"
  Delete "$SMPROGRAMS\${APP_NAME}\Uninstall.lnk"
  RMDir  "$SMPROGRAMS\${APP_NAME}"

  ; Remove PATH entry
  DeleteRegValue HKLM "SYSTEM\CurrentControlSet\Control\Session Manager\Environment" "SIEM_HOME"

  ; Remove registry
  DeleteRegKey HKLM "${REG_KEY}"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SVC_NAME}"

  MessageBox MB_OK "SIEM uninstalled.$\r$\nData preserved in: $APPDATA\siem-syslog\"
SectionEnd
