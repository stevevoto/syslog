# SIEM Response Action Matrix — v1.4.7

Supported live actions, OS requirements, and required system permissions.

## Action Types

| Action | Type | Linux (Ubuntu/Debian) | Linux (RHEL/Oracle) | Windows | Requires Root/Admin | Rollback Available |
|--------|------|----------------------|---------------------|---------|--------------------|--------------------|
| `BLOCK_IP` | iptables | ✅ iptables/nftables | ✅ iptables/firewalld | ❌ | Yes (sudo) | ✅ Yes |
| `UNBLOCK_IP` | iptables | ✅ | ✅ | ❌ | Yes (sudo) | N/A |
| `DISABLE_ACCOUNT` | usermod | ✅ usermod -L | ✅ usermod -L | ❌ | Yes (sudo) | ✅ Yes |
| `ENABLE_ACCOUNT` | usermod | ✅ usermod -U | ✅ usermod -U | ❌ | Yes (sudo) | N/A |
| `LOCK_FILE` | chattr | ✅ chattr +i | ✅ chattr +i | ❌ | Yes (sudo) | ✅ Yes |
| `UNLOCK_FILE` | chattr | ✅ chattr -i | ✅ chattr -i | ❌ | Yes (sudo) | N/A |
| `FORCE_PASSWORD_RESET` | passwd | ✅ passwd --expire | ✅ passwd --expire | ❌ | Yes (sudo) | ✅ Yes |
| `ISOLATE_HOST` | iptables | ✅ (loopback only) | ✅ (loopback only) | ❌ | Yes (sudo) | ✅ Yes |
| `DEISOLATE_HOST` | iptables | ✅ | ✅ | ❌ | Yes (sudo) | N/A |
| `KILL_PROCESS` | kill | ✅ kill -9 | ✅ kill -9 | ❌ | Yes (sudo) | ❌ No |
| `COLLECT_FORENSICS` | tar/dd | ✅ | ✅ | ❌ | Yes (sudo) | N/A |
| `ROTATE_CREDENTIAL` | passwd | ✅ | ✅ | ❌ | Yes (sudo) | ✅ Yes |

## Required sudo Rules

Add to `/etc/sudoers.d/siem-syslog`:
```
siem-syslog ALL=(ALL) NOPASSWD: /sbin/iptables, /sbin/nftables, \
  /usr/sbin/usermod, /usr/bin/chattr, /usr/bin/passwd, \
  /usr/bin/kill, /usr/sbin/firewall-cmd
```

## Action Modes

| Mode | Behavior | Audit Logged | Approval Required |
|------|----------|-------------|-------------------|
| `simulation` | No system changes; returns what would happen | Yes | No |
| `guarded` | Creates pending approval request; waits for admin approval | Yes | Yes |
| `live` | Executes immediately with full system access | Yes | No |

Default mode is `guarded`. Change in **Admin → Response Actions → Mode**.

## Rollback

All reversible actions record a `rollback_cmd` in the response history. To rollback:
```bash
POST /api/v2/response/rollback/{action_id}
```
Or use the **Response Console → History → Rollback** button in the dashboard.

## OS Support Notes

- **Ubuntu 20.04 / 22.04 / 24.04**: Full support for all actions
- **Oracle Linux 8 / 9**: Full support (use `firewall-cmd` for `BLOCK_IP` on OL9 with firewalld)
- **RHEL 8 / 9 / Rocky / Alma**: Full support
- **Debian 11 / 12**: Full support
- **Windows**: Not currently supported — contributions welcome via GitHub issue
- **macOS**: Not supported for production deployments

## Evidence

Each executed action records:
- `id`: Unique action ID (used for approve/rollback)
- `actor`: Username who triggered the action
- `ts`: ISO timestamp
- `target`: IP address, username, or file path
- `mode`: simulation/guarded/live
- `status`: pending_approval/simulated/success/failed
- `rollback_cmd`: Shell command to undo the action
