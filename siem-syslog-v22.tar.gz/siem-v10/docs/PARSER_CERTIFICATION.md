# SIEM Parser Certification Matrix — v1.4.7

## Format Support

| Format | Status | Fields Extracted | ECS Mapped | Test Coverage |
|--------|--------|-----------------|-----------|---------------|
| Syslog RFC 5424 | ✅ Production | priority, facility, severity, host, program, message | Full | §04, §05c |
| Syslog RFC 3164 | ✅ Production | facility, severity, host, message | Full | §04 |
| CEF (ArcSight) | ✅ Production | cs1-cs6, cn1-cn3, src, dst, act, outcome | Full | §31 |
| LEEF (IBM QRadar) | ✅ Production | src, dst, usrName, proto, devTime | Partial | §31 |
| Windows Event XML | ✅ Production | EventID, Provider, Channel, Computer, Security | Full | §31 |
| Sysmon Events 1-25 | ✅ Production | Image, CommandLine, ProcessId, TargetObject | Full | §31 |
| Cisco ASA | ✅ Production | src_ip, dst_ip, action, protocol, port | Full | §34 |
| Cisco IOS | ✅ Production | facility, mnemonic, message | Partial | §34 |
| Juniper SRX | ✅ Production | src-address, dst-address, policy-name, action | Full | §34 |
| Palo Alto PAN-OS | ✅ Production | src, dst, app, action, rule | Full | §34 |
| F5 BIG-IP | ✅ Production | client_ip, virtual_name, method, uri | Partial | §34 |
| Sophos XG | ✅ Production | srcip, dstip, proto, action | Partial | §34 |
| SYSLOG_BARE ECS | ✅ Production | Inferred: ecs_category, ecs_outcome from message patterns | Full | §05c |
| OCSF (v1.0) | 🟡 Preview | Mapped to 4 classes: auth/network/process/malware | Partial | §64 |
| JSON (generic) | ✅ Production | All top-level keys preserved | Passthrough | §05 |
| KV pairs | ✅ Production | key=value pairs extracted | Passthrough | §05c |

## ECS Field Mapping

| Source Field | ECS Field | Notes |
|-------------|-----------|-------|
| hostname / host | `host` | Normalized |
| severity / pri | `severity` | EMERG/ALERT/CRIT/ERR/WARNING/NOTICE/INFO/DEBUG |
| src_ip / srcip / SRC | `source_ip` | GeoIP enriched |
| user / usrName / dstuser | `user_name` | |
| action / act | `ecs_outcome` | success/failure/unknown |
| proto / protocol | `network_protocol` | |
| EventID | `event_code` | Windows events |
| CommandLine | `process_command_line` | Sysmon |

## Vendor Corpus Status

| Vendor | Corpus Status | Notes |
|--------|-------------|-------|
| Cisco | 🟡 Partial | Need live ISR/ASA feed fixtures |
| Juniper | 🟡 Partial | Need SRX/EX feed fixtures |
| Palo Alto | 🟡 Partial | Need NGFW log fixtures |
| F5 | 🟡 Partial | Need BIG-IP iRules log samples |
| Sophos | 🟡 Partial | Need XG firewall samples |
| Microsoft (Windows) | 🟡 Partial | Need Event ID corpus for Security/System/Application |
| Sysmon | ✅ Full | Events 1-25 mapped |
| Linux Audit | 🟡 Partial | auditd log fixtures needed |

## Adding New Parsers

Parsers live in `app/lib/event-parser.js`. To add a new vendor:

1. Add a pattern to `VENDOR_PATTERNS`:
   ```javascript
   { name: 'MY_VENDOR', match: /MyVendor-.*action=/i, parse: parseMyVendor }
   ```
2. Write the `parseMyVendor(raw, ev)` function that populates `ev` fields
3. Add golden fixtures to `tests/golden/my-vendor/` (see Testing below)
4. Run `bash tests/test-all-regress.sh` — §31/§34 will pick up the new parser

## Golden Corpus (in progress)

Fixtures stored in `tests/golden/`:
```
tests/golden/
  cisco-asa/     — ASA deny/permit samples
  juniper-srx/   — SRX session logs
  panos/         — PAN-OS traffic/threat logs
  windows/       — Security event XML samples
  sysmon/        — Sysmon 1/3/7/11/15 samples
  syslog/        — RFC 3164/5424 samples
```
