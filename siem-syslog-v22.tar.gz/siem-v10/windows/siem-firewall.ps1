# SIEM Syslog Command Center — Windows Firewall Configuration
param(
    [int]$HttpPort = 18080,
    [int]$UdpPort  = 55140,
    [int]$TcpPort  = 55141,
    [int]$TlsPort  = 6514
)

function Add-SIEMRule {
    param($Name, $Port, $Protocol, $Description)
    $existing = Get-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue
    if ($existing) { Remove-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue }
    New-NetFirewallRule -DisplayName $Name -Direction Inbound -Protocol $Protocol `
        -LocalPort $Port -Action Allow -Profile Any `
        -Description $Description | Out-Null
    Write-Host "  [OK] Firewall: $Name ($Protocol :$Port)"
}

Add-SIEMRule "SIEM-Syslog-Dashboard"   $HttpPort "TCP" "SIEM Syslog dashboard web interface"
Add-SIEMRule "SIEM-Syslog-UDP"         $UdpPort  "UDP" "SIEM UDP syslog receiver"
Add-SIEMRule "SIEM-Syslog-TCP"         $TcpPort  "TCP" "SIEM TCP syslog receiver"
Add-SIEMRule "SIEM-Syslog-TLS"         $TlsPort  "TCP" "SIEM TLS encrypted syslog"

# Optional: Restrict dashboard to local network
# Set-NetFirewallRule -DisplayName "SIEM-Syslog-Dashboard" -RemoteAddress "LocalSubnet"
Write-Host "  [OK] All SIEM firewall rules active"
