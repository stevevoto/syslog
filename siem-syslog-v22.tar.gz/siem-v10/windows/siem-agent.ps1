<#
.SYNOPSIS
    SIEM Syslog Command Center — Windows Agent v1.4.7
.DESCRIPTION
    Collects Windows Event Log, PowerShell, and security events and
    forwards them to the SIEM server. Runs as a scheduled task.
.PARAMETER SIEMHost
    SIEM server hostname or IP
.PARAMETER SIEMPort
    SIEM REST API port (default: 18080)
.PARAMETER AgentKey
    Agent shared key from SIEM config
.PARAMETER PollSeconds
    Collection interval in seconds (default: 30)
.EXAMPLE
    .\siem-agent.ps1 -SIEMHost siem.corp.local -AgentKey "abc123" -PollSeconds 30
#>
param(
    [Parameter(Mandatory=$true)]  [string]$SIEMHost,
    [int]   $SIEMPort    = 18080,
    [Parameter(Mandatory=$true)]  [string]$AgentKey,
    [int]   $PollSeconds = 30,
    [string]$AgentID     = $env:COMPUTERNAME,
    [int]   $MaxEvents   = 50,
    [switch]$Install,
    [switch]$Uninstall
)

$SIEM_URL    = "http://${SIEMHost}:${SIEMPort}"
$HEADERS     = @{ 'X-Agent-Key' = $AgentKey; 'Content-Type' = 'application/json' }
$TASK_NAME   = "SIEM-Syslog-Agent"
$LAST_READ   = @{}  # Track last event RecordId per log

# ── Install as Scheduled Task ─────────────────────────────────────────────────
if ($Install) {
    $action  = New-ScheduledTaskAction -Execute "powershell.exe" `
        -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$($MyInvocation.MyCommand.Path)`" -SIEMHost `"$SIEMHost`" -AgentKey `"$AgentKey`" -SIEMPort $SIEMPort -PollSeconds $PollSeconds"
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $settings = New-ScheduledTaskSettingsSet -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Days 365)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
    Register-ScheduledTask -TaskName $TASK_NAME -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force
    Start-ScheduledTask -TaskName $TASK_NAME
    Write-Host "[OK] SIEM agent installed as scheduled task: $TASK_NAME"
    Write-Host "[OK] Agent will start automatically on reboot"
    exit 0
}

if ($Uninstall) {
    Stop-ScheduledTask  -TaskName $TASK_NAME -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "[OK] SIEM agent removed"
    exit 0
}

# ── Register with SIEM ────────────────────────────────────────────────────────
function Register-Agent {
    try {
        $body = @{
            hostname = $env:COMPUTERNAME
            platform = "windows"
            version  = "1.4.7"
            ip       = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' } | Select-Object -First 1 -ExpandProperty IPAddress)
        } | ConvertTo-Json
        $resp = Invoke-RestMethod -Uri "$SIEM_URL/api/admin/agents/register" -Method POST -Body $body -Headers $HEADERS -TimeoutSec 10 -ErrorAction Stop
        Write-Host "[OK] Registered with SIEM (id=$($resp.id))"
        return $resp.id
    } catch { Write-Warning "[!!] Registration failed: $_"; return $null }
}

# ── Collect Windows Event Log ─────────────────────────────────────────────────
function Get-NewEvents {
    param([string]$LogName, [int]$MaxCount = 20)
    $lastId = $LAST_READ[$LogName]
    try {
        $filterHash = @{ LogName = $LogName; Level = 1,2,3  }  # Critical, Error, Warning
        if ($lastId) { $filterHash.RecordId = "*[$lastId+]" }
        else { $filterHash.StartTime = (Get-Date).AddSeconds(-$PollSeconds * 2) }

        $events = Get-WinEvent -FilterHashtable $filterHash -MaxEvents $MaxCount -ErrorAction SilentlyContinue
        if ($events) {
            $LAST_READ[$LogName] = ($events | Measure-Object -Property RecordId -Maximum).Maximum
        }
        return $events
    } catch { return @() }
}

# ── Convert Windows Event to syslog format ────────────────────────────────────
function ConvertTo-Syslog {
    param($event)
    $sev = switch ($event.Level) {
        1 { "CRIT" }    # Critical
        2 { "ERR" }     # Error
        3 { "WARNING" } # Warning
        default { "INFO" }
    }
    $msg = ($event.Message -replace '\r?\n',' ' -replace '\s+',' ').Trim()
    if ($msg.Length -gt 500) { $msg = $msg.Substring(0, 500) + "..." }
    return "<$([math]::Floor([Random]::new().Next(34,46)))>$(Get-Date -Format 'MMM dd HH:mm:ss') $env:COMPUTERNAME WinEvent[$($event.Id)]: [$sev] $($event.ProviderName): $msg"
}

# ── Send events to SIEM ───────────────────────────────────────────────────────
function Send-Events {
    param([array]$events)
    if (-not $events) { return }
    foreach ($ev in $events) {
        try {
            $raw = ConvertTo-Syslog $ev
            $body = @{ raw = $raw } | ConvertTo-Json
            Invoke-RestMethod -Uri "$SIEM_URL/api/inject" -Method POST -Body $body -Headers $HEADERS -TimeoutSec 5 -ErrorAction SilentlyContinue | Out-Null
        } catch {}
    }
}

# ── Heartbeat ─────────────────────────────────────────────────────────────────
function Send-Heartbeat {
    param([string]$id)
    try {
        $metrics = @{
            cpu_pct   = [math]::Round((Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average)
            mem_pct   = [math]::Round((1 - (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / (Get-CimInstance Win32_OperatingSystem).TotalVisibleMemorySize) * 100)
            disk_pct  = [math]::Round((Get-PSDrive C | ForEach-Object { ($_.Used / ($_.Used + $_.Free)) * 100 }))
            hostname  = $env:COMPUTERNAME
            platform  = "windows"
        }
        $body = @{ metrics = $metrics } | ConvertTo-Json
        $resp = Invoke-RestMethod -Uri "$SIEM_URL/api/admin/agents/$id/heartbeat" -Method POST -Body $body -Headers $HEADERS -TimeoutSec 5 -ErrorAction Stop

        # Execute any queued commands
        foreach ($cmd in ($resp.commands ?? @())) {
            Write-Host "[CMD] Executing: $($cmd.command)"
            # Basic command dispatch
            switch ($cmd.command) {
                "collect_forensics" {
                    $out = "C:\siem-forensics-$(Get-Date -Format 'yyyyMMddHHmmss')"
                    New-Item -ItemType Directory -Path $out -Force | Out-Null
                    Get-EventLog -LogName Security -Newest 500 -ErrorAction SilentlyContinue | Export-Csv "$out\security.csv" -NoTypeInformation
                    Get-Process | Export-Csv "$out\processes.csv" -NoTypeInformation
                    Get-NetTCPConnection | Export-Csv "$out\connections.csv" -NoTypeInformation
                    Compress-Archive -Path $out -DestinationPath "$out.zip" -Force
                    Write-Host "[OK] Forensics: $out.zip"
                }
                "ping" { Write-Host "[OK] Pong from $env:COMPUTERNAME" }
                default { Write-Warning "[!!] Unknown command: $($cmd.command)" }
            }
        }
    } catch {}
}

# ── Main loop ─────────────────────────────────────────────────────────────────
Write-Host "[..] SIEM Agent starting — connecting to $SIEM_URL"
$agentId = Register-Agent
$heartbeatCounter = 0

while ($true) {
    # Collect from key event logs
    $allEvents = @()
    foreach ($log in @("Security", "System", "Application", "Microsoft-Windows-PowerShell/Operational")) {
        $allEvents += Get-NewEvents -LogName $log -MaxCount $MaxEvents
    }

    if ($allEvents.Count -gt 0) {
        Send-Events $allEvents
        Write-Host "[OK] Sent $($allEvents.Count) events"
    }

    # Heartbeat every 60 seconds
    $heartbeatCounter += $PollSeconds
    if ($heartbeatCounter -ge 60 -and $agentId) {
        Send-Heartbeat $agentId
        $heartbeatCounter = 0
    }

    Start-Sleep -Seconds $PollSeconds
}
