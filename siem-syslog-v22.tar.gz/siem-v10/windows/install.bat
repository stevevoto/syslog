@echo off
:: SIEM Syslog Command Center v1.4.7 — Windows Installer Launcher
:: Double-click to install, or run as Administrator from command line

title SIEM Syslog Command Center Setup

:: Check for admin rights
net session >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c cd /d %~dp0 && install.bat' -Verb RunAs"
    exit /b
)

echo.
echo  ========================================================
echo    SIEM Syslog Command Center v1.4.7 — Windows Setup
echo  ========================================================
echo.

:: Run PowerShell installer
powershell.exe -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
if %ERRORLEVEL% neq 0 (
    echo.
    echo  [ERROR] Installation failed. Check the output above.
    pause
    exit /b 1
)

echo.
echo  Installation complete. Press any key to close.
pause >nul
