/**
 * SIEM Syslog Command Center — Windows Service Wrapper v1.4.7
 * Integrates with Windows Event Log and provides graceful shutdown.
 * Used by NSSM / node-windows for service lifecycle management.
 */
'use strict';

const path    = require('path');
const fs      = require('fs');
const { spawn } = require('child_process');

const SERVICE_NAME = 'SIEM Syslog Command Center';
const VERSION      = '1.4.7';
const APP_PATH     = path.join(__dirname, 'app', 'server-v3.js');
const DATA_DIR     = process.env.SIEM_DATA_DIR || 'C:\\ProgramData\\siem-syslog';
const LOG_DIR      = path.join(DATA_DIR, 'logs');
const CONFIG_PATH  = process.env.SIEM_CONFIG || path.join(DATA_DIR, 'config.json');

// ── Windows Event Log ──────────────────────────────────────────────────────
function winLog(message, level = 'INFO') {
  const ts = new Date().toISOString();
  const logLine = `${ts} [${level}] ${message}\r\n`;
  // Append to SIEM log file
  try {
    if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
    fs.appendFileSync(path.join(LOG_DIR, 'siem-service.log'), logLine);
  } catch(_) {}
  // Also write to stdout (captured by NSSM)
  process.stdout.write(logLine);
}

// ── Schema migration on startup ────────────────────────────────────────────
function runSchemaMigration() {
  return new Promise((resolve) => {
    const pyScript = path.join(__dirname, 'scripts', 'schema-migrate.py');
    if (!fs.existsSync(pyScript)) { resolve(); return; }
    const py = spawn('python', [pyScript], { env: Object.assign({}, process.env, { SIEM_CONFIG: CONFIG_PATH }) });
    py.on('close', () => resolve());
    py.on('error', () => resolve()); // Non-fatal
  });
}

// ── Main ───────────────────────────────────────────────────────────────────
let child = null;

async function start() {
  winLog(`${SERVICE_NAME} v${VERSION} starting...`);

  await runSchemaMigration();
  winLog('Schema migration complete');

  const env = Object.assign({}, process.env, {
    SIEM_CONFIG:    CONFIG_PATH,
    SIEM_DATA_DIR:  DATA_DIR,
    NODE_ENV:       'production',
    SIEM_PLATFORM:  'windows',
  });

  child = spawn(process.execPath, [APP_PATH], {
    env,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });

  child.stdout.on('data', d => process.stdout.write(d));
  child.stderr.on('data', d => process.stderr.write(d));

  child.on('exit', (code, signal) => {
    winLog(`SIEM process exited (code=${code}, signal=${signal})`);
    if (code !== 0 && !_stopping) {
      winLog('Restarting in 5 seconds...', 'WARN');
      setTimeout(start, 5000);
    } else {
      process.exit(0);
    }
  });

  child.on('error', (err) => {
    winLog(`Failed to start SIEM process: ${err.message}`, 'ERROR');
    process.exit(1);
  });

  winLog(`${SERVICE_NAME} started (PID: ${child.pid})`);
}

let _stopping = false;

function stop(signal) {
  if (_stopping) return;
  _stopping = true;
  winLog(`Stopping ${SERVICE_NAME} (${signal})...`);
  if (child) {
    child.kill('SIGTERM');
    setTimeout(() => { if (child) child.kill('SIGKILL'); }, 10000);
  }
}

process.on('SIGTERM', () => stop('SIGTERM'));
process.on('SIGINT',  () => stop('SIGINT'));
process.on('SIGHUP',  () => stop('SIGHUP'));

// Windows-specific: handle service control messages
if (process.platform === 'win32') {
  try {
    process.on('message', (msg) => {
      if (msg === 'shutdown') stop('service_shutdown');
    });
  } catch(_) {}
}

start().catch(err => {
  winLog(`Fatal startup error: ${err.message}`, 'ERROR');
  process.exit(1);
});
