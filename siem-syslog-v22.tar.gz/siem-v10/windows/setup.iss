; SIEM Syslog Command Center v1.4.7
; Inno Setup 6 installer script
; Compile with: ISCC.exe setup.iss
; Download Inno Setup: https://jrsoftware.org/isinfo.php

#define AppName       "SIEM Syslog Command Center"
#define AppVersion    "1.4.7"
#define AppPublisher  "SIEM Syslog"
#define AppURL        "https://github.com/your-org/siem-syslog"
#define AppExeName    "siem-syslog-win-x64.exe"
#define ServiceName   "SIEMSyslog"

[Setup]
AppId={{A7B3C2D1-E4F5-6789-ABCD-EF0123456789}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppURL}/issues
AppUpdatesURL={#AppURL}/releases
DefaultDirName={autopf}\SIEM-Syslog
DefaultGroupName={#AppName}
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=SIEM-Syslog-Setup-{#AppVersion}
SetupIconFile=app\public\favicon.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
WizardResizable=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#AppExeName}
UninstallDisplayName={#AppName}
VersionInfoVersion={#AppVersion}
VersionInfoCompany={#AppPublisher}
VersionInfoDescription={#AppName} Installer

; Require Windows 10 or Server 2019+
MinVersion=10.0.17763

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";     Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startupservice";  Description: "Start SIEM automatically with Windows";                              GroupDescription: "Windows Service:"; Flags: checkedonce

[Files]
; Main executable (built by build-exe.bat using pkg)
Source: "dist\siem-syslog-win-x64.exe";    DestDir: "{app}"; Flags: ignoreversion

; Windows scripts
Source: "windows\install.ps1";              DestDir: "{app}"; Flags: ignoreversion
Source: "windows\uninstall.ps1";            DestDir: "{app}"; Flags: ignoreversion
Source: "windows\siem-firewall.ps1";        DestDir: "{app}"; Flags: ignoreversion
Source: "windows\siem-agent.ps1";           DestDir: "{app}"; Flags: ignoreversion
Source: "windows\siem-service.js";          DestDir: "{app}"; Flags: ignoreversion
Source: "windows\WINDOWS.md";              DestDir: "{app}"; Flags: ignoreversion

; NSSM for service management
Source: "windows\nssm.exe";                DestDir: "{app}"; Flags: ignoreversion; Check: FileExists(ExpandConstant('{src}\windows\nssm.exe'))

; Documentation
Source: "README.md";                        DestDir: "{app}\docs"; Flags: ignoreversion
Source: "docs\ADMIN_GUIDE.md";              DestDir: "{app}\docs"; Flags: ignoreversion; SkipIfDoesntExist: yes
Source: "docs\RESPONSE_ACTION_MATRIX.md";   DestDir: "{app}\docs"; Flags: ignoreversion; SkipIfDoesntExist: yes

[Dirs]
Name: "{commonappdata}\siem-syslog";                  Permissions: everyone-full
Name: "{commonappdata}\siem-syslog\logs";             Permissions: everyone-full
Name: "{commonappdata}\siem-syslog\backups";          Permissions: everyone-full
Name: "{commonappdata}\siem-syslog\reports";          Permissions: everyone-full

[Icons]
Name: "{group}\{#AppName} Dashboard";         Filename: "http://localhost:18080";           WorkingDir: "{app}"
Name: "{group}\{#AppName} Logs";              Filename: "{app}"; WorkingDir: "{commonappdata}\siem-syslog\logs"
Name: "{group}\Uninstall {#AppName}";         Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}";             Filename: "http://localhost:18080"; Tasks: desktopicon

[Run]
; Configure Windows Firewall
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\siem-firewall.ps1"""; \
    Description: "Configure Windows Firewall"; Flags: runhidden waituntilterminated

; Run PowerShell setup (generates config, installs service)
Filename: "powershell.exe"; \
    Parameters: "-ExecutionPolicy Bypass -File ""{app}\install.ps1"" -SkipNodeCheck -NoService"; \
    Description: "Configure SIEM"; Flags: runhidden waituntilterminated

; Install and start Windows Service
Filename: "{app}\nssm.exe"; Parameters: "install {#ServiceName} ""{app}\{#AppExeName}"""; \
    Flags: runhidden waituntilterminated; Tasks: startupservice; Check: FileExists(ExpandConstant('{app}\nssm.exe'))
Filename: "{app}\nssm.exe"; Parameters: "set {#ServiceName} AppDirectory ""{app}"""; \
    Flags: runhidden waituntilterminated; Tasks: startupservice; Check: FileExists(ExpandConstant('{app}\nssm.exe'))
Filename: "{app}\nssm.exe"; Parameters: "set {#ServiceName} AppEnvironmentExtra ""SIEM_CONFIG={commonappdata}\siem-syslog\config.json"""; \
    Flags: runhidden waituntilterminated; Tasks: startupservice; Check: FileExists(ExpandConstant('{app}\nssm.exe'))
Filename: "{app}\nssm.exe"; Parameters: "set {#ServiceName} AppStdout ""{commonappdata}\siem-syslog\logs\siem.log"""; \
    Flags: runhidden waituntilterminated; Tasks: startupservice; Check: FileExists(ExpandConstant('{app}\nssm.exe'))
Filename: "{app}\nssm.exe"; Parameters: "set {#ServiceName} Start SERVICE_AUTO_START"; \
    Flags: runhidden waituntilterminated; Tasks: startupservice; Check: FileExists(ExpandConstant('{app}\nssm.exe'))
Filename: "{app}\nssm.exe"; Parameters: "start {#ServiceName}"; \
    Flags: runhidden waituntilterminated; Tasks: startupservice; Check: FileExists(ExpandConstant('{app}\nssm.exe'))

; Open browser on completion
Filename: "http://localhost:18080"; Description: "Open SIEM Dashboard"; \
    Flags: postinstall skipifsilent shellexec

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\uninstall.ps1"" -Silent -KeepData"; \
    Flags: runhidden waituntilterminated

[UninstallDelete]
Type: filesandordirs; Name: "{app}"

[Code]
// Check Node.js version on pre-install
function CheckNodeJS: Boolean;
var
  nodeVersion: String;
  major: Integer;
begin
  Result := True;
  if Exec('node', '--version', '', SW_HIDE, ewWaitUntilTerminated, 0) then begin
    // Node.js found - check version
    Result := True;
  end else begin
    if MsgBox('Node.js 20+ is required but was not found.' + #13#10 +
              'Download from https://nodejs.org/en/download' + #13#10#13#10 +
              'If you are using the standalone EXE (siem-syslog-win-x64.exe), ' +
              'Node.js is bundled and this check can be skipped.' + #13#10#13#10 +
              'Continue installation anyway?',
              mbConfirmation, MB_YESNO) = IDYES then
      Result := True
    else
      Result := False;
  end;
end;

function InitializeSetup: Boolean;
begin
  Result := CheckNodeJS();
end;
