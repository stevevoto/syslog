#Requires -Version 5.1
param(
    [string]$ServiceName = "SIEMSyslog",
    [string]$InstallDir  = "C:\Program Files\SIEM-Syslog",
    [string]$DataDir     = "C:\ProgramData\siem-syslog",
    [switch]$KeepData,
    [switch]$Silent
)

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator")) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

if (-not $Silent) {
    $confirm = Read-Host "Uninstall SIEM Syslog Command Center? [y/N]"
    if ($confirm -ne 'y' -and $confirm -ne 'Y') { Write-Host "Cancelled."; exit 0 }
}

Write-Host "Uninstalling SIEM Syslog Command Center..." -ForegroundColor Yellow

# Stop and remove service
$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($svc) {
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    $nssm = Join-Path $InstallDir "nssm.exe"
    if (Test-Path $nssm) { & $nssm remove $ServiceName confirm 2>&1 | Out-Null }
    else { & sc.exe delete $ServiceName 2>&1 | Out-Null }
    Write-Host "  [OK] Service removed"
}

# Remove firewall rules
"SIEM-Syslog-Dashboard","SIEM-Syslog-UDP","SIEM-Syslog-TCP","SIEM-Syslog-TLS" |
    ForEach-Object { Remove-NetFirewallRule -DisplayName $_ -ErrorAction SilentlyContinue }
Write-Host "  [OK] Firewall rules removed"

# Remove Start Menu shortcuts
$startMenu = [Environment]::GetFolderPath("CommonPrograms")
Remove-Item "$startMenu\SIEM Syslog" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  [OK] Shortcuts removed"

# Remove registry entry
Remove-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\SIEMSyslog" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  [OK] Registry entries removed"

# Remove install directory
Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  [OK] Installation directory removed"

# Optionally keep data
if (-not $KeepData) {
    if (-not $Silent) {
        $keepData = Read-Host "Keep database and configuration in $DataDir? [Y/n]"
    }
    if ($Silent -or ($keepData -eq 'n' -or $keepData -eq 'N')) {
        Remove-Item $DataDir -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  [OK] Data directory removed"
    } else {
        Write-Host "  [..] Data kept at: $DataDir"
    }
}

Write-Host "`nSIEM Syslog Command Center has been uninstalled." -ForegroundColor Green
