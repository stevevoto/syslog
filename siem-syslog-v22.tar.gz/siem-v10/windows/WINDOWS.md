# SIEM Syslog Command Center v1.4.7 — Windows Installation Guide

## Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Windows   | Server 2019 / Windows 10 1809 | Server 2022 / Windows 11 |
| RAM       | 2 GB    | 4+ GB |
| Disk      | 10 GB   | 50+ GB |
| Node.js   | 18 LTS  | 20 LTS |
| PowerShell | 5.1    | 7.x |

## Installation Options

### Option A — Graphical Installer (recommended)
1. Download `SIEM-Syslog-Setup-1.4.7.exe`
2. Right-click → **Run as administrator**
3. Follow the setup wizard

### Option B — Self-Contained EXE (no Node.js required)
1. Download `siem-syslog-win-x64.exe`
2. Place in a directory with write access
3. Run from an elevated command prompt:
   ```cmd
   set SIEM_CONFIG=C:\ProgramData\siem-syslog\config.json
   siem-syslog-win-x64.exe
   ```

### Option C — PowerShell Script
1. Right-click `install.bat` → **Run as administrator**  
   — OR —
2. Open PowerShell as Administrator:
   ```powershell
   cd C:\path\to\siem-package\windows
   Set-ExecutionPolicy Bypass -Scope Process
   .\install.ps1 -AdminUser admin -AdminPass "YourP@ssword"
   ```

## File Locations

| Item | Default Path |
|------|-------------|
| Application | `C:\Program Files\SIEM-Syslog\` |
| Config | `C:\ProgramData\siem-syslog\config.json` |
| Database | `C:\ProgramData\siem-syslog\siem.db` |
| Logs | `C:\ProgramData\siem-syslog\logs\` |
| Backups | `C:\ProgramData\siem-syslog\backups\` |

## Service Management

```powershell
# Start / Stop / Restart
Start-Service SIEMSyslog
Stop-Service  SIEMSyslog
Restart-Service SIEMSyslog

# View status
Get-Service SIEMSyslog

# View live logs
Get-Content "C:\ProgramData\siem-syslog\logs\siem.log" -Tail 50 -Wait

# Open dashboard
Start-Process "http://localhost:18080"
```

## Windows Agent Deployment

Deploy the SIEM agent to Windows endpoints to forward Event Log, Security, and PowerShell events:

```powershell
# Install agent on endpoint (run as Administrator)
.\siem-agent.ps1 -SIEMHost siem.corp.local -AgentKey "YOUR_AGENT_KEY" -Install

# Verify agent is running
Get-ScheduledTask SIEM-Syslog-Agent

# Uninstall agent
.\siem-agent.ps1 -SIEMHost siem.corp.local -AgentKey "KEY" -Uninstall
```

## Windows Firewall

The installer opens these ports automatically:

| Port | Protocol | Purpose |
|------|----------|---------|
| 18080 | TCP | Dashboard web interface |
| 55140 | UDP | Syslog receiver |
| 55141 | TCP | Syslog receiver (persistent) |
| 6514  | TCP | Encrypted syslog (TLS) |

To restrict dashboard access to your local network:
```powershell
Set-NetFirewallRule -DisplayName "SIEM-Syslog-Dashboard" -RemoteAddress "LocalSubnet"
```

## Sending Windows Logs to SIEM

**Via Agent (recommended):**
See [Windows Agent Deployment](#windows-agent-deployment) above.

**Via Windows Event Forwarding (WEF):**
```powershell
# On collector (SIEM server — Linux) — set up rsyslog or nxlog to receive WEF
# On Windows endpoints — configure WEF subscription to forward to SIEM UDP port
winrm quickconfig
wecutil qc /q
```

**Via NXLog:**
```xml
<!-- nxlog.conf -->
<Output out>
  Module  om_udp
  Host    siem.corp.local
  Port    55140
</Output>
```

**Via Direct API:**
```powershell
Invoke-RestMethod -Uri "http://siem.corp.local:18080/api/inject" `
  -Method POST -ContentType "application/json" `
  -Headers @{'X-Agent-Key'='YOUR_KEY'} `
  -Body '{"raw":"<34>Apr 16 10:00:01 hostname syslog: test event"}'
```

## Building the EXE from Source

Requirements: Node.js 20+, npm, pkg

```cmd
# 1. Install pkg globally
npm install -g pkg

# 2. Build executables (Windows/Linux/macOS)
windows\build-exe.bat

# Output:
#   dist\siem-syslog-win-x64.exe    (Windows self-contained)
#   dist\siem-syslog-linux-x64      (Linux self-contained)
#   dist\siem-syslog-macos-x64      (macOS self-contained)
```

## Compiling the Installer

Requirements: [Inno Setup 6](https://jrsoftware.org/isinfo.php)

```cmd
# Compile installer (produces dist\SIEM-Syslog-Setup-1.4.7.exe)
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" windows\setup.iss
```

## Troubleshooting

**Service won't start:**
```powershell
# Check error log
Get-Content "C:\ProgramData\siem-syslog\logs\siem-error.log" -Tail 20

# Check Event Viewer
Get-EventLog -LogName Application -Source SIEMSyslog -Newest 10
```

**Port already in use:**
```powershell
netstat -ano | findstr :18080
# Identify PID and stop the conflicting process
```

**Permission denied on database:**
```powershell
icacls "C:\ProgramData\siem-syslog" /grant "SYSTEM:(OI)(CI)F" /T
icacls "C:\ProgramData\siem-syslog" /grant "Administrators:(OI)(CI)F" /T
```

**Reset to factory defaults:**
```powershell
Stop-Service SIEMSyslog
Remove-Item "C:\ProgramData\siem-syslog\siem.db"
Remove-Item "C:\ProgramData\siem-syslog\config.json"
# Re-run install.ps1 to regenerate config
```
