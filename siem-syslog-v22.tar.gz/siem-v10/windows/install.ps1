#Requires -Version 5.1
<#
.SYNOPSIS
    SIEM Syslog Command Center v1.4.7 — Windows Installer
.DESCRIPTION
    Installs SIEM as a Windows Service with full firewall configuration.
    Requires PowerShell 5.1+ running as Administrator.
.PARAMETER InstallDir
    Installation directory. Default: C:\Program Files\SIEM-Syslog
.PARAMETER DataDir
    Data/config directory. Default: C:\ProgramData\siem-syslog
.PARAMETER HttpPort
    Dashboard HTTP port. Default: 18080
.PARAMETER AdminUser
    Initial admin username. Default: admin
.PARAMETER AdminPass
    Initial admin password. Default: (prompted)
.EXAMPLE
    .\install.ps1 -AdminUser admin -AdminPass "MyP@ssw0rd"
#>
[CmdletBinding()]
param(
    [string]$InstallDir  = "C:\Program Files\SIEM-Syslog",
    [string]$DataDir     = "C:\ProgramData\siem-syslog",
    [int]   $HttpPort    = 18080,
    [int]   $UdpPort     = 55140,
    [int]   $TcpPort     = 55141,
    [int]   $TlsPort     = 6514,
    [string]$AdminUser   = "admin",
    [string]$AdminPass   = "",
    [string]$ServiceName = "SIEMSyslog",
    [switch]$SkipNodeCheck,
    [switch]$NoService,
    [switch]$Upgrade
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$VERSION = "1.4.7"

# ── Helpers ──────────────────────────────────────────────────────────────────
function Write-Step  { param($msg) Write-Host "`n[$([char]0x25BA)] $msg" -ForegroundColor Cyan }
function Write-OK    { param($msg) Write-Host "  [OK] $msg"              -ForegroundColor Green }
function Write-Warn  { param($msg) Write-Host "  [!!] $msg"              -ForegroundColor Yellow }
function Write-Fail  { param($msg) Write-Host "  [XX] $msg"              -ForegroundColor Red }
function Write-Info  { param($msg) Write-Host "  [..] $msg"              -ForegroundColor Gray }

# ── Privilege check ───────────────────────────────────────────────────────────
Write-Host "`n╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Blue
Write-Host "║   SIEM Syslog Command Center v$VERSION — Windows Setup   ║" -ForegroundColor Blue
Write-Host "╚═══════════════════════════════════════════════════════════╝`n" -ForegroundColor Blue

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator")) {
    Write-Fail "This installer must be run as Administrator."
    Write-Info  "Right-click install.ps1 → Run as Administrator"
    exit 1
}

# ── Node.js check ─────────────────────────────────────────────────────────────
Write-Step "Checking Node.js"
if (-not $SkipNodeCheck) {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if (-not $node) {
        Write-Warn "Node.js not found."
        $download = Read-Host "  Download and install Node.js 20 LTS now? [Y/n]"
        if ($download -ne 'n' -and $download -ne 'N') {
            Write-Info "Downloading Node.js 20 LTS..."
            $nodeInstaller = "$env:TEMP\node-v20-x64.msi"
            $nodeUrl = "https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi"
            try {
                Invoke-WebRequest -Uri $nodeUrl -OutFile $nodeInstaller -UseBasicParsing
                Write-Info "Installing Node.js..."
                Start-Process msiexec.exe -Wait -ArgumentList "/i `"$nodeInstaller`" /quiet ADDLOCAL=ALL"
                Remove-Item $nodeInstaller -Force -ErrorAction SilentlyContinue
                # Refresh PATH
                $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
                Write-OK "Node.js installed successfully"
            } catch {
                Write-Fail "Failed to download Node.js: $_"
                Write-Info "Manual download: https://nodejs.org/en/download"
                exit 1
            }
        } else {
            Write-Fail "Node.js is required. Install Node.js 18+ and re-run."
            exit 1
        }
    } else {
        $nodeVersion = & node --version 2>&1
        Write-OK "Node.js found: $nodeVersion"
        $major = [int]($nodeVersion -replace 'v(\d+)\..*','$1')
        if ($major -lt 18) {
            Write-Fail "Node.js 18+ required. Found: $nodeVersion"
            exit 1
        }
    }
}

# ── Admin password ────────────────────────────────────────────────────────────
if (-not $AdminPass) {
    $secPass = Read-Host "  Enter initial admin password" -AsSecureString
    $AdminPass = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secPass))
    if ($AdminPass.Length -lt 8) {
        Write-Fail "Password must be at least 8 characters."
        exit 1
    }
}

# ── Stop existing service ─────────────────────────────────────────────────────
Write-Step "Preparing installation"
$existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existingService) {
    if (-not $Upgrade) {
        Write-Warn "SIEM service already exists."
        $confirm = Read-Host "  Upgrade/reinstall? (existing data preserved) [Y/n]"
        if ($confirm -eq 'n' -or $confirm -eq 'N') { Write-Info "Installation cancelled."; exit 0 }
    }
    Write-Info "Stopping existing service..."
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
}

# ── Create directories ────────────────────────────────────────────────────────
Write-Step "Creating directories"
$dirs = @($InstallDir, "$InstallDir\app", "$DataDir", "$DataDir\logs", "$DataDir\backups", "$DataDir\reports")
foreach ($dir in $dirs) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    Write-Info "Created: $dir"
}
Write-OK "Directories ready"

# ── Copy application files ────────────────────────────────────────────────────
Write-Step "Installing application files"
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent
$appSource  = Join-Path $sourceDir "app"

if (-not (Test-Path $appSource)) {
    Write-Fail "Application source not found at: $appSource"
    Write-Info "Ensure install.ps1 is in the 'windows' subdirectory of the SIEM package."
    exit 1
}

Write-Info "Copying application files..."
Copy-Item -Path "$appSource\*" -Destination "$InstallDir\app" -Recurse -Force
Copy-Item -Path (Join-Path $sourceDir "package.json") -Destination $InstallDir -Force -ErrorAction SilentlyContinue

# Install npm dependencies
Write-Info "Installing Node.js dependencies..."
Push-Location "$InstallDir\app"
try {
    & npm install --omit=dev --silent 2>&1 | Out-Null
    Write-OK "Dependencies installed"
} finally {
    Pop-Location
}

# Copy Windows-specific scripts
$winScripts = @("siem-service.js","siem-firewall.ps1","siem-agent.ps1","uninstall.ps1")
foreach ($script in $winScripts) {
    $src = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) $script
    if (Test-Path $src) {
        Copy-Item $src -Destination $InstallDir -Force
    }
}

Write-OK "Application files installed"

# ── Generate configuration ────────────────────────────────────────────────────
Write-Step "Generating configuration"

# Generate scrypt hash for admin password using Node
$hashScript = @"
const crypto = require('crypto');
const pass = process.argv[1];
crypto.scrypt(pass, 'siem-salt', 64, { N:16384, r:8, p:1 }, (err, key) => {
    if (err) { process.exit(1); }
    console.log(key.toString('hex'));
});
"@
$hashScript | Set-Content "$env:TEMP\siem-hash.js" -Encoding UTF8
$passwordHash = & node "$env:TEMP\siem-hash.js" $AdminPass 2>&1
Remove-Item "$env:TEMP\siem-hash.js" -Force -ErrorAction SilentlyContinue

$agentKey = -join ((48..57) + (97..102) | Get-Random -Count 32 | ForEach-Object {[char]$_})
$sessionSecret = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 48 | ForEach-Object {[char]$_})
$hmacSecret = -join ((48..57) + (97..102) | Get-Random -Count 64 | ForEach-Object {[char]$_})

$config = @{
    server = @{
        httpPort       = $HttpPort
        udpPort        = $UdpPort
        tcpPort        = $TcpPort
        maxEvents      = 50000
        demoMode       = $false
        demoIntervalMs = 500
        platform       = "windows"
    }
    auth = @{
        enabled = $true
        sessionSecret = $sessionSecret
        users = @(@{
            username     = $AdminUser
            passwordHash = $passwordHash
            role         = "admin"
            displayName  = "Administrator"
            enabled      = $true
        })
    }
    database = @{
        path      = "$DataDir\siem.db" -replace '\\','\\'
        retainDays = 30
    }
    phase2 = @{
        agentSharedKey = $agentKey
    }
    worm = @{
        hmacSecret = $hmacSecret
    }
    logging = @{
        path  = "$DataDir\logs" -replace '\\','\\'
        level = "INFO"
    }
    backupDir  = "$DataDir\backups" -replace '\\','\\'
    reportsDir = "$DataDir\reports" -replace '\\','\\'
    windows = @{
        serviceAccount = "LocalSystem"
        eventLog       = $true
    }
}

$configJson = $config | ConvertTo-Json -Depth 10
New-Item -ItemType Directory -Path "$DataDir" -Force | Out-Null
$configJson | Set-Content -Path "$DataDir\config.json" -Encoding UTF8
Write-OK "Configuration written to: $DataDir\config.json"
Write-Warn "SAVE THESE CREDENTIALS:"
Write-Host "    Admin user:   $AdminUser"
Write-Host "    Agent key:    $agentKey"

# ── Windows Firewall rules ────────────────────────────────────────────────────
Write-Step "Configuring Windows Firewall"
& "$InstallDir\siem-firewall.ps1" -HttpPort $HttpPort -UdpPort $UdpPort -TcpPort $TcpPort -TlsPort $TlsPort
Write-OK "Firewall rules created"

# ── NSSM Service installation ─────────────────────────────────────────────────
if (-not $NoService) {
    Write-Step "Installing Windows Service"

    # Check for NSSM (Non-Sucking Service Manager)
    $nssm = Get-Command nssm -ErrorAction SilentlyContinue
    if (-not $nssm) {
        $nssmPath = "$InstallDir\nssm.exe"
        if (-not (Test-Path $nssmPath)) {
            Write-Info "Downloading NSSM (service manager)..."
            try {
                $nssmUrl = "https://nssm.cc/release/nssm-2.24.zip"
                $nssmZip = "$env:TEMP\nssm.zip"
                Invoke-WebRequest -Uri $nssmUrl -OutFile $nssmZip -UseBasicParsing
                Expand-Archive -Path $nssmZip -DestinationPath "$env:TEMP\nssm" -Force
                Copy-Item "$env:TEMP\nssm\nssm-2.24\win64\nssm.exe" -Destination $nssmPath
                Remove-Item $nssmZip, "$env:TEMP\nssm" -Recurse -Force -ErrorAction SilentlyContinue
                Write-OK "NSSM downloaded"
            } catch {
                Write-Warn "Could not download NSSM. Falling back to sc.exe service registration."
                $nssmPath = $null
            }
        }
    } else {
        $nssmPath = $nssm.Source
    }

    $nodeExe = (Get-Command node -ErrorAction SilentlyContinue)?.Source
    if (-not $nodeExe) { $nodeExe = "C:\Program Files\nodejs\node.exe" }

    if ($nssmPath -and (Test-Path $nssmPath)) {
        Write-Info "Registering service via NSSM..."
        & $nssmPath install $ServiceName $nodeExe "$InstallDir\app\server-v3.js" 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppDirectory "$InstallDir\app" 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppEnvironmentExtra "SIEM_CONFIG=$DataDir\config.json" 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppEnvironmentExtra "NODE_ENV=production" 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppStdout "$DataDir\logs\siem.log" 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppStderr "$DataDir\logs\siem-error.log" 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppRotateFiles 1 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppRotateOnline 1 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppRotateSeconds 86400 2>&1 | Out-Null
        & $nssmPath set $ServiceName AppRotateBytes 10485760 2>&1 | Out-Null
        & $nssmPath set $ServiceName Start SERVICE_AUTO_START 2>&1 | Out-Null
        & $nssmPath set $ServiceName Description "SIEM Syslog Command Center v$VERSION" 2>&1 | Out-Null
        & $nssmPath set $ServiceName DisplayName "SIEM Syslog Command Center" 2>&1 | Out-Null
    } else {
        Write-Info "Registering service via sc.exe..."
        $binPath = "`"$nodeExe`" `"$InstallDir\app\server-v3.js`""
        & sc.exe create $ServiceName binPath= $binPath start= auto DisplayName= "SIEM Syslog Command Center" 2>&1 | Out-Null
        & sc.exe description $ServiceName "SIEM Syslog Command Center v$VERSION — Security Information and Event Management" 2>&1 | Out-Null
        [Environment]::SetEnvironmentVariable("SIEM_CONFIG", "$DataDir\config.json", "Machine")
    }

    Write-Info "Starting service..."
    Start-Service -Name $ServiceName -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 4
    $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running') {
        Write-OK "Service started: $ServiceName"
    } else {
        Write-Warn "Service may not have started. Check: Services -> SIEM Syslog Command Center"
        Write-Info "Log: $DataDir\logs\siem-error.log"
    }
}

# ── Schema migration ──────────────────────────────────────────────────────────
Write-Step "Running schema migration"
$python = Get-Command python -ErrorAction SilentlyContinue
$python3 = Get-Command python3 -ErrorAction SilentlyContinue
$pyExe = if ($python3) { "python3" } elseif ($python) { "python" } else { $null }
if ($pyExe) {
    & $pyExe "$InstallDir\scripts\schema-migrate.py" 2>&1 | Out-Null
    Write-OK "Database schema migrated"
} else {
    Write-Info "Python not found — schema migration will run on first service start"
}

# ── Start Menu shortcuts ──────────────────────────────────────────────────────
Write-Step "Creating shortcuts"
$startMenu = [Environment]::GetFolderPath("CommonPrograms")
$siemFolder = New-Item -ItemType Directory -Path "$startMenu\SIEM Syslog" -Force
$WshShell = New-Object -ComObject WScript.Shell

# Dashboard shortcut
$shortcut = $WshShell.CreateShortcut("$siemFolder\SIEM Dashboard.lnk")
$shortcut.TargetPath = "http://localhost:$HttpPort"
$shortcut.Description = "Open SIEM Dashboard"
$shortcut.Save()

# Service Manager shortcut
$shortcut2 = $WshShell.CreateShortcut("$siemFolder\SIEM Service Manager.lnk")
$shortcut2.TargetPath = "services.msc"
$shortcut2.Description = "Manage SIEM Windows Service"
$shortcut2.Save()

# Uninstaller shortcut
$shortcut3 = $WshShell.CreateShortcut("$siemFolder\Uninstall SIEM.lnk")
$shortcut3.TargetPath = "powershell.exe"
$shortcut3.Arguments = "-ExecutionPolicy Bypass -File `"$InstallDir\uninstall.ps1`""
$shortcut3.Description = "Uninstall SIEM Syslog Command Center"
$shortcut3.Save()

Write-OK "Start Menu shortcuts created"

# ── Registry entry (Programs and Features) ────────────────────────────────────
Write-Step "Registering in Programs and Features"
$uninstKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\SIEMSyslog"
New-Item -Path $uninstKey -Force | Out-Null
Set-ItemProperty -Path $uninstKey -Name "DisplayName"     -Value "SIEM Syslog Command Center"
Set-ItemProperty -Path $uninstKey -Name "DisplayVersion"  -Value $VERSION
Set-ItemProperty -Path $uninstKey -Name "Publisher"       -Value "SIEM Syslog"
Set-ItemProperty -Path $uninstKey -Name "InstallLocation" -Value $InstallDir
Set-ItemProperty -Path $uninstKey -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$InstallDir\uninstall.ps1`""
Set-ItemProperty -Path $uninstKey -Name "DisplayIcon"     -Value "$InstallDir\app\public\favicon.ico"
Set-ItemProperty -Path $uninstKey -Name "NoModify"        -Value 1 -Type DWord
Set-ItemProperty -Path $uninstKey -Name "EstimatedSize"   -Value 51200 -Type DWord
Write-OK "Registered in Programs and Features"

# ── Post-install validation ───────────────────────────────────────────────────
Write-Step "Validating installation"
Start-Sleep -Seconds 2
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:$HttpPort/api/health" -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
    $health = $resp.Content | ConvertFrom-Json
    if ($health.ok) { Write-OK "Health check passed — SIEM is running" }
    else { Write-Warn "Health check returned unexpected response" }
} catch {
    Write-Warn "Health check failed. SIEM may still be starting. Wait 10 seconds and try:"
    Write-Host "    http://localhost:$HttpPort" -ForegroundColor Yellow
}

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host "`n╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║            SIEM INSTALLATION COMPLETE                    ║" -ForegroundColor Green
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "  Dashboard:    http://localhost:$HttpPort" -ForegroundColor Cyan
Write-Host "  Admin user:   $AdminUser"
Write-Host "  Install dir:  $InstallDir"
Write-Host "  Data dir:     $DataDir"
Write-Host "  Service:      $ServiceName (auto-start)"
Write-Host "  Log file:     $DataDir\logs\siem.log"
Write-Host ""
Write-Host "  Syslog ports open:" -ForegroundColor Gray
Write-Host "    UDP :$UdpPort  TCP :$TcpPort  TLS :$TlsPort"
Write-Host ""
Write-Host "  To restart:   Restart-Service $ServiceName"
Write-Host "  To view logs: Get-Content `"$DataDir\logs\siem.log`" -Tail 50 -Wait"
Write-Host ""
