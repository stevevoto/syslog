@echo off
:: SIEM Syslog Command Center v1.4.7 — Windows EXE Build Script
:: Requires: Node.js 20+, npm, pkg (npm install -g pkg)

setlocal EnableDelayedExpansion
title SIEM Build

echo.
echo  ========================================================
echo    SIEM Syslog Command Center v1.4.7 — Build Script
echo  ========================================================
echo.

:: Check Node.js
where node >nul 2>&1 || (
    echo  [ERROR] Node.js not found. Install Node.js 20+ first.
    pause & exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo  [OK] Node.js %NODE_VER%

:: Check pkg
where pkg >nul 2>&1 || (
    echo  [..] Installing pkg bundler...
    call npm install -g pkg >nul 2>&1
    where pkg >nul 2>&1 || (
        echo  [ERROR] pkg installation failed.
        pause & exit /b 1
    )
)
echo  [OK] pkg found

:: Navigate to repo root
cd /d "%~dp0.."
echo  [OK] Working directory: %CD%

:: Install dependencies
echo  [..] Installing dependencies...
cd app
call npm install --omit=dev --silent
cd ..
echo  [OK] Dependencies installed

:: Create dist directory
if not exist dist mkdir dist

:: Build Windows x64 EXE
echo  [..] Building Windows x64 executable...
call pkg . --config windows\pkg.config.json --targets node20-win-x64 --output dist\siem-syslog-win-x64.exe
if %ERRORLEVEL% neq 0 (
    echo  [ERROR] Windows build failed.
    pause & exit /b 1
)
echo  [OK] dist\siem-syslog-win-x64.exe

:: Build Linux x64
echo  [..] Building Linux x64 executable...
call pkg . --config windows\pkg.config.json --targets node20-linux-x64 --output dist\siem-syslog-linux-x64
echo  [OK] dist\siem-syslog-linux-x64

:: Build macOS x64
echo  [..] Building macOS x64 executable...
call pkg . --config windows\pkg.config.json --targets node20-macos-x64 --output dist\siem-syslog-macos-x64
echo  [OK] dist\siem-syslog-macos-x64

echo.
echo  ========================================================
echo    Build complete! Executables in: %CD%\dist
echo  ========================================================
echo.
dir dist\siem-syslog*

echo.
echo  Usage (Windows):
echo    dist\siem-syslog-win-x64.exe
echo  Usage (Linux):
echo    chmod +x dist/siem-syslog-linux-x64 ^&^& ./dist/siem-syslog-linux-x64
echo.
pause
