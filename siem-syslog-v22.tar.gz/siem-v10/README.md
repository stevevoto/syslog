# SIEM Syslog Command Center v1.4.7

## Quick Start

### Install on Ubuntu 20.04/22.04/24.04

```bash
sudo bash install.sh
```

The installer creates a systemd service, configures iptables port redirects,
and prompts for the first admin account.

### Access the dashboard

```
http://YOUR_SERVER_IP:18080
```

Default ports: UDP :55140 (514 via iptables), TCP :55141, TLS :6514, HTTP :18080

### Run regression tests

```bash
ADMIN_USER=admin ADMIN_PASS=yourpass bash tests/test-all-regress.sh
```

### Documentation

See `RELEASE_NOTES_v1.4.7-fixed.md` for this release.
See `COMPLIANCE_RELEASE_GUIDE.md` for compliance and audit guidance.

## Version Information

| Item              | Value                  |
|-------------------|------------------------|
| Product version   | 1.4.7                  |
| Package revision  | Commercial GA Candidate|
| Planning document | Rev 8.0                |
| Primary UI        | app/public/index.html  |
| Regression runner | tests/test-all-regress.sh |

## File Layout

```
app/          — Node.js server, dashboard, v11 extension modules
agents/       — Linux log-forwarding agent
tests/        — Regression suite (primary: test-all-regress.sh)
scripts/      — Backup, restore, cron, schema migration utilities
compliance/   — Compliance and audit reference guides
install.sh    — Full install script for Ubuntu/Debian
```
