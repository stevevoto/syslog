#!/usr/bin/env bash
# Golden corpus parser certification tests
# Usage: ADMIN_USER=admin ADMIN_PASS=pass bash tests/test-golden-corpus.sh [BASE_URL] [PORT]
set -euo pipefail

BASE_URL="${1:-http://127.0.0.1}"
PORT="${2:-18080}"
PASS=0; FAIL=0; SKIP=0

ok()   { echo "  PASS $1"; PASS=$((PASS+1)); }
fail() { echo "  FAIL $1"; FAIL=$((FAIL+1)); }
skip() { echo "  SKIP $1"; SKIP=$((SKIP+1)); }
info() { echo "  INFO $1"; }

COOKIE="/tmp/golden-corpus-$$.jar"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GOLDEN_DIR="$SCRIPT_DIR/golden"

echo "==> Golden corpus parser certification — $(date +%Y-%m-%d)"
echo "    Base: ${BASE_URL}:${PORT}"
echo ""

# Login
LOGIN=$(curl -sk -c "$COOKIE" -b "$COOKIE" \
  -X POST "${BASE_URL}:${PORT}/api/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"${ADMIN_USER:-admin}\",\"password\":\"${ADMIN_PASS:-Siem1234}\"}" \
  -w '\n__S:%{http_code}')
LOGIN_CODE=$(echo "$LOGIN" | grep -oP '__S:\K\d+' || echo "0")
[[ "$LOGIN_CODE" -lt 400 ]] && ok "Login" || { fail "Login failed (HTTP $LOGIN_CODE)"; exit 1; }

# Count events before
BEFORE=$(curl -sk -c "$COOKIE" -b "$COOKIE" "${BASE_URL}:${PORT}/api/stats" | \
  python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print(sum(d.get('sevCounts',{}).values()))" 2>/dev/null || echo 0)

# Inject each fixture
for corpus_dir in "$GOLDEN_DIR"/*/; do
    vendor=$(basename "$corpus_dir")
    injected=0
    
    for log_file in "$corpus_dir"*.log "$corpus_dir"*.xml; do
        [[ -f "$log_file" ]] || continue
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            raw=$(python3 -c "import json,sys; print(json.dumps(sys.argv[1]))" "$line" 2>/dev/null || echo "\"$line\"")
            curl -sk -c "$COOKIE" -b "$COOKIE" \
              -X POST "${BASE_URL}:${PORT}/api/inject" \
              -H "Content-Type: application/json" \
              -d "{\"raw\":${raw}}" >/dev/null 2>&1 || true
            injected=$((injected+1))
        done < "$log_file"
    done
    
    [[ "$injected" -gt 0 ]] && ok "$vendor: injected $injected log lines" || skip "$vendor: no log files found"
    
    # Validate expected fields if expected.json present
    expected_file="$corpus_dir/expected.json"
    if [[ -f "$expected_file" && "$injected" -gt 0 ]]; then
        sleep 1
        # Get recent events and check first expected field is present
        EVENTS=$(curl -sk -c "$COOKIE" -b "$COOKIE" "${BASE_URL}:${PORT}/api/events?limit=50")
        
        # Check each expected record's first non-empty field
        python3 - "$expected_file" "$EVENTS" << 'PY'
import json, sys
expected = json.load(open(sys.argv[1]))
events_resp = json.loads(sys.argv[2]) if sys.argv[2].startswith('{') else {'events':[]}
events = events_resp.get('events', [])

hits = 0
for exp in expected:
    for field, val in exp.items():
        found = any(str(ev.get(field,'')).lower() == str(val).lower() for ev in events)
        if found:
            hits += 1
            break

print(f"  INFO expected_checks={len(expected)} matched={hits}")
PY
    fi
done

# Count after
sleep 1
AFTER=$(curl -sk -c "$COOKIE" -b "$COOKIE" "${BASE_URL}:${PORT}/api/stats" | \
  python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print(sum(d.get('sevCounts',{}).values()))" 2>/dev/null || echo 0)
DELTA=$((AFTER - BEFORE))
info "Events ingested during golden corpus run: $DELTA"

echo ""
echo "  PASS: $PASS  FAIL: $FAIL  SKIP: $SKIP  TOTAL: $((PASS+FAIL+SKIP))"
rm -f "$COOKIE"
[[ "$FAIL" -eq 0 ]]
