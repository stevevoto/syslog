# SIEM v10.4 packaging + validation fixes

## What changed
- restored a robust Version Consistency section in `tests/test-all-regress.sh`
- validator now defaults to `http://127.0.0.1` in the docs/comments and checks version using absolute app-root paths
- restored `.github/workflows/release-gate.yml`
- added `scripts/install-or-upgrade.sh` for stop/backup/sync/restart upgrades
- changed `sync-after-install.sh` to call the unified install-or-upgrade flow
- added `scripts/build-customer-sea.sh` for a tighter customer artifact with stripped tests/docs/maps
- added `packaging/build-native-packages.sh`
- added `packaging/rpm/siem-syslog.spec`
- added packaging docs under `packaging/README_PACKAGING.md`
- updated the main UI title to `SIEM Command Center v1.4.7 / siem-v10.4`

## What this moves forward
- installer / upgrade packaging
- release-gate discipline
- customer build/code exposure posture
- install-time validation reliability

## Honest limits
- one code build can target both Ubuntu and Rocky/RHEL, but native Linux installer formats are still separate (`.deb` vs `.rpm`)
- the included package builder can produce `.deb` here and an `.rpm` on a Rocky/RHEL host with `rpmbuild`
- SEA/minification raises the reverse-engineering bar, but it does not make code unrecoverable on a customer-controlled box
