# CVE handling

This build adds a Phase 10 CVE foundation:
- `/api/admin/cve/lookup?cve=CVE-YYYY-NNNN`
- `/api/admin/cve/extract` with arbitrary text/message input

Returned links:
- `https://www.cve.org/CVERecord?id=<CVE-ID>`
- `https://nvd.nist.gov/vuln/detail/<CVE-ID>`

Guidance:
- CVE.org is the authoritative CVE record.
- NVD provides enrichment and scoring context.
- MITRE ATT&CK is a separate knowledge base and should be linked for technique mapping, not as the CVE canonical source.
