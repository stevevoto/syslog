# Compliance-Ready Release Guide

This release is designed for a **mixed-source distribution model**:

- **Proprietary product code** remains proprietary.
- **Third-party open-source components** are disclosed with notices, license metadata, and SBOM artifacts.
- **Post-install validation** can be executed automatically so every install can be verified and archived.

## What this release includes

- `PROPRIETARY_NOTICE.md` for the proprietary portions of the product
- `OPEN_SOURCE_COMPLIANCE.md` for compliance process guidance
- `scripts/generate-compliance-artifacts.py` to generate:
  - `THIRD_PARTY_NOTICES.md`
  - `sbom.spdx.json`
  - `release-manifest.json`
  - copied license texts from installed `node_modules`
- `scripts/check-license-policy.py` to flag strong-copyleft or unknown licenses for review
- `scripts/build-sea-binary.sh` to try a Node SEA single-binary packaging flow for the server
- `scripts/run-post-install-validation.sh` to run `tests/test-allv13v3.sh` and store a timestamped validation log

## Important guardrails

A compiled binary does **not** erase license obligations. If you distribute binaries, you still need to meet the obligations of every third-party license included in the shipped product.

In practice, that means your release package should include at least:

1. A clear proprietary notice for your own code
2. A third-party notices file
3. A machine-readable SBOM
4. Full license texts for shipped dependencies when required or prudent
5. A release manifest tying artifacts to the exact product version
6. A validation report showing the shipped installer and product passed tests

## Suggested release folder contents

```
release/
  siem-syslog              # optional compiled server binary
  public/                  # static assets shipped with the binary
  LICENSES/                # copied third-party license texts
  THIRD_PARTY_NOTICES.md
  sbom.spdx.json
  release-manifest.json
  PROPRIETARY_NOTICE.md
  OPEN_SOURCE_COMPLIANCE.md
  VALIDATION_REPORT.txt
```

## Recommended workflow

```bash
# 1) Install normally
sudo ./install.sh

# 2) Regenerate compliance artifacts from installed dependencies
sudo /opt/siem-syslog/scripts/generate-compliance-artifacts.py \
  /opt/siem-syslog \
  /opt/siem-syslog/compliance

# 3) Run the license gate
sudo /opt/siem-syslog/scripts/check-license-policy.py \
  /opt/siem-syslog \
  /opt/siem-syslog/compliance/license-policy-report.json

# 4) Run full validation and save the result
sudo ADMIN_USER=admin ADMIN_PASS='your-password' \
  /opt/siem-syslog/scripts/run-post-install-validation.sh

# 5) Optional: attempt a Node SEA binary build
cd /opt/siem-syslog
sudo ./scripts/build-sea-binary.sh
```

## Distribution note

This release is structured to support transparent distribution and auditability. It is **not legal advice**. Review the output with counsel if you are shipping to customers or at conference scale.
