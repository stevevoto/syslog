
# Enterprise implementation matrix

## Implemented
- Syslog UDP/TCP/TLS ingestion
- API ingest and agent ingest
- Live tail
- Correlation engine
- IOC matching and anomaly detection foundations
- Real-time dashboard
- Case management
- PDF/CSV/NDJSON reporting
- Compliance summary
- Theme settings and enterprise matrix API
- Cloud connector profile foundation
- Enrichment settings foundation
- Playbook simulation foundation

## Partial / Foundation only
- Native AWS/Azure/M365 collectors (profiles only, no full pull pipeline)
- Identity enrichment (toggle/settings only)
- Asset enrichment (toggle/settings only)
- Playbooks (simulation only)

## Not yet implemented
- Full CEF parser library
- Automated response actions (disable account/block IP/isolate host)
- WORM / immutable storage
- Multi-node / big-data backend
- Full CMDB / asset / identity integration
