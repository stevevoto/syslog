# Open Source Compliance

This product uses a **mixed-source distribution model**.

- The SIEM application's product-specific code may remain proprietary.
- Third-party open-source components must still be disclosed and handled according to their licenses.

## Minimum operational practices

1. Preserve upstream copyright and license notices.
2. Generate a machine-readable SBOM for each release.
3. Generate a human-readable third-party notices file for each release.
4. Copy license texts from shipped dependencies into the release bundle.
5. Review transitive dependencies before external distribution.
6. Keep a release manifest that ties notices and SBOM files to an exact product version.
7. Keep validation evidence showing the installed release passed its tests.
8. Treat strong-copyleft, custom, and unknown licenses as legal review items.

## Commands

Generate compliance artifacts:
```bash
sudo /opt/siem-syslog/scripts/generate-compliance-artifacts.py \
  /opt/siem-syslog \
  /opt/siem-syslog/compliance
```

Run a simple license gate:
```bash
sudo /opt/siem-syslog/scripts/check-license-policy.py \
  /opt/siem-syslog \
  /opt/siem-syslog/compliance/license-policy-report.json
```

Run full validation and archive the result:
```bash
sudo ADMIN_USER=admin ADMIN_PASS='your-password' \
  /opt/siem-syslog/scripts/run-post-install-validation.sh
```

## Release bundle guidance

A binary release should include at minimum:

- proprietary notice
- third-party notices
- SBOM
- copied license texts
- release manifest
- validation report

A compiled binary does **not** remove license obligations.

This file is operational guidance, not legal advice.
