# SIEM Syslog Command Center v1.4.7

**See README.md for full installation and usage instructions.**

Quick start:
```bash
sudo bash install.sh
```

Primary regression runner:
```bash
ADMIN_USER=admin ADMIN_PASS=yourpass bash tests/test-all-regress.sh
```

Documentation: `RELEASE_NOTES_v1.4.7-fixed.md`
