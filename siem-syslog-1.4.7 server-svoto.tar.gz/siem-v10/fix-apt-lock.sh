#!/usr/bin/env bash
set -euo pipefail

echo "Stopping auto-update services that commonly hold apt/dpkg locks..."
for unit in apt-daily.timer apt-daily-upgrade.timer apt-daily.service apt-daily-upgrade.service unattended-upgrades.service packagekit.service packagekit-offline-update.service; do
  systemctl stop "$unit" >/dev/null 2>&1 || true
  systemctl reset-failed "$unit" >/dev/null 2>&1 || true
done

echo "Gracefully stopping lingering apt/unattended-upgrades processes..."
pkill -TERM -x unattended-upgr >/dev/null 2>&1 || true
pkill -TERM -x apt >/dev/null 2>&1 || true
pkill -TERM -x apt-get >/dev/null 2>&1 || true
pkill -TERM -x aptitude >/dev/null 2>&1 || true
pkill -TERM -x packagekitd >/dev/null 2>&1 || true
sleep 8

echo "Force-stopping anything still lingering..."
pkill -KILL -x unattended-upgr >/dev/null 2>&1 || true
pkill -KILL -x apt >/dev/null 2>&1 || true
pkill -KILL -x apt-get >/dev/null 2>&1 || true
pkill -KILL -x aptitude >/dev/null 2>&1 || true
pkill -KILL -x packagekitd >/dev/null 2>&1 || true
sleep 2

echo "Repairing package database state..."
dpkg --configure -a || true
apt-get -f install -y || true

echo "Remaining lock-related processes:"
ps -eo pid=,comm= | awk '$2 ~ /^(apt|apt-get|dpkg|unattended-upgr|aptitude|packagekitd)$/ {print $1, $2}' || true

echo "Done. You can now retry:"
echo "  apt-get update"
echo "  ./install.sh"
