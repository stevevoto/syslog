# SIEM Syslog Command Center v1.4.7 — Release Notes

## Summary

This release completes commercial hardening (Rev 8.0). It adds a full multi-format parser, asset/identity enrichment pipeline, WORM HMAC chain, playbook automation engine, upgraded response actions with approval gating, and a real cloud connector polling scheduler.

---

## Core Fixes Applied

### Ingest & GeoMap
- Bootstrap replay limit: 100 → 500 events
- GeoMap 24-hr window default (was 1 hr); `?hours=N` param added; `{ ok, points, count, hours }` response wrapper
- GeoIP enrichment: skips private RFC-1918 IPs, finds first public IP in message body
- `fetchGeoMapData()` hydrates world map on load, tab switch, and map init

### UI
- Scroll button: initial state corrected to active (auto-scroll starts enabled)
- `toggleScroll()` class logic was inverted; fixed
- Nav bar: `v8.0` → `v1.4.7`

### Security
- WebSocket inject: role guard — only admin/analyst may inject via WS

### API
- `/api/admin/sigma/validate`: calls `parseSigmaYaml` + `validateSigmaRule`
- `/api/admin/entity-risk/summary`: calls `getTopRiskyEntities(db)`, returns `entity` field
- `/api/admin/ocsf/map-sample`: normalizes body to event object before mapping
- `/api/admin/version`: unified to 1.4.7

### Version Consistency
All four surfaces now show `1.4.7`: `package.json`, dashboard badge, installer `RELEASE_VERSION`, API.

---

## New Modules

### Multi-Format Event Parser (`app/lib/event-parser.js`)
CEF (0-10 severity scale), LEEF (tab/custom separator), Windows Event XML (EventID→ECS), JSON, Palo Alto CSV, RFC 3164/5424. Wired into every ingest path and the `/api/v2/ingest/cef` + `/api/v2/ingest/batch` endpoints.

### Asset & Identity Enrichment (`app/lib/enrichment-pipeline.js`)
In-memory cache rebuilt every 5 min. Enriches every event with: `asset_criticality`, `asset_owner`, `asset_bu`, `asset_env`, `identity_dept`, `identity_title`, `identity_mfa`. Risk score adjusted by criticality factor (0.2×–2.0×). No-MFA auth events get +5 risk. API: `/api/v2/assets`, `/api/v2/identities`, `/api/v2/enrichment/stats`.

### WORM HMAC Chain (`app/lib/worm-chain.js`)
HMAC-SHA256 cryptographic event chain. Key auto-generated at `~/.siem-hmac-key` (mode 0600). Anchors every 1000 events. `verifyChain()` walks full ledger and reports exact break point. API: `/api/v2/worm/status`, `/api/v2/worm/verify`, `/api/v2/worm/verify-event/:id`.

### Playbook Engine (`app/lib/playbook-engine.js`)
4 built-in playbooks in guarded mode: SSH Brute Force Auto-Response, Malware Indicator Response, IOC Match Escalation, High-Risk User Activity. Trigger types: alert_rule, alert_severity, risk_threshold, ioc_match, manual. Step types: create_case, block_ip, disable_account, isolate_host, collect_forensics, add_ioc, enrich_case, notify_slack, wait, webhook. API: `/api/v2/playbooks`, `/api/v2/playbooks/:id/run`.

### Response Actions Engine (`app/lib/response-actions.js`)
Three modes: simulation (default), guarded (approval-gated), live (immediate). Real actions: `iptables` block/unblock, `usermod -L/-U`, `pkill -u`, forensic collection. Every action records `rollback_cmd`. API: `/api/v2/response/pending-approvals`, `/api/v2/response/approve/:id`, `/api/v2/response/rollback/:id`.

### Cloud Connectors (`app/lib/cloud-connectors.js`)
Real HTTP: AWS SigV4 + CloudTrail, Azure OAuth2 + Log Analytics, M365 OAuth2 + Office Management API. Added: `startPolling()` scheduler, `testConnector()`, `pollOnce()`. API: `/api/v2/cloud/connectors` CRUD.

---

## Test Suite

| Script | Purpose |
|--------|---------|
| `test-all-regress.sh` | **Primary** — 19 sections, 516 lines, JSON artifacts |
| `test-smoke.sh` | Fast pre-flight (< 30s) |
| `test-ui-e2e.sh` | Playwright browser automation |
| `test-destructive.sh` | Wipe tests (`DESTRUCTIVE=true` required) |
| `test-all*.sh` | Legacy wrappers → redirect to `test-all-regress.sh` |

## Known Limitations

- Response live mode requires host `sudo` access for iptables/usermod
- Cloud connectors: code is real; production credential testing pending
- WORM chain: HMAC ledger is real; S3/GCS anchoring is roadmap
- Browser E2E: script ready; Playwright must be installed separately
- Multi-node / scale-out: requires separate project (SQLite is single-node)
