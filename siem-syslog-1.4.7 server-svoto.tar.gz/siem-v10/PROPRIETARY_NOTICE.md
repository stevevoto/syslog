# Proprietary Notice

Except for third-party open-source components and their licenses, this SIEM product codebase,
custom workflows, templates, scripts, UI behavior, packaging, and product-specific logic are
intended for proprietary internal/commercial use by the owner of this codebase.

Do not remove or alter third-party license notices. Review dependency licenses before
redistribution.

This file is a product notice, not legal advice.
