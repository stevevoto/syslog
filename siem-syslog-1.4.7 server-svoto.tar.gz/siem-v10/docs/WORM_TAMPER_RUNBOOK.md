# WORM Chain Integrity — Operator Runbook

## Overview
The SIEM uses a HMAC-SHA256 cryptographic chain where every event is signed and linked to the previous event's hash. If any event is modified, deleted, or inserted out of order, the chain breaks and `POST /api/v2/worm/verify` will return `ok: false` with a `tamper_report`.

This runbook covers detection, containment, investigation, and notification procedures.

---

## Step 1 — Detect

The chain is verified:
- On demand: `POST /api/v2/worm/verify`
- Via the Admin panel → WORM section → Verify button
- Via scheduled job (add to cron, recommended nightly)

**Cron example:**
```bash
0 3 * * * ADMIN_USER=admin ADMIN_PASS=secret \
  curl -sk -c /tmp/worm-c.cookie -b /tmp/worm-c.cookie \
  -X POST https://localhost:18080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"secret"}'
curl -sk -c /tmp/worm-c.cookie -b /tmp/worm-c.cookie \
  -X POST https://localhost:18080/api/v2/worm/verify \
  | python3 -c "import json,sys; d=json.load(sys.stdin); exit(0 if d['ok'] else 1)"
```

A violation creates a **SIEM alert** with `severity: EMERG` and `rule_name: WORM Chain Integrity Violation` — this will appear in the live stream as a critical alert.

---

## Step 2 — Contain (First 15 Minutes)

**Do NOT modify the database.** Modification destroys forensic evidence.

```bash
# 1. Immediately make a forensic copy of the database
sudo cp /var/lib/siem-syslog/siem.db /forensics/siem-evidence-$(date +%Y%m%d-%H%M%S).db

# 2. Note the broken_at event ID from the tamper report
# 3. Stop accepting new ingest (optional — prevents ongoing evidence contamination)
sudo systemctl stop siem-syslog
```

---

## Step 3 — Investigate

### 3a. Get the tamper report
```bash
curl -sk -b /tmp/worm-c.cookie \
  -X POST https://localhost:18080/api/v2/worm/verify \
  -H 'Content-Type: application/json' \
  | python3 -m json.tool > /forensics/tamper-report.json
```

The report includes:
- `broken_at_event_id` — the first event where the chain breaks
- `events_verified_before_break` — how many events were clean before the break
- `context.event_at_break` — the host, severity, message, and timestamp of the modified event
- `context.events_before` / `context.events_after` — surrounding events for timeline reconstruction

### 3b. Compare against external anchors
```bash
# If an S3 or HTTP anchor backend is configured:
curl -sk -b /tmp/worm-c.cookie \
  -X POST https://localhost:18080/api/v2/worm/verify-external \
  | python3 -m json.tool > /forensics/external-anchor-comparison.json
```

A mismatch between local and external anchors confirms external tampering vs internal DB modification.

### 3c. Check access logs
```bash
# Review who accessed the database file
sudo ausearch -f /var/lib/siem-syslog/siem.db --start $(date -d '7 days ago' '+%m/%d/%Y') 2>/dev/null || true

# Check audit log in SIEM
curl -sk -b /tmp/worm-c.cookie \
  "https://localhost:18080/api/admin/audit?limit=500" | python3 -m json.tool > /forensics/audit-log.json

# Check OS-level logs
sudo journalctl --since "7 days ago" | grep -E "siem|sqlite" > /forensics/os-logs.txt
```

### 3d. Identify the modified event
```bash
# Pull the 10 events around the break point
EVENT_ID=<broken_at_event_id>
curl -sk -b /tmp/worm-c.cookie \
  "https://localhost:18080/api/events?limit=10" | python3 -m json.tool
```

---

## Step 4 — Classify

| Scenario | Indicator | Action |
|----------|-----------|--------|
| Internal accidental modification | DB tool access in audit log, single break point | Fix process controls, restore from backup |
| Malicious insider | Access during off-hours, suspicious audit entries | Escalate to legal, preserve evidence chain |
| External attacker | Break point correlates with security incident | Treat as breach, notify CISO, consider notification obligations |
| Hardware failure / corruption | Multiple break points, IO errors in OS logs | Restore from backup, verify backup integrity |

---

## Step 5 — Escalate

For any confirmed or suspected malicious tampering:

1. **Immediately notify:** CISO / Security Operations Manager
2. **Do not restore** until forensic investigation is complete
3. **Preserve evidence chain:** hash the forensic DB copy: `sha256sum /forensics/siem-evidence-*.db`

---

## Step 6 — Regulatory Notification

| Regulation | Requirement | Timeline |
|------------|-------------|----------|
| **NIS2 (EU 2022/2555)** Art. 23 | Report significant incidents to national CSIRT | Early warning: 24h, Full report: 72h |
| **DORA (EU 2022/2554)** Art. 17 | Report major ICT incidents to competent authority | Initial: ASAP, Intermediate: within 72h, Final: 1 month |
| **GDPR Art. 33** | Report personal data breaches to supervisory authority | Within 72h of awareness |
| **HIPAA §164.412** | Report breach to HHS and affected individuals | Within 60 days of discovery |
| **SOC 2** | Document incident for auditor | Per your audit engagement agreement |

---

## Step 7 — Recover

```bash
# Restore from last verified backup
sudo systemctl stop siem-syslog
sudo cp /var/lib/siem-syslog/backups/siem-YYYY-MM-DD.db /var/lib/siem-syslog/siem.db

# Verify chain after restore
sudo systemctl start siem-syslog
curl -sk -b /tmp/worm-c.cookie \
  -X POST https://localhost:18080/api/v2/worm/verify | python3 -m json.tool
```

---

## Tamper Simulation Test (for validation/training)

**Only run on non-production systems.**

```bash
# 1. Get a recent event ID
EVENT_ID=$(curl -sk -b /tmp/worm-c.cookie "https://localhost:18080/api/events?limit=1" \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['events'][0]['id'])")

# 2. Directly modify the event in SQLite (simulates tampering)
sqlite3 /var/lib/siem-syslog/siem.db \
  "UPDATE events SET message='[TAMPERED] ' || message WHERE id=$EVENT_ID"

# 3. Run verification — should detect the break
curl -sk -b /tmp/worm-c.cookie \
  -X POST https://localhost:18080/api/v2/worm/verify \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('Tamper detected:', not d['ok'], 'broken_at:', d.get('broken_at'))"

# 4. Restore from backup to clean state
```

---

## Key API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v2/worm/status` | GET | Chain status (enabled, signed_events, anchors) |
| `/api/v2/worm/verify` | POST | Walk and verify full chain |
| `/api/v2/worm/verify-event/:id` | GET | Spot-check single event |
| `/api/v2/worm/verify-external` | POST | Compare local anchors to S3/HTTP backend |
| `/api/v2/worm/configure-anchor` | POST | Set S3/HTTP external anchor backend |
| `/api/v2/worm/test-anchor` | POST | Write a test anchor to external backend |

