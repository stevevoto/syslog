# LDAP / Active Directory Identity Sync — Validation Guide

## Required AD Permissions

The SIEM service account needs only **read** access:

```
CN=siem-svc,OU=ServiceAccounts,DC=corp,DC=example,DC=com
```

Required AD permissions:
- `Read` on the user OU and all child OUs
- `List Contents` on OUs containing users
- `Read All Properties` on user objects
- `Read Group Membership` — for risk tier mapping

Create the service account in PowerShell:
```powershell
New-ADUser -Name "siem-svc" -SamAccountName "siem-svc" `
  -Path "OU=ServiceAccounts,DC=corp,DC=example,DC=com" `
  -AccountPassword (ConvertTo-SecureString "StrongP@ss!" -AsPlainText -Force) `
  -Enabled $true -PasswordNeverExpires $true

# Grant read permissions on user OU
$ou = "OU=Users,DC=corp,DC=example,DC=com"
$acl = Get-Acl "AD:$ou"
$identity = "corp\siem-svc"
$adRights = [System.DirectoryServices.ActiveDirectoryRights]::ReadProperty -bor `
            [System.DirectoryServices.ActiveDirectoryRights]::ListChildren -bor `
            [System.DirectoryServices.ActiveDirectoryRights]::GenericRead
$acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
  $identity, $adRights, "Allow", [guid]::empty, "Descendents", [guid]::empty))
Set-Acl -Path "AD:$ou" -AclObject $acl
```

## Filter Examples

### Active users only (AD)
```
(&(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))
```

### Active users in specific OU (OpenLDAP)
```
(&(objectClass=inetOrgPerson)(uid=*))
```

### Users with email address
```
(&(objectClass=user)(mail=*)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))
```

### Service accounts excluded
```
(&(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(!(description=*service*)))
```

## Common Errors and Fixes

| Error | Meaning | Fix |
|-------|---------|-----|
| `LDAP bind failed (49): invalidCredentials` | Wrong password or DN format | Check bindDn uses CN=, not just username. Format: `CN=siem-svc,OU=SA,DC=corp,DC=com` |
| `LDAP bind failed (34): invalidDNSyntax` | bindDn format is wrong | Use full Distinguished Name, not `siem-svc@corp.com` |
| `LDAP search failed (32): noSuchObject` | baseDn OU doesn't exist | Verify the OU exists: `ldapsearch -x -H ldap://dc01 -D "CN=siem-svc,..." -W -b "DC=corp,DC=com" "(ou=Users)"` |
| `LDAP search failed (50): insufficientAccessRights` | Service account lacks read permission | Grant Read on the baseDn OU (see PowerShell above) |
| `LDAP TLS certificate error` | Self-signed cert | Add `"tlsRejectUnauthorized": false` to ldapSync config |
| `LDAP connect timeout` | Firewall blocking port 389/636 | Open TCP 389 (LDAP) or 636 (LDAPS) from SIEM to DC |
| `sizeLimitExceeded` | More users than pageSize limit | Increase `pageSize` in config (default 500) or use more specific filter |

## Validation Steps

### 1. Test connectivity from SIEM host
```bash
# Test TCP connectivity
nc -zv dc01.corp.com 389     # LDAP
nc -zv dc01.corp.com 636     # LDAPS

# Test LDAP bind (requires ldap-utils)
ldapsearch -x -H ldap://dc01.corp.com \
  -D "CN=siem-svc,OU=SA,DC=corp,DC=com" \
  -W -b "OU=Users,DC=corp,DC=com" \
  -s base "(objectClass=*)" dn
```

### 2. Use the SIEM built-in test
```bash
curl -sk -b /tmp/cookie -c /tmp/cookie \
  -X POST https://localhost:18080/api/v2/ldap/test \
  -H "Content-Type: application/json" \
  -d '{
    "url": "ldaps://dc01.corp.com:636",
    "bindDn": "CN=siem-svc,OU=ServiceAccounts,DC=corp,DC=com",
    "bindPassword": "your-password",
    "baseDn": "OU=Users,DC=corp,DC=com"
  }' | python3 -m json.tool
```

Expected response on success:
```json
{
  "ok": true,
  "stage": "search",
  "message": "Connection OK — baseDn reachable, 1 test entry returned"
}
```

### 3. Dry-run sync (no DB writes)
```bash
curl -sk -b /tmp/cookie \
  -X POST https://localhost:18080/api/v2/ldap/sync \
  -H "Content-Type: application/json" \
  -d '{
    "url": "ldaps://dc01.corp.com:636",
    "bindDn": "CN=siem-svc,OU=ServiceAccounts,DC=corp,DC=com",
    "bindPassword": "your-password",
    "baseDn": "OU=Users,DC=corp,DC=com",
    "dryRun": true
  }' | python3 -m json.tool
```

Expected: `synced: N` with `dry_run: true` — no identities written.

### 4. Real sync and verify enrichment
```bash
# Sync
curl -sk -b /tmp/cookie -X POST https://localhost:18080/api/v2/ldap/sync \
  -H "Content-Type: application/json" \
  -d '{"url":"ldaps://dc01.corp.com","bindDn":"...","bindPassword":"...","baseDn":"..."}' \
  | python3 -m json.tool

# Verify identities imported
curl -sk -b /tmp/cookie "https://localhost:18080/api/v2/identities?limit=5" | python3 -m json.tool

# Force cache rebuild
curl -sk -b /tmp/cookie -X POST https://localhost:18080/api/v2/enrichment/rebuild | python3 -m json.tool

# Inject a test event with known username and check enrichment
curl -sk -b /tmp/cookie -X POST https://localhost:18080/api/inject \
  -H "Content-Type: application/json" \
  -d '{"raw":"<36>Apr 06 12:00:00 auth-host sshd: Failed password for alice from 185.220.101.45 port 22"}'

# Find the event and check identity fields
curl -sk -b /tmp/cookie "https://localhost:18080/api/events?q=alice&limit=1" \
  | python3 -c "import json,sys; e=json.load(sys.stdin)['events'][0]; print('dept:', e.get('identity_dept'), 'mfa:', e.get('identity_mfa'), 'risk:', e.get('identity_risk'))"
```

## Risk Tier Configuration

```json
{
  "ldapSync": {
    "riskTierMap": {
      "Domain Admins": "privileged",
      "Enterprise Admins": "privileged",
      "Schema Admins": "privileged",
      "C-Suite": "executive",
      "Executives": "executive",
      "IT Security": "elevated",
      "Service Accounts": "elevated"
    },
    "privilegedGroups": ["Domain Admins", "Enterprise Admins", "Administrators"],
    "mfaAttribute": "extensionAttribute1",
    "mfaValue": "MFA_ENROLLED"
  }
}
```

## Large Directory Handling

For directories with >10,000 users:
1. Use a more specific `baseDn` targeting only relevant OUs
2. Increase `syncIntervalMinutes` to reduce frequency
3. Use a narrower `filter` to exclude service accounts, disabled users
4. The sync will log `sizeLimitExceeded` if too many results — add filter conditions

## Azure AD Connect + LDAP

If using Azure AD Connect for hybrid identity:
- LDAP to on-premises AD works as described above
- For cloud-only Azure AD users, use the Okta/Azure AD SCIM sync instead
- `sAMAccountName` will be populated for synced users; cloud-only users need `userPrincipalName`

