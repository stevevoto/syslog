
# CMDB Validation Guide — siem-v10.3

## Purpose
Validate CMDB / asset registry synchronization using file, URL, or inline JSON.

## Required checks
1. Configure source with `/api/v2/cmdb/configure`
2. Run `/api/v2/cmdb/test`
3. Run `/api/v2/cmdb/sync`
4. Confirm imported assets via `/api/v2/assets`
5. Confirm at least one event receives higher risk based on criticality
