# SIEM Syslog Command Center — Administrator Guide v1.4.7

This guide covers installation, configuration, daily operations, and troubleshooting.
For feature scope and support boundaries, see `COMMERCIAL_SCOPE.md`.

---

## 1. Installation

### Supported platforms
- Ubuntu 20.04 LTS, 22.04 LTS, 24.04 LTS
- 64-bit x86. Minimum 2 CPU, 4 GB RAM, 50 GB disk.
- Node.js 18 or 20 (installed by installer if missing)

### Install
```bash
sudo bash install.sh
```

The installer:
1. Installs Node.js 20 if not present
2. Installs npm dependencies in `app/`
3. Creates data directory at `/var/lib/siem-syslog/`
4. Creates systemd service `siem-syslog`
5. Starts the service
6. Opens firewall ports (if ufw is active)

### Create first admin
```bash
node app/add-admin.js admin YOUR_STRONG_PASSWORD
```

### Validate
```bash
bash tests/test-smoke.sh
```

### Ports used
| Port | Protocol | Purpose |
|------|----------|---------|
| 18080 | TCP | HTTP dashboard and REST API |
| 55140 | UDP | Syslog ingest |
| 55141 | TCP | Syslog ingest |
| 6514  | TCP/TLS | Syslog ingest (encrypted) |

---

## 2. Configuration

### Config file
`/var/lib/siem-syslog/config.json` (auto-created on first start with defaults)

### Key settings
```json
{
  "server": {
    "httpPort": 18080,
    "udpPort": 55140,
    "tcpPort": 55141,
    "bindAddress": "0.0.0.0"
  },
  "database": {
    "path": "/var/lib/siem-syslog/siem.db"
  },
  "auth": {
    "enabled": true,
    "sessionSecret": "auto-generated"
  },
  "tlsSyslog": {
    "enabled": false,
    "port": 6514,
    "certFile": "/etc/ssl/siem/server.crt",
    "keyFile": "/etc/ssl/siem/server.key"
  },
  "geoip": {
    "enabled": true
  },
  "worm": {
    "enabled": true
  }
}
```

### Enabling TLS syslog
```bash
# Generate self-signed cert
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/siem/server.key \
  -out /etc/ssl/siem/server.crt \
  -subj "/CN=$(hostname)"

# Add to config.json
{
  "tlsSyslog": {
    "enabled": true,
    "port": 6514,
    "certFile": "/etc/ssl/siem/server.crt",
    "keyFile": "/etc/ssl/siem/server.key"
  }
}

sudo systemctl restart siem-syslog
```

---

## 3. Daily Operations

### Service management
```bash
sudo systemctl status siem-syslog    # check status
sudo systemctl restart siem-syslog   # restart
sudo journalctl -u siem-syslog -f    # follow logs
```

### Backup
Backups are full database snapshots.
```bash
# Trigger via API
curl -sk -b /tmp/cookie -X POST https://localhost:18080/api/admin/backup/run

# Via Admin panel: Admin → Backup Now

# Backups stored at: /var/lib/siem-syslog/backups/
ls /var/lib/siem-syslog/backups/
```

**Recommendation:** Run nightly backup via cron:
```bash
# /etc/cron.d/siem-backup
0 2 * * * root curl -sk -b /var/lib/siem-syslog/.session-cookie \
  -X POST https://localhost:18080/api/admin/backup/run > /dev/null
```

### Restore
```bash
sudo systemctl stop siem-syslog
sudo cp /var/lib/siem-syslog/backups/BACKUP_FILE.db /var/lib/siem-syslog/siem.db
sudo systemctl start siem-syslog
```

Verify after restore:
```bash
curl -sk https://localhost:18080/api/status | python3 -m json.tool
```

### Disk management
The DB grows ~100MB per million events (typical). Plan retention accordingly.

Set event retention in Admin panel → Storage → Hot Tier Days.
Or via API:
```bash
curl -sk -b /tmp/cookie -X POST https://localhost:18080/api/v11/storage/policy \
  -H 'Content-Type: application/json' \
  -d '{"hotDays":30,"warmDays":90}'
```

Monitor disk usage:
```bash
df -h /var/lib/siem-syslog/
du -sh /var/lib/siem-syslog/siem.db
```

### WORM chain
The HMAC chain key is stored at `~/.siem-hmac-key` (mode 0600) for the service account.

**Back up this key separately.** If the key is lost, the chain cannot be verified.
```bash
# Back up the key
sudo cp ~/.siem-hmac-key /secure-backup-location/siem-hmac-key-$(date +%Y%m%d)

# Verify chain integrity
curl -sk -b /tmp/cookie -X POST https://localhost:18080/api/v2/worm/verify | python3 -m json.tool
```

See `docs/WORM_TAMPER_RUNBOOK.md` for incident procedures.

---

## 4. Identity Integration

### Option A: Local registry (default)
Add assets and identities directly via Admin panel or API.
No external dependencies. Always available.

### Option B: LDAP / Active Directory (Preview)
See `docs/LDAP_VALIDATION_GUIDE.md` for full setup.

Quick start:
1. Admin panel → Identity → LDAP/AD section
2. Enter LDAP URL, Bind DN, Bind Password, Base DN
3. Click Test Connection — should return `stage: search` success
4. Click Sync Now — identities loaded
5. Check Admin panel → Identity → Stats to confirm

### Option C: Okta / Azure AD (Preview)
1. Admin panel → Identity → Okta / Azure AD section
2. Select provider (Okta or Azure AD)
3. Enter credentials
4. Click Test Connection
5. Click Sync Now

See `COMMERCIAL_SCOPE.md` for supported identity patterns and known limits.

---

## 5. Cloud Connectors (Preview)

1. Admin panel → Cloud tab
2. Each connector has: Test, Poll Now, Enable/Disable buttons
3. Connector health shows: last poll time, event count, error message

For credential setup see provider-specific docs:
- **AWS CloudTrail**: IAM user with `cloudtrail:LookupEvents`, `sts:GetCallerIdentity`
- **Azure Monitor**: Service principal with Log Analytics Reader on workspace
- **M365**: App registration with `ActivityFeed.Read`

After configuring credentials, always run Test before enabling.

---

## 6. Response Actions (Preview)

Response actions run in three modes:
- **Simulation** (default): Logged and broadcast. No system changes.
- **Guarded**: Creates an approval request. Operator must approve in the Response panel.
- **Live**: Real commands execute immediately. **Requires sudo on the SIEM host.**

### Setting up live mode
```bash
# Grant SIEM service account specific sudo rights (recommended over full sudo)
sudo visudo -f /etc/sudoers.d/siem-response
```

Add:
```
siem-user ALL=(ALL) NOPASSWD: /sbin/iptables, /usr/sbin/usermod, /usr/bin/pkill, /usr/bin/passwd, /bin/mv, /bin/cp, /bin/chmod, /usr/bin/chattr, /bin/mkdir
```

### Approving actions
1. Navigate to Response panel
2. Pending Approvals section shows waiting actions
3. Click ✓ Approve to execute or ✗ Reject to cancel
4. All approvals are recorded in the audit log

---

## 7. Compliance Reports

Generate evidence reports for compliance frameworks:
```bash
# Via browser: Admin panel → Compliance Reports

# Via API
curl -sk -b /tmp/cookie "https://localhost:18080/api/reports/compliance/soc2?hours=720" | python3 -m json.tool
curl -sk -b /tmp/cookie "https://localhost:18080/api/reports/compliance/iso27001?hours=720" | python3 -m json.tool
curl -sk -b /tmp/cookie "https://localhost:18080/api/reports/compliance/nis2" | python3 -m json.tool
curl -sk -b /tmp/cookie "https://localhost:18080/api/reports/compliance/dora" | python3 -m json.tool
```

**Important:** Compliance reports pull evidence from the SIEM's own event DB. They do not pull from external systems. The `evidence_coverage_pct` tells you how many controls have measurable data in the configured time window.

---

## 8. Troubleshooting

### Service not starting
```bash
journalctl -u siem-syslog --no-pager | tail -50
node --check /opt/siem-syslog/app/server-v3.js  # syntax check
ls -la /var/lib/siem-syslog/  # check data dir permissions
```

### No events appearing
```bash
# Test UDP ingest
echo "<46>$(date) testhost syslog: test message" | nc -u localhost 55140

# Test TCP ingest
echo "<46>$(date) testhost syslog: test message" | nc localhost 55141

# Check firewall
sudo ufw status
sudo iptables -L INPUT | grep -E "55140|55141"
```

### Login not working
```bash
# Reset or create admin account
node app/add-admin.js admin NEW_SECURE_PASSWORD
```

### High disk usage
```bash
du -sh /var/lib/siem-syslog/siem.db
# Set retention or archive old events via Admin → Storage
```

### WORM chain broken
Follow `docs/WORM_TAMPER_RUNBOOK.md` immediately. Do not modify the database.

### Cloud connector errors
```bash
# Check connector status
curl -sk -b /tmp/cookie "https://localhost:18080/api/v2/cloud/metrics" | python3 -m json.tool
# Check last_error field for specific message
```

### LDAP sync failing
Run `POST /api/v2/ldap/test` with your credentials — it returns `stage` (connect/bind/search) and a `hint`.
See `docs/LDAP_VALIDATION_GUIDE.md` for full error table.

---

## 9. Useful API commands (with session cookie)

```bash
# Login and save cookie
curl -sk -c /tmp/siem.cookie -b /tmp/siem.cookie \
  -X POST https://localhost:18080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"yourpassword"}'

# Status
curl -sk https://localhost:18080/api/status

# Recent events
curl -sk -b /tmp/siem.cookie "https://localhost:18080/api/events?limit=10" | python3 -m json.tool

# Run backup
curl -sk -b /tmp/siem.cookie -X POST https://localhost:18080/api/admin/backup/run

# WORM verify
curl -sk -b /tmp/siem.cookie -X POST https://localhost:18080/api/v2/worm/verify

# Compliance report
curl -sk -b /tmp/siem.cookie "https://localhost:18080/api/reports/compliance/soc2" | python3 -m json.tool
```

---

## 10. Support escalation

Before opening a support ticket, collect:
1. `journalctl -u siem-syslog --no-pager > siem-service.log`
2. `curl -sk -b /tmp/siem.cookie https://localhost:18080/api/admin/diagnostics > diagnostics.json`
3. `curl -sk -b /tmp/siem.cookie https://localhost:18080/api/admin/version > version.json`
4. DB size: `du -sh /var/lib/siem-syslog/siem.db`
5. Event count: `curl -sk -b /tmp/siem.cookie "https://localhost:18080/api/stats"`

Known limits to check first:
- Max ingest rate: ~5,000 EPS
- DB practical limit: ~10GB
- Backup: single file only
- Live response actions: require sudo on Linux

