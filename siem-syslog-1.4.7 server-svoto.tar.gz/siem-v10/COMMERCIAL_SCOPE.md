# SIEM Syslog Command Center — Commercial Scope Declaration v1.4.7

This document is the authoritative "contract" between engineering, product, and support.
It defines exactly what is supported, what is preview, and what is not in scope for v1.4.7.

**Before making any commercial claim, verify it against this document.**

---

## Tier Definitions

| Tier | Meaning | Support obligation |
|------|---------|-------------------|
| **Supported** | Tested, documented, regression-gated. Field-reachable without escalation. | Fix critical bugs within SLA. Document known limits. |
| **Preview** | Feature exists but not fully hardened. Needs customer validation. | Best-effort support. Label clearly in UI and docs. Must not be marketed as production-ready. |
| **Foundation** | Code exists. Not yet validated against real external systems. | No support obligation. Technical preview only. |
| **Not in scope** | Not present or not intended for v1.4.7. | Do not mention in sales or marketing materials. |

---

## Section 1 — Core Platform (All Supported)

| Feature | Notes |
|---------|-------|
| Syslog ingest — UDP/TCP | Port 55140/55141. Max tested: ~5,000 EPS single-node |
| Syslog ingest — TLS | Port 6514. Self-signed cert supported. Certificate rotation documented. |
| HTTP ingest API | `/api/inject` and `/api/v2/ingest/cef` + batch up to 500 events |
| Multi-format parser | CEF (0-10 severity, cs1-cs6 custom fields), LEEF, Windows Event XML + Sysmon 1-25, JSON, Palo Alto CSV, RFC 3164/5424 |
| Live event stream | WebSocket-based live tail. Tested to 1,000 concurrent events. |
| Dashboard and search | Full-text search, severity filter, host filter, time range. |
| GeoIP enrichment | MaxMind-style lat/lon. Private IPs excluded. 24-hr world map. |
| ECS normalization | ecs_category, ecs_type, ecs_outcome, ecs_action on all events. |
| Threat detection rules | 14 built-in rules. Regex + threshold-based. |
| Correlation rules | 5 built-in rules including brute-force, lateral movement. |
| IOC / threat intel | Add/list IOCs (IP, domain, hash, URL, email). Auto-match on ingest. |
| UEBA anomaly detection | Baseline + deviation per host/user per hour. |
| MITRE ATT&CK heatmap | Technique-to-event mapping. |
| Case management | Create, update (priority/status/notes), close, assign. Push to Jira/ServiceNow. |
| Reports and export | PDF (30-day summary), CSV, NDJSON. |
| Compliance summary | Single-page evidence summary across all control families. |
| Compliance report templates | SOC 2 (10 controls), ISO 27001 (7 controls), NIS2 (8 controls), DORA (7 controls). Evidence pulled live from DB. |
| Backup and restore | DB backup with timestamp. List backups. Restore procedure documented. |
| Authentication | Username/password. bcrypt hashed. Session cookie (httpOnly, SameSite=Strict). |
| Role-based access | admin, analyst, viewer. Enforced on all routes. |
| Audit log | All admin actions logged with user, IP, action, outcome. |
| Demo mode | Populates synthetic events. Safe for demos and QA. |
| Diagnostics | 26 diagnostic checks. Health endpoint. Version API. |
| Admin panel | Full configuration UI for all admin functions. |
| Themes | 11 UI themes. |
| OpenAPI / Swagger | 56 routes documented. Available at `/api/docs`. |

---

## Section 2 — Preview Features

These features are in the product and may be used by customers with appropriate expectations. They are labeled **Preview** in the UI and docs. Support is best-effort.

| Feature | Status | What is real | What still needs proof |
|---------|--------|-------------|----------------------|
| Asset registry + enrichment | Preview | Local SQLite registry. Risk score adjusted by criticality. `/api/v2/assets` CRUD. | No enterprise CMDB sync. Self-service only. |
| Identity registry + enrichment | Preview | Local registry. MFA flag, department, risk tier on events. `/api/v2/identities` CRUD. | No live LDAP/Okta/Azure sync enabled out of box. |
| LDAP / AD identity sync | Preview | RFC 4511 BER client. Error classification. Dry-run. Paged results. Test endpoint. | Real AD/LDAPS must be validated per customer. Large directories (>10k users) not tested. |
| Okta identity sync | Preview | SCIM-style pull via API. Group membership + risk tier mapping. Pagination. Rate limit handling. | Needs live Okta tenant validation. MFA status requires extra scope. |
| Azure AD / Entra ID sync | Preview | Microsoft Graph API. OAuth2 client credentials. Group membership. | Needs live Azure tenant validation. Nested group depth not tested. |
| WORM HMAC chain | Preview | HMAC-SHA256 per event. Chain verification. Anchors every 1,000 events. Tamper report + EMERG alert. | Not a legally defensible immutable retention system. No object-lock enforcement. |
| WORM external anchoring | Preview | S3 SigV4 PUT and HTTP webhook. `verify-external` comparison endpoint. | No real S3 bucket tested. S3 Object Lock config requires customer setup. |
| Cloud connectors | Preview | AWS CloudTrail SigV4, Azure Log Analytics OAuth2, M365 Graph API. Retry with backoff. Token caching. Metrics + health dashboard. | No live tenant credential testing performed. Credential expiry edge cases not fully proven. |
| Response actions — simulation mode | Supported | All 12 action types. Logs, broadcasts, audit trail. No system changes. | N/A — simulation is safe and fully covered. |
| Response actions — guarded mode | Preview | Approval required before execution. Approval dashboard. Audit trail. Rollback commands stored. | Live commands require host sudo. Full audit trail needs browser validation. |
| Response actions — live mode | Preview | Real iptables, usermod, pkill, passwd, chattr. | Requires sudo on host. Only use on Linux hosts with appropriate tools installed. |
| Playbook automation | Preview | 4 built-in playbooks in guarded mode. Condition evaluator. 12 step types. Run history. | Slack notifications require webhook config. No playbook editor UI yet. |
| Sigma rule engine | Preview | YAML rule parse + match. Validate endpoint. | Not all Sigma condition operators implemented. |
| OCSF v1.1 mapping | Preview | Class mapping for common event types. Map-sample endpoint. | Not full schema coverage. |
| Entity risk scoring | Preview | Score aggregation per entity. Top-risky entities API. | No ML-based scoring. Rule-based only. |
| Storage policy / tiering | Preview | Hot/warm/cold tier definitions. Status API. | No real S3/GCS archival. Local disk only. |

---

## Section 3 — Not In Scope for v1.4.7

Do not market these or include in GA documentation. They may appear as stubs or foundation code but are not customer-ready.

| Item | Reason | Guidance |
|------|--------|----------|
| Enterprise CMDB integration (ServiceNow, Tenable, CrowdStrike) | No finished integration. Local registry only. | Tell customers: "Asset registry is local. CMDB integration is roadmap." |
| Multi-node / Kafka / Elasticsearch backend | SQLite single-node. No clustering. | Tell customers: "Designed for single-node deployments up to ~50M events." |
| True immutable/WORM retention (regulatory grade) | HMAC chain is not S3 Object Lock. No write-once enforcement. | Tell customers: "WORM chain provides tamper detection, not regulatory immutability. Roadmap item." |
| Full CEF parser library (every vendor format) | Parser covers major formats. Vendor-specific edge cases not exhaustively tested. | Tell customers: "Common CEF/LEEF/WinEvent formats are supported. Vendor-specific extensions may require custom mapping." |
| Active Directory Certificate Services (ADCS) integration | Not implemented. | Out of scope. |
| High-availability / active-active deployment | Not implemented. | Out of scope. |
| Kubernetes / container deployment | Not tested. | Out of scope. |
| Multi-tenancy | Not implemented. | Out of scope. |
| GenAI / LLM analyst integration | Not implemented. | Roadmap. |

---

## Section 4 — Known Limits (Supported Features)

These are hard limits that customers must know before deploying.

| Area | Limit | Notes |
|------|-------|-------|
| Single-node ingest | ~5,000 EPS sustained | Higher rates cause DB write contention. SQLite WAL mode helps. |
| Database size | ~10GB practical limit | Query performance degrades above ~50M events. Plan retention policy. |
| WebSocket connections | ~100 concurrent | HTTP/2 not implemented. Each connection is a separate socket. |
| LDAP result set | 5,000 users per sync | Increase `pageSize` for larger directories. |
| Batch ingest | 500 events per call | Use multiple calls for larger batches. |
| Backup | Single file, no incremental | Backup is a full DB snapshot. Plan disk space accordingly. |
| Response live mode | Requires sudo on SIEM host | iptables and usermod require root or equivalent. |
| Cloud connector poll | 5 minute minimum interval | Shorter intervals are rate-limited by providers. |
| Compliance reports | Evidence pulled from local DB only | Does not pull from external systems. |
| WORM key | Stored at `~/.siem-hmac-key` | If the key is lost, chain cannot be re-verified. Back up the key. |

---

## Section 5 — Support Boundaries by Feature

| Feature | Supported on | Not supported on |
|---------|-------------|-----------------|
| Syslog ingest | Ubuntu 20.04, 22.04, 24.04 | Windows, macOS, containers |
| LDAP sync | OpenLDAP 2.4+, Active Directory 2012+ | LDAP over StartTLS (STARTTLS not implemented — use LDAPS port 636) |
| Response live actions | Linux with sudo access | Windows hosts, remote execution over SSH |
| Cloud connectors | Public cloud endpoints | Private/on-premises AWS, Air-gapped networks |
| Browser UI | Chrome 100+, Firefox 100+, Safari 15+ | IE11, old Edge |

---

## Change Log

| Version | Date | Change |
|---------|------|--------|
| v1.4.7 | 2026-04 | Initial commercial scope document |
