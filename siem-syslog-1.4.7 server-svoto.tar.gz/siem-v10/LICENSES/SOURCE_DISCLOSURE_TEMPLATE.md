# Source Disclosure Template

This product contains proprietary code and third-party open-source software.

For third-party components distributed under licenses that require source availability, complete corresponding source code and/or a written offer must be made available in accordance with the terms of the applicable license.

Recommended fields to complete before distribution:

- Product name:
- Product version:
- Binary hash:
- Distribution date:
- Source location / source archive identifier:
- Source offer contact / fulfillment process:
- Retention period for source offer:

Do not use this template as a substitute for license review.
