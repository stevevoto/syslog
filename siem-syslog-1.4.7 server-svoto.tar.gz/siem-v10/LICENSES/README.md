# Third-Party License Texts

This directory is populated by `scripts/generate-compliance-artifacts.py`.

Expected contents after install:

- one subdirectory per package
- copied `LICENSE`, `LICENSE.md`, `LICENSE.txt`, `COPYING`, or `NOTICE` files when present
- `THIRD_PARTY_NOTICES.md` in the compliance output folder

Keep this directory in shipped release bundles whenever you distribute binaries externally.
