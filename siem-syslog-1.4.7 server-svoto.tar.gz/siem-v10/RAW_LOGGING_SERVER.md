# Raw Logging Server Reference

## External listener ports
- UDP syslog: `514`
- TCP syslog: `601`
- TLS syslog: `6514`

## Web and API
- HTTPS dashboard and API: `443`
- HTTP redirect: `80`
- Internal Node app: `127.0.0.1:18080`

## Data locations
- SQLite event database: `/var/lib/siem-syslog/events.db`
- Archive directory: `/var/lib/siem-syslog/archive`
- Report outbox: `/var/lib/siem-syslog/outbox`
- Validation logs: `/var/log/siem-syslog/validation`

## Useful commands
```bash
sudo ss -lntup | egrep ':514|:601|:6514|:18080|:443|:80'
sudo journalctl -u siem-syslog -f
sudo journalctl -u nginx -f
```

## Quick send tests
```bash
logger -n 127.0.0.1 -P 514 -d 'udp test message'
logger -n 127.0.0.1 -P 601 -T 'tcp test message'
```
