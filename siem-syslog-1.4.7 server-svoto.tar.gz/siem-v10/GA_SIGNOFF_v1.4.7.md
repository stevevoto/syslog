# SIEM Syslog Command Center v1.4.7 — GA Release Sign-off

| Item                          | Value                                  |
|-------------------------------|----------------------------------------|
| Product                       | SIEM Syslog Command Center             |
| Version                       | 1.4.7                                  |
| Planning document             | Commercial Readiness Rev 8.0           |
| Build date                    | April 2026                             |
| Primary regression script     | tests/test-all-regress.sh              |
| Primary UI                    | app/public/index.html                  |
| Release notes                 | RELEASE_NOTES_v1.4.7-fixed.md         |
| SHA256 manifest               | SHA256SUMS.txt (20 files)              |

## GA Checklist

- [ ] All version strings match 1.4.7 (package.json, installer, UI, API, test-allv14.sh)
- [ ] `tests/test-all-regress.sh` passes with zero failures on release host
- [ ] `tests/test-smoke.sh` passes as pre-flight check
- [ ] Browser E2E suite passes (or absence documented with Playwright install note)
- [ ] Backup and restore test passes with event-count evidence
- [ ] Demo mode, diagnostics, and reports all pass
- [ ] Feature Support Matrix in Admin panel reflects current capability
- [ ] Preview/Foundation/Simulation labels visible in UI for partial features
- [ ] SHA256SUMS.txt regenerated for this exact build
- [ ] Release evidence folder created: `artifacts/regress/<BUILD_ID>/`

## Module Inventory — v1.4.7

| Module | File | Status | Notes |
|--------|------|--------|-------|
| Core syslog server | app/server-v3.js | Production | UDP/TCP/TLS/HTTP |
| Multi-format parser | app/lib/event-parser.js | Production | CEF, LEEF, WinEvent, JSON, PAN-OS, RFC 3164/5424 |
| v11 Extensions | app/lib/v11-extensions.js | Production | OCSF, Sigma, Entity Risk, Storage, Response, Cloud |
| Asset/Identity Enrichment | app/lib/enrichment-pipeline.js | Preview | Local registry; full CMDB integration is roadmap |
| WORM HMAC Chain | app/lib/worm-chain.js | Preview | Cryptographic ledger; S3/GCS anchoring is roadmap |
| Playbook Engine | app/lib/playbook-engine.js | Preview | 4 built-ins; defaults to guarded mode with approval |
| Response Actions | app/lib/response-actions.js | Preview | sim/guarded/live modes; live requires sudo on host |
| Cloud Connectors | app/lib/cloud-connectors.js | Foundation | Real HTTP/OAuth2/SigV4; needs prod credential test |
| Sigma Engine | app/lib/sigma-engine.js | Preview | Rule parse + match; full YAML spec is roadmap |
| OCSF Mapper | app/lib/ocsf-mapper.js | Preview | v1.1 class mapping; full schema coverage roadmap |
| Entity Risk | app/lib/entity-risk.js | Preview | Score aggregation; full ML scoring is roadmap |
| Storage Policy | app/lib/storage-policy.js | Preview | Hot/warm/cold tiers; real S3/GCS tiering roadmap |

## Feature Tier Declaration

| Tier | Features |
|------|----------|
| **Production** | Syslog ingest (UDP/TCP/TLS), ECS normalization, GeoIP, live stream, auth/RBAC, 14 threat rules, 5 correlation rules, IOC matching, UEBA, MITRE ATT&CK, case management, Jira/ServiceNow push, PDF/CSV/NDJSON export, compliance summary, backup/restore, demo mode, diagnostics, 11 UI themes, multi-format event parser (CEF/LEEF/WinEvent/JSON/PAN-OS) |
| **Preview** | OCSF mapping, Sigma rules, entity risk scoring, asset/identity registry + enrichment, WORM HMAC chain, hot/warm/cold tiering, playbook automation (guarded mode), response actions (guarded mode) |
| **Foundation** | Cloud connectors (AWS/Azure/M365 — real HTTP; needs prod credential validation), CEF batch ingest endpoint, multi-format batch ingest |

## Known Limitations

- Response actions require `sudo` privileges on the host for live mode. Default is simulation.
- Cloud connectors make real HTTP calls when credentials are provided. Credentials are not included.
- Browser E2E (test-ui-e2e.sh) requires Playwright separately: `npm install -g playwright && npx playwright install chromium`
- WORM chain requires write access to `~/.siem-hmac-key` for key persistence.
- Playbook Slack notifications require `config.slack.webhookUrl` and `config.slack.enabled`.

## Sign-off

| Role               | Name                          | Date |
|--------------------|-------------------------------|------|
| Engineering Lead   | _____________________         | ____ |
| QA Lead            | _____________________         | ____ |
| Release Manager    | _____________________         | ____ |
| Product Owner      | _____________________         | ____ |
