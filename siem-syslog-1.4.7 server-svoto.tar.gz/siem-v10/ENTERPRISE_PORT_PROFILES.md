# Port Profiles

## Enterprise
Uses standards-aligned defaults when available:
- UDP syslog: 514/udp
- TCP syslog: 601/tcp
- TLS syslog: 6514/tcp
- Internal app: 18080/tcp
- HTTP redirect: 80/tcp
- HTTPS UI/API: 443/tcp

## Lab
Uses high ports that avoid collisions more often:
- UDP syslog: 55140/udp
- TCP syslog: 55141/tcp
- TLS syslog: 6514/tcp
- Internal app: 18080/tcp
- HTTP redirect: 80/tcp
- HTTPS UI/API: 443/tcp

## Custom
Prompts for each port individually.

The installer checks whether the selected ports are already in use and prompts for alternates if needed.
