# Customer Build and Packaging

## Code protection

Use the customer SEA path to raise the reverse-engineering bar:

```bash
bash scripts/build-customer-sea.sh
```

What it does:
- bundles the Node server into a single executable payload
- strips tests, docs, GitHub workflow files, and source maps from the customer artifact
- leaves only the runtime, public assets, helper scripts, and notices

This improves protection, but does **not** make code unrecoverable on a customer-controlled Linux system.

## One code build, two native packages

- Rocky / RHEL / Alma / CentOS: `.rpm`
- Ubuntu / Debian: `.deb`

```bash
bash packaging/build-native-packages.sh rpm
bash packaging/build-native-packages.sh deb
```
