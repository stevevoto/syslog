        #!/usr/bin/env bash
        set -euo pipefail
        DEST="${1:-/var/backups/siem-syslog/reports}"
        COMPONENT="${2:-summary}"
        mkdir -p "$DEST"
        TS="$(date +%Y%m%d-%H%M%S)"
        OUT="$DEST/${COMPONENT}-${TS}.pdf"
        python3 - <<'PY' "$OUT" "$COMPONENT"
import sys
from pathlib import Path
out=Path(sys.argv[1]); component=sys.argv[2]
# minimal placeholder PDF
pdf = b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<<>>>>endobj\n4 0 obj<</Length 69>>stream\nBT /F1 18 Tf 72 720 Td (SIEM Scheduled Report: " + component.encode() + b") Tj ET\nendstream endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"
out.write_bytes(pdf)
print(out)
PY
