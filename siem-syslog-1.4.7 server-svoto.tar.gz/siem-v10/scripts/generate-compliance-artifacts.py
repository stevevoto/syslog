#!/usr/bin/env python3
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

APP_DIR = Path(sys.argv[1] if len(sys.argv) > 1 else '/opt/siem-syslog')
OUT_DIR = Path(sys.argv[2] if len(sys.argv) > 2 else str(APP_DIR / 'compliance'))
NODE_MODULES = APP_DIR / 'node_modules'
PACKAGE_JSON = APP_DIR / 'package.json'
LICENSE_DIR = OUT_DIR / 'LICENSES'
LICENSE_FILENAMES = ('LICENSE', 'LICENSE.md', 'LICENSE.txt', 'COPYING', 'COPYING.md', 'NOTICE', 'NOTICE.txt')

OUT_DIR.mkdir(parents=True, exist_ok=True)
LICENSE_DIR.mkdir(parents=True, exist_ok=True)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def normalize_license(value) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        if 'type' in value:
            return str(value.get('type', 'UNKNOWN'))
        return json.dumps(value, sort_keys=True)
    if isinstance(value, list):
        values = [normalize_license(v) for v in value]
        return ' AND '.join([v for v in values if v]) or 'UNKNOWN'
    return 'UNKNOWN'


def copy_license_texts(pkg_dir: Path, dest_dir: Path):
    copied = []
    for name in LICENSE_FILENAMES:
        src = pkg_dir / name
        if src.exists() and src.is_file():
            dest_dir.mkdir(parents=True, exist_ok=True)
            target = dest_dir / name
            if not target.exists():
                shutil.copy2(src, target)
            copied.append(str(target.relative_to(OUT_DIR)))
    return copied


def scan_packages():
    packages = []
    if NODE_MODULES.exists():
        for pkg_json in NODE_MODULES.rglob('package.json'):
            try:
                data = json.loads(pkg_json.read_text())
            except Exception:
                continue
            name = data.get('name') or pkg_json.parent.name
            version = str(data.get('version', ''))
            if not name or not version:
                continue
            repo = data.get('repository', '')
            if isinstance(repo, dict):
                repo = repo.get('url', '')
            homepage = data.get('homepage', '')
            lic = normalize_license(data.get('license', data.get('licenses', 'UNKNOWN')))
            pkg_out = LICENSE_DIR / f"{name.replace('/', '__')}@{version}"
            copied = copy_license_texts(pkg_json.parent, pkg_out)
            packages.append({
                'name': name,
                'version': version,
                'license': lic,
                'homepage': homepage or '',
                'repository': repo or '',
                'license_files': copied,
            })
    seen = set()
    uniq = []
    for p in sorted(packages, key=lambda x: (x['name'], x['version'])):
        key = (p['name'], p['version'])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(p)
    return uniq


def esc(value: str) -> str:
    return value.replace('|', '\\|')


def build_notices(packages):
    lines = [
        '# THIRD_PARTY_NOTICES',
        '',
        'Generated from installed package metadata and local license files.',
        '',
        '| Package | Version | License | Homepage | Repository | License Files |',
        '|---|---:|---|---|---|---|',
    ]
    for p in packages:
        lines.append(
            '| {name} | {version} | {license} | {homepage} | {repository} | {license_files} |'.format(
                name=esc(p['name']),
                version=esc(p['version']),
                license=esc(p['license']),
                homepage=esc(p['homepage'] or ''),
                repository=esc(p['repository'] or ''),
                license_files=esc(', '.join(p['license_files'])),
            )
        )
    return '\n'.join(lines) + '\n'


def build_spdx(packages, app_meta):
    created = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    namespace = f"https://example.invalid/spdx/{app_meta.get('name','siem-syslog')}/{app_meta.get('version','0.0.0')}/{int(time.time())}"
    files = []
    for rel in ['server-v3.js', 'add-admin.js', 'package.json']:
        path = APP_DIR / rel
        if path.exists():
            files.append({
                'SPDXID': f"SPDXRef-File-{rel.replace('/', '-').replace('.', '-')}",
                'fileName': f"./{rel}",
                'checksums': [{'algorithm': 'SHA256', 'checksumValue': sha256_file(path)}],
                'licenseConcluded': 'NOASSERTION',
                'licenseInfoInFiles': ['NOASSERTION'],
                'copyrightText': 'NOASSERTION',
            })
    pkgs = []
    relationships = []
    for idx, p in enumerate(packages, start=1):
        spdxid = f"SPDXRef-Package-{idx}"
        pkgs.append({
            'name': p['name'],
            'SPDXID': spdxid,
            'versionInfo': p['version'],
            'downloadLocation': p['repository'] or p['homepage'] or 'NOASSERTION',
            'licenseConcluded': p['license'] or 'NOASSERTION',
            'licenseDeclared': p['license'] or 'NOASSERTION',
            'copyrightText': 'NOASSERTION',
            'externalRefs': [],
        })
        relationships.append({
            'spdxElementId': 'SPDXRef-DOCUMENT',
            'relationshipType': 'DESCRIBES',
            'relatedSpdxElement': spdxid,
        })
    return {
        'spdxVersion': 'SPDX-2.3',
        'dataLicense': 'CC0-1.0',
        'SPDXID': 'SPDXRef-DOCUMENT',
        'name': f"{app_meta.get('name','siem-syslog')} {app_meta.get('version','0.0.0')} SBOM",
        'documentNamespace': namespace,
        'creationInfo': {
            'created': created,
            'creators': ['Tool: generate-compliance-artifacts.py'],
            'licenseListVersion': '3.26',
        },
        'documentDescribes': [p['SPDXID'] for p in pkgs],
        'packages': pkgs,
        'files': files,
        'relationships': relationships,
    }


def write_release_manifest(packages, app_meta):
    manifest = {
        'product': app_meta.get('name', 'siem-syslog'),
        'version': app_meta.get('version', '0.0.0'),
        'generated_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'app_dir': str(APP_DIR),
        'compliance_dir': str(OUT_DIR),
        'package_count': len(packages),
        'artifacts': {
            'notices': 'THIRD_PARTY_NOTICES.md',
            'sbom_spdx': 'sbom.spdx.json',
            'license_texts_dir': 'LICENSES',
        },
        'top_level_hashes': {},
    }
    for rel in ['server-v3.js', 'add-admin.js', 'package.json']:
        path = APP_DIR / rel
        if path.exists():
            manifest['top_level_hashes'][rel] = sha256_file(path)
    (OUT_DIR / 'release-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')


def main():
    app_meta = load_json(PACKAGE_JSON) or {'name': 'siem-syslog', 'version': '0.0.0'}
    packages = scan_packages()
    (OUT_DIR / 'THIRD_PARTY_NOTICES.md').write_text(build_notices(packages))
    (OUT_DIR / 'sbom.spdx.json').write_text(json.dumps(build_spdx(packages, app_meta), indent=2) + '\n')
    write_release_manifest(packages, app_meta)
    summary = {
        'package_count': len(packages),
        'output_dir': str(OUT_DIR),
        'files': ['THIRD_PARTY_NOTICES.md', 'sbom.spdx.json', 'release-manifest.json', 'LICENSES/'],
    }
    (OUT_DIR / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
