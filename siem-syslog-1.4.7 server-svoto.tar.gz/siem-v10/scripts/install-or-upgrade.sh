#!/usr/bin/env bash
set -Eeuo pipefail
BUNDLE_DIR="${BUNDLE_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
APP_DIR="${APP_DIR:-/opt/siem-syslog}"
SERVICE_NAME="${SERVICE_NAME:-siem-syslog}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/siem-syslog-upgrades}"
mkdir -p "$BACKUP_ROOT"
if systemctl list-unit-files --type=service 2>/dev/null | awk '{print $1}' | grep -qx "${SERVICE_NAME}.service"; then
  systemctl stop "$SERVICE_NAME" || true
fi
if [[ -d "$APP_DIR" ]]; then
  ts="$(date +%Y%m%d-%H%M%S)"
  tar -C "$(dirname "$APP_DIR")" -czf "$BACKUP_ROOT/${SERVICE_NAME}-$ts.tgz" "$(basename "$APP_DIR")" || true
fi
if [[ -x "$BUNDLE_DIR/scripts/sync-live-tree.sh" ]]; then
  APP_DIR="$APP_DIR" BUNDLE_DIR="$BUNDLE_DIR" SYNC_DELETE=true "$BUNDLE_DIR/scripts/sync-live-tree.sh"
else
  mkdir -p "$APP_DIR"
  rsync -a --delete "$BUNDLE_DIR/" "$APP_DIR/"
fi
systemctl daemon-reload || true
systemctl enable "$SERVICE_NAME" || true
systemctl restart "$SERVICE_NAME" || true
echo "Installed/upgraded ${SERVICE_NAME} from $BUNDLE_DIR into $APP_DIR"
