#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-/var/backups/siem-syslog}"
mkdir -p "$DEST"
TS="$(date +%Y%m%d-%H%M%S)"
OUT="$DEST/siem-backup-$TS.tar.gz"
tar -czf "$OUT" /etc/siem-syslog /opt/siem-syslog /var/lib/siem-syslog /var/log/siem-syslog 2>/dev/null || true
echo "$OUT"
