#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${APP_DIR:-/opt/siem-syslog}"
if [[ ! -d "$APP_DIR/app" && -d "${SCRIPT_DIR%/scripts}/app" ]]; then
  APP_DIR="${SCRIPT_DIR%/scripts}"
fi
CFG_FILE="${CFG_FILE:-/etc/siem-syslog/config.json}"
VALIDATION_DIR="${VALIDATION_DIR:-/var/log/siem-syslog/validation}"
TEST_SCRIPT="${TEST_SCRIPT:-$APP_DIR/tests/test-all-regress.sh}"
if [[ ! -x "$TEST_SCRIPT" && -x "${SCRIPT_DIR%/scripts}/tests/test-all-regress.sh" ]]; then
  TEST_SCRIPT="${SCRIPT_DIR%/scripts}/tests/test-all-regress.sh"
fi
BASE="${BASE:-http://127.0.0.1}"
ADMIN_USER="${ADMIN_USER:-}"
ADMIN_PASS="${ADMIN_PASS:-}"
STRICT="${STRICT:-false}"
mkdir -p "$VALIDATION_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"
LOG_FILE="$VALIDATION_DIR/post-install-validation-$STAMP.log"
SUMMARY_FILE="$VALIDATION_DIR/post-install-validation-$STAMP.summary"

if [[ -z "$ADMIN_USER" || -z "$ADMIN_PASS" ]]; then
  echo "ADMIN_USER and ADMIN_PASS must be provided." >&2
  exit 2
fi

set +e
cd "$APP_DIR"
ADMIN_USER="$ADMIN_USER" ADMIN_PASS="$ADMIN_PASS" BASE="$BASE" CFG_FILE="$CFG_FILE" \
  "$TEST_SCRIPT" 2>&1 | tee "$LOG_FILE"
rc=${PIPESTATUS[0]}
set -e

pass=$(grep -Eo 'PASS: *[0-9]+' "$LOG_FILE" | tail -1 | grep -Eo '[0-9]+' || true)
fail=$(grep -Eo 'FAIL: *[0-9]+' "$LOG_FILE" | tail -1 | grep -Eo '[0-9]+' || true)
skip=$(grep -Eo 'SKIP: *[0-9]+' "$LOG_FILE" | tail -1 | grep -Eo '[0-9]+' || true)
pass=${pass:-0}
fail=${fail:-0}
skip=${skip:-0}
cat > "$SUMMARY_FILE" <<EOF
validation_log=$LOG_FILE
exit_code=$rc
pass=$pass
fail=$fail
skip=$skip
EOF

echo "Validation log: $LOG_FILE"
echo "Validation summary: $SUMMARY_FILE"

if [[ "$STRICT" == "true" && "$rc" -ne 0 ]]; then
  exit "$rc"
fi
exit 0
