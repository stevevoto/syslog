#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

APP_DIR = Path(sys.argv[1] if len(sys.argv) > 1 else '/opt/siem-syslog')
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else str(APP_DIR / 'compliance' / 'license-policy-report.json'))
NODE_MODULES = APP_DIR / 'node_modules'

DENY_PATTERNS = [re.compile(p, re.I) for p in [r'AGPL', r'GPL-3', r'GPL-2', r'LGPL']]
WARN_PATTERNS = [re.compile(p, re.I) for p in [r'UNKNOWN', r'UNLICENSED', r'Custom', r'SEE LICENSE']]

rows = []
if NODE_MODULES.exists():
    for pkg_json in NODE_MODULES.rglob('package.json'):
        try:
            data = json.loads(pkg_json.read_text())
        except Exception:
            continue
        name = data.get('name') or pkg_json.parent.name
        version = str(data.get('version', ''))
        lic = data.get('license', data.get('licenses', 'UNKNOWN'))
        if isinstance(lic, list):
            lic = ' AND '.join(str(x) for x in lic)
        elif isinstance(lic, dict):
            lic = lic.get('type', json.dumps(lic, sort_keys=True))
        else:
            lic = str(lic)
        status = 'allow'
        if any(p.search(lic) for p in DENY_PATTERNS):
            status = 'review'
        elif any(p.search(lic) for p in WARN_PATTERNS):
            status = 'warn'
        rows.append({'name': name, 'version': version, 'license': lic, 'status': status})

report = {
    'summary': {
        'allow': sum(1 for r in rows if r['status'] == 'allow'),
        'warn': sum(1 for r in rows if r['status'] == 'warn'),
        'review': sum(1 for r in rows if r['status'] == 'review'),
    },
    'packages': sorted(rows, key=lambda r: (r['status'], r['name'], r['version'])),
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['summary'], indent=2))
sys.exit(1 if report['summary']['review'] > 0 else 0)
