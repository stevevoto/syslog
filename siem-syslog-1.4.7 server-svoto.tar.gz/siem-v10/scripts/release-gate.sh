#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# SIEM Syslog Command Center — Release Gate Runner v1.4.7
#
# Runs all 9 commercial release gates from the Engineering Guide v8.2.
# Produces a timestamped evidence folder with JSON summary.
# All 9 gates must pass before releasing to customers.
#
# Usage:
#   BASE=https://127.0.0.1 APP_PORT=18080 \
#   ADMIN_USER=admin ADMIN_PASS=secret \
#   bash scripts/release-gate.sh
#
# Optional:
#   SKIP_INSTALL_TEST=true  (skip clean-install gate if running on existing install)
#   SKIP_E2E=true           (skip browser E2E if Playwright not available)
#   BUILD_ID=my-build-id    (override build identifier)
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

BASE="${BASE:-https://127.0.0.1}"
APP_PORT="${APP_PORT:-18080}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-admin}"
DB_PATH="${DB_PATH:-/var/lib/siem-syslog/siem.db}"
BUILD_ID="${BUILD_ID:-$(date +%Y%m%d-%H%M%S)}"
EVIDENCE_DIR="./release-evidence/${BUILD_ID}"
COOKIE="/tmp/release-gate-$$.cookie"

mkdir -p "${EVIDENCE_DIR}/logs" "${EVIDENCE_DIR}/artifacts"
trap "rm -f '$COOKIE'" EXIT

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
PASS=0; FAIL=0; SKIP=0
GATE_RESULTS=()

gate_pass() { echo -e "${GREEN}  ✅ GATE $1 PASSED${NC}: $2"; ((PASS++)); GATE_RESULTS+=("PASS: Gate $1 — $2"); }
gate_fail() { echo -e "${RED}  ❌ GATE $1 FAILED${NC}: $2"; ((FAIL++)); GATE_RESULTS+=("FAIL: Gate $1 — $2"); }
gate_skip() { echo -e "${YELLOW}  ⏭  GATE $1 SKIPPED${NC}: $2"; ((SKIP++)); GATE_RESULTS+=("SKIP: Gate $1 — $2"); }
info()      { echo -e "${CYAN}     →${NC} $*"; }

api() {
  curl -sk -c "$COOKIE" -b "$COOKIE" -X "$1" "${BASE}:${APP_PORT}${2}" \
    -H "Content-Type: application/json" "${@:3}"
}
hcode() { echo "$1" | grep -o '__S:[0-9]*' | cut -d: -f2; }

echo -e "\n${BOLD}══════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD} SIEM v1.4.7 Release Gate Runner — Build: ${BUILD_ID}${NC}"
echo -e "${BOLD}══════════════════════════════════════════════════════════${NC}"
echo "  Server:    ${BASE}:${APP_PORT}"
echo "  Evidence:  ${EVIDENCE_DIR}"
echo ""

# ─── Gate 1: Clean install ───────────────────────────────────────────────
echo -e "\n${BOLD}Gate 1 · Clean install verification${NC}"
if [[ "${SKIP_INSTALL_TEST:-false}" == "true" ]]; then
  gate_skip 1 "Skipped (SKIP_INSTALL_TEST=true) — run on a fresh OS image to validate"
else
  # Check installer exists and is valid shell
  if bash -n install.sh 2>/dev/null && grep -q "RELEASE_VERSION" install.sh && grep -q "1.4.7" install.sh; then
    info "install.sh syntax OK, RELEASE_VERSION=1.4.7"
    # Check README has install command
    grep -q "bash install.sh" README.md 2>/dev/null && info "README.md has install command"
    gate_pass 1 "install.sh valid, version-stamped, documented in README"
  else
    gate_fail 1 "install.sh missing, invalid, or version mismatch"
  fi
fi

# ─── Gate 2: Upgrade path ────────────────────────────────────────────────
echo -e "\n${BOLD}Gate 2 · Upgrade path — config + data preserved${NC}"
if [[ -f "tests/test-upgrade.sh" ]]; then
  if BASE="$BASE" APP_PORT="$APP_PORT" ADMIN_USER="$ADMIN_USER" ADMIN_PASS="$ADMIN_PASS" \
     bash tests/test-upgrade.sh > "${EVIDENCE_DIR}/logs/upgrade.log" 2>&1; then
    gate_pass 2 "Upgrade test passed — see logs/upgrade.log"
  else
    gate_fail 2 "Upgrade test failed — see logs/upgrade.log"
  fi
else
  # At minimum, verify server starts and data endpoint works
  STATUS=$(api GET /api/status -w '\n__S:%{http_code}' 2>/dev/null)
  [[ "$(hcode "$STATUS")" == "200" ]] && \
    gate_pass 2 "Server running (full upgrade test at tests/test-upgrade.sh — add to pipeline)" || \
    gate_fail 2 "Server not responding at ${BASE}:${APP_PORT}"
fi

# ─── Gate 3: Regression suite ────────────────────────────────────────────
echo -e "\n${BOLD}Gate 3 · Regression suite — test-all-regress.sh${NC}"
# Login first
LOGIN=$(api POST /api/auth/login -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}")
echo "$LOGIN" | grep -q '"ok":true' || { gate_fail 3 "Cannot login — check ADMIN_USER/ADMIN_PASS"; FAIL=$((FAIL+1)); }

REGRESS_LOG="${EVIDENCE_DIR}/logs/regression.log"
if BASE="$BASE" APP_PORT="$APP_PORT" ADMIN_USER="$ADMIN_USER" ADMIN_PASS="$ADMIN_PASS" \
   BUILD_ID="$BUILD_ID" ART_ROOT="${EVIDENCE_DIR}" RUN_UI_E2E=false \
   bash tests/test-all-regress.sh > "$REGRESS_LOG" 2>&1; then
  PASS_COUNT=$(grep -c "✓\|PASS\|pass" "$REGRESS_LOG" 2>/dev/null || echo 0)
  gate_pass 3 "Regression passed (${PASS_COUNT} checks OK) — see logs/regression.log"
else
  FAIL_COUNT=$(grep -c "✗\|FAIL\|fail" "$REGRESS_LOG" 2>/dev/null || echo 0)
  gate_fail 3 "Regression FAILED (${FAIL_COUNT} failures) — see logs/regression.log"
fi

# ─── Gate 4: Browser E2E ─────────────────────────────────────────────────
echo -e "\n${BOLD}Gate 4 · Browser E2E — critical user flows${NC}"
if [[ "${SKIP_E2E:-false}" == "true" ]]; then
  gate_skip 4 "SKIP_E2E=true. Set SKIP_E2E=false and install Playwright for mandatory E2E."
elif command -v npx >/dev/null 2>&1 && npx playwright --version >/dev/null 2>&1; then
  mkdir -p "${EVIDENCE_DIR}/screens"
  if BASE="$BASE" APP_PORT="$APP_PORT" ADMIN_USER="$ADMIN_USER" ADMIN_PASS="$ADMIN_PASS" \
     RUN_UI_E2E=true SCREEN_DIR="${EVIDENCE_DIR}/screens" \
     bash tests/test-ui-e2e.sh > "${EVIDENCE_DIR}/logs/e2e.log" 2>&1; then
    SCREENSHOTS=$(ls "${EVIDENCE_DIR}/screens/"*.png 2>/dev/null | wc -l || echo 0)
    gate_pass 4 "Browser E2E passed. ${SCREENSHOTS} screenshot(s) saved."
  else
    gate_fail 4 "Browser E2E FAILED — see logs/e2e.log and screens/"
  fi
else
  if [[ "${CI:-false}" == "true" ]]; then
  gate_fail 4 "Playwright missing in CI — browser E2E is mandatory for release"
else
  gate_skip 4 "Playwright not installed. Install: npm install -g playwright && npx playwright install chromium"
fi
fi

# ─── Gate 5: Backup and restore ──────────────────────────────────────────
echo -e "\n${BOLD}Gate 5 · Backup and restore${NC}"
BEFORE_EVENTS=$(api GET "/api/events?limit=1" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))" 2>/dev/null || echo 0)
BACKUP_RESULT=$(api POST /api/admin/backup/run -d '{}')
if echo "$BACKUP_RESULT" | grep -q '"ok":true'; then
  BACKUP_FILE=$(echo "$BACKUP_RESULT" | python3 -c "import json,sys; print(json.load(sys.stdin).get('path',''))" 2>/dev/null || echo "")
  info "Backup created: ${BACKUP_FILE}"
  BACKUP_LIST=$(api GET /api/admin/backup/list)
  BACKUP_COUNT=$(echo "$BACKUP_LIST" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('backups',[])))" 2>/dev/null || echo 0)
  [[ "$BACKUP_COUNT" -ge 1 ]] && gate_pass 5 "Backup created + listed (${BACKUP_COUNT} backup files). Manual restore test needed for full validation." || gate_fail 5 "Backup list empty after backup"
else
  gate_fail 5 "Backup failed: $(echo "$BACKUP_RESULT" | python3 -c "import json,sys; print(json.load(sys.stdin).get('error','?'))" 2>/dev/null)"
fi

# ─── Gate 6: Security controls ───────────────────────────────────────────
echo -e "\n${BOLD}Gate 6 · Security controls${NC}"
GATE6_FAIL=0

# Bad password → 401
BAD_LOGIN=$(api POST /api/auth/login -d '{"username":"admin","password":"DEFINITELY_WRONG_PASSWORD_XYZ"}' -w '\n__S:%{http_code}')
[[ "$(hcode "$BAD_LOGIN")" == "401" ]] && info "✓ Bad password → 401" || { info "✗ Bad password not rejected"; GATE6_FAIL=1; }

# Re-login as admin
api POST /api/auth/login -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}" > /dev/null

# Secrets masked in cloud connector list
CC_LIST=$(api GET /api/v2/cloud/connectors)
if echo "$CC_LIST" | python3 -c "
import json,sys
d=json.load(sys.stdin)
conns=d.get('connectors',[])
has_secret=any('password' in str(c.get('config',{})).lower() and '***' not in str(c.get('config',{})) for c in conns)
exit(1 if has_secret else 0)" 2>/dev/null; then
  info "✓ Secrets masked in connector list"
else
  info "✗ Possible secret leak in connector list"; GATE6_FAIL=1
fi

# Audit log accessible
AUDIT=$(api GET "/api/admin/audit?limit=5")
echo "$AUDIT" | grep -q '"ok":true' && info "✓ Audit log endpoint working" || { info "✗ Audit log not working"; GATE6_FAIL=1; }

# Approval gate works
RA_TEST=$(api POST /api/v11/response/execute -d '{"actionType":"isolate_host","target":"test-gate6","mode":"guarded","params":{"reason":"security gate test"}}')
RA_STATUS=$(echo "$RA_TEST" | python3 -c "import json,sys; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null)
[[ "$RA_STATUS" == "pending_approval" ]] && info "✓ Guarded action creates pending approval" || info "  Guarded action status: ${RA_STATUS} (OK if simulation fallback)"

# Version header
VERSION=$(api GET /api/admin/version)
VER=$(echo "$VERSION" | python3 -c "import json,sys; print(json.load(sys.stdin).get('version',{}).get('app','?'))" 2>/dev/null)
[[ "$VER" == "1.4.7" ]] && info "✓ Version 1.4.7 confirmed" || { info "✗ Version mismatch: $VER"; GATE6_FAIL=1; }

[[ $GATE6_FAIL -eq 0 ]] && gate_pass 6 "Auth, secret masking, audit log, approval gate, version" || gate_fail 6 "One or more security checks failed — review output above"

# ─── Gate 7: Connector proof ─────────────────────────────────────────────
echo -e "\n${BOLD}Gate 7 · Connector proof (credential validation sheet)${NC}"
CLOUD=$(api GET /api/v2/cloud/metrics)
CC_COUNT=$(echo "$CLOUD" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('connectors',[])))" 2>/dev/null || echo 0)
info "${CC_COUNT} cloud connectors configured"

# Write connector validation sheet for manual completion
CONNECTOR_SHEET="${EVIDENCE_DIR}/artifacts/connector-validation-sheet.md"
cat > "$CONNECTOR_SHEET" << 'CONNSHEET'
# Connector Live Validation Sheet

**Instructions:** Complete this sheet by running each connector test against a real tenant before GA release.

## AWS CloudTrail
- [ ] IAM credentials configured (read-only CloudTrail access)
- [ ] `POST /api/v2/cloud/connectors/aws-default/test` returns `{ok: true}`
- [ ] Events appear in SIEM stream after poll
- [ ] Credential expiry test: rotate key, verify `status=error` with clear message
- [ ] Result: PASS / FAIL | Tester: ________ | Date: ________

## Azure Monitor
- [ ] Service principal configured (Log Analytics Reader)
- [ ] `POST /api/v2/cloud/connectors/azure-default/test` returns `{ok: true}`
- [ ] AuditLogs query returns results
- [ ] Token expiry: token cache clears on 401
- [ ] Result: PASS / FAIL | Tester: ________ | Date: ________

## Microsoft 365
- [ ] App registration configured (ActivityFeed.Read)
- [ ] `POST /api/v2/cloud/connectors/m365-default/test` returns `{ok: true}`
- [ ] At least one content type polled successfully
- [ ] Result: PASS / FAIL | Tester: ________ | Date: ________

## LDAP / Active Directory
- [ ] Service account configured (read-only)
- [ ] `POST /api/v2/ldap/test` returns `{ok: true, stage: 'search'}`
- [ ] `POST /api/v2/ldap/sync` returns `synced > 0`
- [ ] Risk tier mapping validated (privileged group maps correctly)
- [ ] Large OU test (>1,000 users): sync completes in < 120s
- [ ] LDAPS certificate test: self-signed cert with tlsRejectUnauthorized:false
- [ ] Result: PASS / FAIL | Tester: ________ | Date: ________

## Okta
- [ ] API token configured
- [ ] `POST /api/v2/oidc/test` returns `{ok: true}`
- [ ] `POST /api/v2/oidc/sync` returns `synced > 0`
- [ ] Rate limit handling tested (token with low rate limit)
- [ ] Result: PASS / FAIL | Tester: ________ | Date: ________

## Azure AD / Entra ID
- [ ] App registration configured (User.Read.All, Group.Read.All)
- [ ] `POST /api/v2/oidc/test` returns `{ok: true}`
- [ ] Large tenant test (>500 users via pagination)
- [ ] Result: PASS / FAIL | Tester: ________ | Date: ________
CONNSHEET

gate_skip 7 "Credential sheet generated at artifacts/connector-validation-sheet.md — complete before GA release"


CMDB_SHEET="${EVIDENCE_DIR}/artifacts/cmdb-validation-sheet.md"
cat > "$CMDB_SHEET" << 'CMDBSHEET'
# CMDB / Asset Validation Sheet
- [ ] CMDB source configured (file/url)
- [ ] `POST /api/v2/cmdb/test` returns `{ok:true}`
- [ ] `POST /api/v2/cmdb/sync` imports expected record count
- [ ] Imported assets appear in `/api/v2/assets`
- [ ] Criticality mapping validated on at least 3 assets
CMDBSHEET
info "CMDB validation sheet generated: ${CMDB_SHEET}"

# ─── Gate 8: Docs truth check ────────────────────────────────────────────
echo -e "\n${BOLD}Gate 8 · Documentation truth check${NC}"
GATE8_FAIL=0

[[ -f "README.md" ]] && grep -q "1.4.7" README.md && info "✓ README.md version-stamped" || { info "✗ README.md missing or unstamped"; GATE8_FAIL=1; }
[[ -f "RELEASE_NOTES_v1.4.7-fixed.md" ]] && info "✓ Release notes present" || { info "✗ Release notes missing"; GATE8_FAIL=1; }
[[ -f "COMMERCIAL_SCOPE.md" ]] && info "✓ COMMERCIAL_SCOPE.md present" || { info "✗ COMMERCIAL_SCOPE.md missing"; GATE8_FAIL=1; }
[[ -f "docs/ADMIN_GUIDE.md" ]] && info "✓ Admin guide present" || { info "  docs/ADMIN_GUIDE.md not yet created — required before GA"; GATE8_FAIL=1; }
[[ -f "docs/WORM_TAMPER_RUNBOOK.md" ]] && info "✓ WORM runbook present" || { info "✗ WORM runbook missing"; GATE8_FAIL=1; }
[[ -f "docs/LDAP_VALIDATION_GUIDE.md" ]] && info "✓ LDAP guide present" || { info "✗ LDAP guide missing"; GATE8_FAIL=1; }

# Check OpenAPI serves at runtime
OPENAPI_CHECK=$(api GET /api/docs/openapi.yaml -w '\n__S:%{http_code}' 2>/dev/null)
[[ "$(hcode "$OPENAPI_CHECK")" == "200" ]] && info "✓ OpenAPI spec served at /api/docs" || { info "✗ OpenAPI not served"; GATE8_FAIL=1; }

[[ $GATE8_FAIL -eq 0 ]] && gate_pass 8 "All docs present, versioned, and serving" || gate_fail 8 "Missing or stale docs — see items above"

# ─── Gate 9: Support handoff ─────────────────────────────────────────────
echo -e "\n${BOLD}Gate 9 · Support handoff package${NC}"
# Write the support handoff document
SUPPORT_DOC="${EVIDENCE_DIR}/artifacts/support-handoff.md"
VER_CHECK=$(api GET /api/admin/version | python3 -c "import json,sys; d=json.load(sys.stdin); v=d.get('version',{}); print(f'app={v.get(\"app\")} api={v.get(\"api\")} node={v.get(\"node\",\"\")[:6]}')" 2>/dev/null || echo "unavailable")

cat > "$SUPPORT_DOC" << SUPPORTDOC
# SIEM v1.4.7 Support Handoff

Build: ${BUILD_ID}
Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
Runtime version check: ${VER_CHECK}

## Install steps
1. \`sudo bash install.sh\` on Ubuntu 20/22/24
2. Create first admin: \`node app/add-admin.js USERNAME PASSWORD\`
3. Validate: \`bash tests/test-smoke.sh\`

## Rollback steps
1. Stop service: \`sudo systemctl stop siem-syslog\`
2. Restore DB: \`sudo cp /var/lib/siem-syslog/backups/YYYYMMDD.db /var/lib/siem-syslog/siem.db\`
3. Restore previous binary: reinstall prior version
4. Start service: \`sudo systemctl start siem-syslog\`

## Known limits (ship-blocking if exceeded)
- Max sustained ingest: ~5,000 EPS single-node
- DB practical limit: ~10GB (~50M events)
- Backup: full snapshot only, no incremental
- Live response actions: require sudo on Linux host

## Preview features (best-effort support)
- Cloud connectors: real code, not live-tenant-validated
- LDAP/Okta/Azure sync: available, needs per-customer validation
- WORM chain: tamper detection, not regulatory immutable storage
- Response guarded/live: approval workflow, not audited SOAR

## Not in scope (do not promise to customers)
- CMDB integration, multi-node scale, HA/DR, GenAI, container deployment

## First-call resolution guide
- Service not starting: check \`journalctl -u siem-syslog\`, check port conflicts
- No events: check UDP 55140 / TCP 55141 firewall rules
- Login broken: reset with \`node app/add-admin.js\`
- High disk: set retention policy in Admin → Storage
- WORM break: follow docs/WORM_TAMPER_RUNBOOK.md

## Evidence artifacts this release
- Regression log: logs/regression.log
- E2E screenshots: screens/
- Connector validation sheet: artifacts/connector-validation-sheet.md
SUPPORTDOC

gate_pass 9 "Support handoff doc written to artifacts/support-handoff.md"

# ─── Summary ─────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}══════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD} Release Gate Summary — Build: ${BUILD_ID}${NC}"
echo -e "${BOLD}══════════════════════════════════════════════════════════${NC}"
for result in "${GATE_RESULTS[@]}"; do
  if [[ "$result" == PASS* ]]; then echo -e "  ${GREEN}${result}${NC}"
  elif [[ "$result" == FAIL* ]]; then echo -e "  ${RED}${result}${NC}"
  else echo -e "  ${YELLOW}${result}${NC}"; fi
done

echo ""
echo -e "  Gates: ${GREEN}${PASS} PASSED${NC} / ${RED}${FAIL} FAILED${NC} / ${YELLOW}${SKIP} SKIPPED${NC}"
echo "  Evidence: ${EVIDENCE_DIR}"
echo ""

# Write JSON summary
python3 - << PYSUMMARY
import json, datetime
summary = {
  "build_id": "${BUILD_ID}",
  "generated": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "passed": ${PASS}, "failed": ${FAIL}, "skipped": ${SKIP},
  "release_ok": ${FAIL} == 0,
  "gates": [
    $(for r in "${GATE_RESULTS[@]}"; do echo "\"${r}\","; done)
  ]
}
with open("${EVIDENCE_DIR}/release-gate-summary.json", "w") as f:
    json.dump(summary, f, indent=2)
print("  JSON summary: ${EVIDENCE_DIR}/release-gate-summary.json")
PYSUMMARY

[[ $FAIL -eq 0 ]] && { echo -e "${GREEN}  ✅ ALL REQUIRED GATES PASSED — Build ${BUILD_ID} is release-candidate${NC}"; exit 0; } || { echo -e "${RED}  ❌ ${FAIL} GATE(S) FAILED — Do not release until fixed${NC}"; exit 1; }
