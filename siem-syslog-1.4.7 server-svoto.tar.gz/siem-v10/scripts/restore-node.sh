#!/usr/bin/env bash
set -euo pipefail
SRC="${1:-}"
[[ -f "$SRC" ]] || { echo "Usage: $0 /path/to/backup.tar.gz"; exit 1; }
systemctl stop siem-syslog || true
tar -xzf "$SRC" -C / 2>/dev/null || tar -xzf "$SRC" -C /opt 2>/dev/null || true
systemctl start siem-syslog || true
echo "Restore attempted from $SRC"
