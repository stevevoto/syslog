#!/usr/bin/env python3
import json
import sqlite3
import sys
from pathlib import Path

cfg_path = Path(sys.argv[1] if len(sys.argv) > 1 else "/etc/siem-syslog/config.json")
db_path = Path("/var/lib/siem-syslog/events.db")

try:
    cfg = json.loads(cfg_path.read_text())
    db_path = Path(cfg.get("database", {}).get("path", str(db_path)))
except Exception:
    pass

db_path.parent.mkdir(parents=True, exist_ok=True)

conn = sqlite3.connect(str(db_path))
cur = conn.cursor()

cur.executescript("""
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  ts_epoch INTEGER NOT NULL,
  host TEXT NOT NULL DEFAULT 'unknown',
  source_ip TEXT NOT NULL DEFAULT '',
  facility TEXT NOT NULL DEFAULT 'user',
  severity TEXT NOT NULL DEFAULT 'INFO',
  sev_num INTEGER NOT NULL DEFAULT 6,
  program TEXT NOT NULL DEFAULT '',
  pid TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL DEFAULT '',
  country TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  lat REAL,
  lon REAL,
  tags TEXT NOT NULL DEFAULT '',
  raw TEXT NOT NULL DEFAULT '',
  ecs_category TEXT NOT NULL DEFAULT '',
  ecs_type TEXT NOT NULL DEFAULT '',
  ecs_outcome TEXT NOT NULL DEFAULT '',
  ecs_action TEXT NOT NULL DEFAULT '',
  user_name TEXT NOT NULL DEFAULT '',
  dest_ip TEXT NOT NULL DEFAULT '',
  dest_port INTEGER,
  protocol TEXT NOT NULL DEFAULT '',
  risk_score INTEGER NOT NULL DEFAULT 0,
  anomaly_score REAL DEFAULT 0,
  anomaly_flags TEXT NOT NULL DEFAULT '',
  ioc_match INTEGER NOT NULL DEFAULT 0,
  ioc_type TEXT NOT NULL DEFAULT '',
  ioc_value TEXT NOT NULL DEFAULT '',
  authentication TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS alerts (
  id TEXT PRIMARY KEY,
  ts TEXT NOT NULL,
  rule_name TEXT NOT NULL,
  severity TEXT NOT NULL,
  host TEXT NOT NULL,
  message TEXT NOT NULL,
  event_id INTEGER,
  notified INTEGER NOT NULL DEFAULT 0,
  risk_score INTEGER NOT NULL DEFAULT 0,
  mitre_id TEXT NOT NULL DEFAULT '',
  mitre_tactic TEXT NOT NULL DEFAULT '',
  case_id TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS stats_hourly (
  bucket_hour INTEGER PRIMARY KEY,
  total INTEGER NOT NULL DEFAULT 0,
  crit INTEGER NOT NULL DEFAULT 0,
  warn INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cases (
  id TEXT PRIMARY KEY,
  ts_created TEXT NOT NULL,
  ts_updated TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  priority TEXT NOT NULL DEFAULT 'medium',
  assignee TEXT NOT NULL DEFAULT '',
  external_ref TEXT NOT NULL DEFAULT '',
  external_system TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS admin_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  username TEXT NOT NULL DEFAULT '',
  actor TEXT NOT NULL DEFAULT '',
  target TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL DEFAULT '',
  object_type TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  result TEXT NOT NULL DEFAULT '',
  remote_ip TEXT NOT NULL DEFAULT ''
);
""")

def ensure_column(table: str, name: str, decl: str) -> None:
    cur.execute(f"PRAGMA table_info({table})")
    cols = {row[1] for row in cur.fetchall()}
    if name not in cols:
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")

ensure_column("events", "authentication", "TEXT NOT NULL DEFAULT ''")
ensure_column("admin_audit", "actor", "TEXT NOT NULL DEFAULT ''")
ensure_column("admin_audit", "target", "TEXT NOT NULL DEFAULT ''")
ensure_column("alerts", "risk_score", "INTEGER NOT NULL DEFAULT 0")
ensure_column("alerts", "mitre_id", "TEXT NOT NULL DEFAULT ''")
ensure_column("alerts", "mitre_tactic", "TEXT NOT NULL DEFAULT ''")
ensure_column("alerts", "case_id", "TEXT NOT NULL DEFAULT ''")
ensure_column("stats_hourly", "warn", "INTEGER NOT NULL DEFAULT 0")
ensure_column("cases", "external_ref", "TEXT NOT NULL DEFAULT ''")
ensure_column("cases", "external_system", "TEXT NOT NULL DEFAULT ''")

cur.executescript("""
CREATE INDEX IF NOT EXISTS idx_ts ON events (ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_sev ON events (severity, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_host ON events (host, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_src_ip ON events (source_ip);
CREATE INDEX IF NOT EXISTS idx_risk ON events (risk_score DESC, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_user ON events (user_name, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_ioc ON events (ioc_match, ts_epoch DESC);
CREATE INDEX IF NOT EXISTS idx_alert_ts ON alerts (ts DESC);
CREATE INDEX IF NOT EXISTS idx_alert_case ON alerts (case_id);
""")

conn.commit()
conn.close()
print(f"Schema migration OK: {db_path}")
