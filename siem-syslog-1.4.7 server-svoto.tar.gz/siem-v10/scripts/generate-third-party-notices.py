#!/usr/bin/env python3
import json, sys
from pathlib import Path

app_dir = Path(sys.argv[1] if len(sys.argv) > 1 else "/opt/siem-syslog")
out = Path(sys.argv[2] if len(sys.argv) > 2 else str(app_dir / "THIRD_PARTY_NOTICES.md"))
node_modules = app_dir / "node_modules"
pkgs = []

def scan_pkg_json(path: Path):
    try:
        data = json.loads(path.read_text())
    except Exception:
        return None
    name = data.get("name") or path.parent.name
    version = data.get("version", "")
    license_ = data.get("license", "UNKNOWN")
    homepage = data.get("homepage", "")
    repo = data.get("repository", "")
    if isinstance(repo, dict):
        repo = repo.get("url", "")
    return {"name": name, "version": version, "license": license_, "homepage": homepage, "repo": repo}

if node_modules.exists():
    for pkg_json in node_modules.rglob("package.json"):
        # skip nested within node-gyp caches or obvious duplicates? keep unique by name/version
        item = scan_pkg_json(pkg_json)
        if item:
            pkgs.append(item)

seen = set()
rows = []
for item in sorted(pkgs, key=lambda x: (x["name"], x["version"])):
    key = (item["name"], item["version"])
    if key in seen:
        continue
    seen.add(key)
    rows.append(item)

lines = [
    "# THIRD_PARTY_NOTICES",
    "",
    "Generated from installed package metadata.",
    "",
]
for r in rows:
    lines.extend([
        f"## {r['name']} {r['version']}",
        f"- License: {r['license']}",
        f"- Homepage: {r['homepage']}" if r['homepage'] else "- Homepage: ",
        f"- Repository: {r['repo']}" if r['repo'] else "- Repository: ",
        "",
    ])

out.write_text("\n".join(lines))
print(out)
