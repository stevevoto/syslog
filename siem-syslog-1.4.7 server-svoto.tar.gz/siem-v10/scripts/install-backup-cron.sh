#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-/var/backups/siem-syslog}"
CRON="${2:-15 2 * * *}"
MODE="${3:-enable}"
FILE="/etc/cron.d/siem-syslog-backup"
mkdir -p "$DEST"
if [[ "$MODE" == "disable" ]]; then
  rm -f "$FILE"
  echo "disabled"
  exit 0
fi
printf '%s root %s %q\n' "$CRON" "/usr/local/bin/siem-syslog-backup-node" "$DEST" > "$FILE"
chmod 644 "$FILE"
echo "enabled"
