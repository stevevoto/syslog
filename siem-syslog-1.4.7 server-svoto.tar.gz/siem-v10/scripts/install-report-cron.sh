#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-/var/backups/siem-syslog/reports}"
CRON="${2:-30 2 * * *}"
COMPONENT="${3:-summary}"
MODE="${4:-enable}"
FILE="/etc/cron.d/siem-syslog-report"
mkdir -p "$DEST"
if [[ "$MODE" == "disable" ]]; then
  rm -f "$FILE"
  echo "disabled"
  exit 0
fi
printf '%s root %s %q %q\n' "$CRON" "/usr/local/bin/siem-syslog-run-report" "$DEST" "$COMPONENT" > "$FILE"
chmod 644 "$FILE"
echo "enabled"
