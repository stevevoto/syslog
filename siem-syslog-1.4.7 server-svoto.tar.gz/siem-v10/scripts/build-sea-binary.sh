#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"
DIST_DIR="${DIST_DIR:-$APP_DIR/dist-sea}"
ENTRY="${ENTRY:-$APP_DIR/server-v3.js}"
SEA_ENTRY="$DIST_DIR/sea-entry.cjs"
SEA_BLOB="$DIST_DIR/sea-prep.blob"
SEA_CONFIG="$DIST_DIR/sea-config.json"
BIN_NAME="${BIN_NAME:-siem-syslog}"

need() { command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1" >&2; exit 1; }; }
need node
need npm
mkdir -p "$DIST_DIR"

# Build a bundled CommonJS entry for Node SEA.
if ! command -v npx >/dev/null 2>&1; then
  echo "npx is required to bundle the server for SEA." >&2
  exit 1
fi

npx --yes esbuild "$ENTRY" \
  --bundle --platform=node --format=cjs --outfile="$SEA_ENTRY"

cat > "$SEA_CONFIG" <<EOF
{
  "main": "$SEA_ENTRY",
  "output": "$SEA_BLOB",
  "useCodeCache": true
}
EOF

node --experimental-sea-config "$SEA_CONFIG"
cp "$(command -v node)" "$DIST_DIR/$BIN_NAME"

if command -v postject >/dev/null 2>&1; then
  postject "$DIST_DIR/$BIN_NAME" NODE_SEA_BLOB "$SEA_BLOB" \
    --sentinel-fuse NODE_SEA_FUSE_fce680ab2cc467b6e072b8b5df1996b2
else
  echo "postject is not installed. Install it to finish SEA injection:" >&2
  echo "  npm install -g postject" >&2
  exit 2
fi

mkdir -p "$DIST_DIR/public"
cp -a "$APP_DIR/public/." "$DIST_DIR/public/"
cp -a "$APP_DIR/scripts" "$DIST_DIR/scripts"
cp -a "$APP_DIR/tests" "$DIST_DIR/tests"
cp -a "$APP_DIR"/package.json "$DIST_DIR/"

echo "SEA build ready in $DIST_DIR"
echo "Ship the binary together with public/, scripts/, tests/, compliance artifacts, and license notices."
