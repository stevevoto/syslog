#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST="${DIST:-$ROOT/dist-customer}"
mkdir -p "$DIST"
"$ROOT/scripts/build-sea-binary.sh"
rm -rf "$DIST"/*
cp -a "$ROOT/dist-sea/." "$DIST/"
rm -rf "$DIST/tests" "$DIST/docs" "$DIST/.github" || true
find "$DIST" -name '*.map' -delete || true
echo "Customer SEA artifact ready in $DIST"
