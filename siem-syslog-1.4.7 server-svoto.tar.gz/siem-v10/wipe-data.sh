#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/opt/siem-syslog}"
CONFIG_FILE="${CONFIG_FILE:-/etc/siem-syslog/config.json}"
DATA_DIR="${DATA_DIR:-/var/lib/siem-syslog}"
LOG_DIR="${LOG_DIR:-/var/log/siem-syslog}"
MODE="${1:-runtime}"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root."
  exit 1
fi

systemctl stop siem-syslog || true

case "$MODE" in
  runtime)
    rm -f "$DATA_DIR"/events.db "$DATA_DIR"/events.db-shm "$DATA_DIR"/events.db-wal
    rm -f "$LOG_DIR"/*.log 2>/dev/null || true
    rm -rf "$DATA_DIR/archive"/* "$DATA_DIR/outbox"/* 2>/dev/null || true
    ;;
  all)
    rm -f "$DATA_DIR"/events.db "$DATA_DIR"/events.db-shm "$DATA_DIR"/events.db-wal
    rm -rf "$DATA_DIR/archive"/* "$DATA_DIR/outbox"/* 2>/dev/null || true
    rm -f "$LOG_DIR"/*.log 2>/dev/null || true
    rm -f "$CONFIG_FILE"
    ;;
  *)
    echo "Usage: $0 {runtime|all}"
    exit 1
    ;;
esac

mkdir -p "$DATA_DIR/archive" "$DATA_DIR/outbox" "$LOG_DIR"
systemctl start siem-syslog || true
echo "Wipe complete: $MODE"
