#!/usr/bin/env bash
set -Eeuo pipefail

APP_PORT="${APP_PORT:-18080}"
CERT_CN="${CERT_CN:-$(hostname -f 2>/dev/null || hostname)}"
CERT_DAYS="${CERT_DAYS:-825}"
SERVER_NAME="${SERVER_NAME:-_}"
NGINX_SITE_NAME="siem-syslog-https"
NGINX_SITE_AVAIL="/etc/nginx/sites-available/${NGINX_SITE_NAME}"
NGINX_SITE_ENABLED="/etc/nginx/sites-enabled/${NGINX_SITE_NAME}"
CERT_DIR="/etc/siem-syslog/ssl"
CERT_KEY="${CERT_DIR}/siem-selfsigned.key"
CERT_CRT="${CERT_DIR}/siem-selfsigned.crt"
BACKUP_DIR="/var/backups/siem-syslog-https"
TS="$(date +%Y%m%d-%H%M%S)"

need_root() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "Please run as root: sudo bash $0" >&2
    exit 1
  fi
}

install_pkgs() {
  export DEBIAN_FRONTEND=noninteractive
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y nginx openssl curl
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y nginx openssl curl
    systemctl enable nginx || true
  elif command -v yum >/dev/null 2>&1; then
    yum install -y nginx openssl curl
    systemctl enable nginx || true
  else
    echo "Unsupported package manager. Install nginx openssl curl manually." >&2
    exit 1
  fi
}

backup_existing() {
  mkdir -p "${BACKUP_DIR}"
  [[ -f /etc/nginx/nginx.conf ]] && cp -a /etc/nginx/nginx.conf "${BACKUP_DIR}/nginx.conf.${TS}" || true
  [[ -f /etc/nginx/sites-available/default ]] && cp -a /etc/nginx/sites-available/default "${BACKUP_DIR}/default-site.${TS}" || true
  [[ -f /etc/nginx/conf.d/default.conf ]] && cp -a /etc/nginx/conf.d/default.conf "${BACKUP_DIR}/default.conf.${TS}" || true
  [[ -f "${NGINX_SITE_AVAIL}" ]] && cp -a "${NGINX_SITE_AVAIL}" "${BACKUP_DIR}/${NGINX_SITE_NAME}.${TS}" || true
}

gen_cert() {
  mkdir -p "${CERT_DIR}"
  chmod 700 "${CERT_DIR}"
  if [[ ! -f "${CERT_KEY}" || ! -f "${CERT_CRT}" ]]; then
    openssl req -x509 -nodes -newkey rsa:4096 \
      -keyout "${CERT_KEY}" \
      -out "${CERT_CRT}" \
      -sha256 -days "${CERT_DAYS}" \
      -subj "/CN=${CERT_CN}" \
      -addext "subjectAltName=DNS:${CERT_CN},IP:127.0.0.1"
    chmod 600 "${CERT_KEY}"
    chmod 644 "${CERT_CRT}"
  fi
}

write_nginx_site() {
  mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled
  cat > "${NGINX_SITE_AVAIL}" <<NGINX
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name ${SERVER_NAME};
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2 default_server;
    listen [::]:443 ssl http2 default_server;
    server_name ${SERVER_NAME};

    ssl_certificate     ${CERT_CRT};
    ssl_certificate_key ${CERT_KEY};
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;

    client_max_body_size 50m;

    proxy_http_version 1.1;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto https;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_read_timeout 3600;
    proxy_send_timeout 3600;

    location / {
        proxy_pass http://127.0.0.1:${APP_PORT};
    }
}
NGINX
  ln -sf "${NGINX_SITE_AVAIL}" "${NGINX_SITE_ENABLED}"

  # Disable common defaults that can conflict.
  rm -f /etc/nginx/sites-enabled/default || true
  rm -f /etc/nginx/conf.d/default.conf || true
}

check_backend() {
  if ! curl -fsS "http://127.0.0.1:${APP_PORT}" >/dev/null; then
    echo "Warning: backend http://127.0.0.1:${APP_PORT} did not answer before Nginx reload." >&2
    echo "The proxy will still be configured, but verify the siem-syslog service is running." >&2
  fi
}

reload_nginx() {
  nginx -t
  systemctl enable nginx >/dev/null 2>&1 || true
  systemctl restart nginx
}

show_result() {
  echo
  echo "HTTPS overlay applied."
  echo "Open: https://$(hostname -I 2>/dev/null | awk '{print $1}')/"
  echo "Self-signed cert CN: ${CERT_CN}"
  echo "Backend stays on: http://127.0.0.1:${APP_PORT}"
  echo
  echo "Quick checks:"
  echo "  curl -I http://127.0.0.1"
  echo "  curl -kI https://127.0.0.1"
  echo "  curl -k https://127.0.0.1/api/version"
}

main() {
  need_root
  install_pkgs
  backup_existing
  gen_cert
  write_nginx_site
  check_backend
  reload_nginx
  show_result
}

main "$@"
