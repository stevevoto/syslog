#!/usr/bin/env bash
set -Eeuo pipefail

SITE_AVAIL="/etc/nginx/sites-available/siem-syslog-https"
SITE_ENABLED="/etc/nginx/sites-enabled/siem-syslog-https"

if [[ ${EUID} -ne 0 ]]; then
  echo "Please run as root: sudo bash $0" >&2
  exit 1
fi

rm -f "${SITE_ENABLED}" "${SITE_AVAIL}"
if [[ -f /etc/nginx/sites-available/default ]]; then
  ln -sf /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default || true
fi
nginx -t
systemctl restart nginx

echo "Rolled back SIEM HTTPS overlay."
echo "Your SIEM backend should still be on http://127.0.0.1:18080"
