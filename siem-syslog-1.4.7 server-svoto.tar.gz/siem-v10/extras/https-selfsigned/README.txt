SIEM HTTPS self-signed overlay

What this does
- Keeps the SIEM app running internally on http://127.0.0.1:18080
- Redirects http://SERVER to https://SERVER
- Terminates TLS in Nginx with a self-signed certificate
- Proxies https://SERVER to the local SIEM app

Files included
- apply-siem-https-selfsigned.sh
- rollback-siem-https.sh

How to use
1) Copy this folder or zip to the server.
2) Run:
   sudo bash apply-siem-https-selfsigned.sh
3) Open:
   https://YOUR_SERVER_IP/
   or
   https://YOUR_SERVER_NAME/

Notes
- Because the certificate is self-signed, browsers will warn until you trust the cert.
- The SIEM service itself remains on port 18080 internally.
- Nginx listens on 80 and 443 and proxies to 127.0.0.1:18080.
- The script backs up any existing default Nginx site before replacing it.

Optional variables
- CERT_CN: common name for the cert. Default: current hostname
- CERT_DAYS: cert lifetime in days. Default: 825
- APP_PORT: backend SIEM port. Default: 18080
- SERVER_NAME: Nginx server_name. Default: _

Example
  sudo CERT_CN=siem.local SERVER_NAME=siem.local bash apply-siem-https-selfsigned.sh
