# siem-v10 full fixed code bundle

Bundle label: **siem-v10**
Internal application version: **1.4.7**

This bundle is based on the latest engineering-full (6) code with the following overlays applied:

- Safer post-install validation runner
- Safer regression runner path handling
- HTTP default for local validation on 127.0.0.1:18080
- Scheme auto-detection in the regression runner
- Broader 2xx JSON success handling in validation
- Extra CEF parser aliases and fields
- Included GitHub Actions release-gate workflow starter
- Included self-signed HTTPS / Nginx overlay under `extras/https-selfsigned/`

## Important notes
- Use **https://SERVER/** after applying the Nginx self-signed overlay.
- The Node app itself still listens on **http://127.0.0.1:18080**.
- Do not browse directly to **https://127.0.0.1:18080** because that port is still HTTP.
- The bundle name is `siem-v10`, but the app version remains `1.4.7` so version checks stay consistent.

## Included hotfix v10.1
- Folded in the test-all-regress.sh hotfix so chk_ok is defined and validation no longer aborts after Admin login.
- Updated app/public/index.html title/version labeling to reduce UI build confusion.
- Added HOTFIX_NOTES_v10.1.txt to the bundle.


## v10.2 sync-after-install fix
- Added scripts/sync-live-tree.sh to sync the full bundle into /opt/siem-syslog with delete semantics.
- Added sync-after-install.sh convenience wrapper for post-unzip refreshes.
- install.sh now invokes the sync helper during install/upgrade so stale files do not survive between builds.
- Expanded installed file coverage for newer modules: event-parser, enrichment-pipeline, ldap-sync, okta-sync, playbook-engine, worm-chain, openapi, upgrade/tamper tests, and docs.
