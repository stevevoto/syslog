#!/usr/bin/env bash
# SIEM v1.4.7 — Browser E2E tests via Playwright
# Requires: npm install -g playwright @playwright/test && npx playwright install chromium
set -Eeuo pipefail
BASE="${BASE:-https://127.0.0.1}"; APP_PORT="${APP_PORT:-18080}"
ADMIN_USER="${ADMIN_USER:-admin}"; ADMIN_PASS="${ADMIN_PASS:-}"
SCREEN_DIR="${SCREEN_DIR:-artifacts/regress/screens}"
mkdir -p "$SCREEN_DIR"

if ! command -v npx >/dev/null 2>&1; then
  echo "SKIP: npx/Playwright not available on this host"
  exit 0
fi
if ! npx playwright --version >/dev/null 2>&1; then
  echo "SKIP: Playwright not installed (npm install -g playwright)"
  exit 0
fi

TMPDIR=$(mktemp -d)
cat > "$TMPDIR/e2e.spec.js" << SPEC
const { test, expect } = require('@playwright/test');
const BASE = process.env.SIEM_BASE || 'http://127.0.0.1:${APP_PORT}';
const USER = process.env.SIEM_USER || '${ADMIN_USER}';
const PASS = process.env.SIEM_PASS || '';

test.use({ ignoreHTTPSErrors: true });

test('Login and session', async ({ page }) => {
  await page.goto(BASE, { timeout: 15000 });
  await page.waitForSelector('#username, input[type="text"]', { timeout: 10000 });
  await page.fill('#username, input[type="text"]', USER);
  await page.fill('#password, input[type="password"]', PASS);
  await page.click('button[type="submit"], .login-btn, .auth-btn, button:has-text("Sign In"), button:has-text("Login")');
  await page.waitForTimeout(2000);
  await page.screenshot({ path: '${SCREEN_DIR}/01-after-login.png' });
  await expect(page).not.toHaveURL(/login|auth/);
});

test('Live stream view loads', async ({ page }) => {
  await page.goto(BASE, { timeout: 15000 });
  await page.waitForSelector('#username, .nav-btn', { timeout: 10000 });
  if (await page.isVisible('#username')) {
    await page.fill('#username', USER);
    await page.fill('#password', PASS);
    await page.click('button:has-text("Sign In"), .auth-btn, button[type="submit"]');
    await page.waitForTimeout(2000);
  }
  const streamEl = page.locator('#logWrap, .live-stream, .log-stream').first();
  await page.screenshot({ path: '${SCREEN_DIR}/02-live-stream.png' });
  await expect(page.locator('.nav-btn, .nav-tabs')).toBeVisible({ timeout: 10000 });
});

test('Navigate to GeoMap and Cases', async ({ page }) => {
  await page.goto(BASE, { timeout: 15000 });
  await page.waitForSelector('.nav-btn, #username', { timeout: 10000 });
  if (await page.isVisible('#username')) {
    await page.fill('#username', USER);
    await page.fill('#password', PASS);
    await page.click('button:has-text("Sign In"), button[type="submit"]');
    await page.waitForTimeout(2000);
  }
  await page.click('.nav-btn:has-text("GeoMap")');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: '${SCREEN_DIR}/03-geomap.png' });
  await page.click('.nav-btn:has-text("Cases")');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: '${SCREEN_DIR}/04-cases.png' });
});

test('Diagnostics panel runs', async ({ page }) => {
  await page.goto(BASE, { timeout: 15000 });
  await page.waitForSelector('.nav-btn, #username', { timeout: 10000 });
  if (await page.isVisible('#username')) {
    await page.fill('#username', USER);
    await page.fill('#password', PASS);
    await page.click('button:has-text("Sign In"), button[type="submit"]');
    await page.waitForTimeout(2000);
  }
  await page.click('.nav-btn:has-text("Diagnostics"), #diagNavBtn');
  await page.waitForTimeout(1000);
  await page.click('button:has-text("Run All")');
  await page.waitForTimeout(8000);
  await page.screenshot({ path: '${SCREEN_DIR}/05-diagnostics.png' });
  const summary = await page.locator('#diagSummary').textContent({ timeout: 5000 }).catch(() => 'unknown');
  console.log('Diagnostics summary:', summary);
});
SPEC

SIEM_BASE="${BASE}:${APP_PORT}" SIEM_USER="${ADMIN_USER}" SIEM_PASS="${ADMIN_PASS}" \
  npx playwright test "$TMPDIR/e2e.spec.js" \
  --reporter=line \
  --browser=chromium \
  --headed=false \
  --screenshot=only-on-failure \
  --output="$SCREEN_DIR" 2>&1
RES=$?
rm -rf "$TMPDIR"
exit $RES
