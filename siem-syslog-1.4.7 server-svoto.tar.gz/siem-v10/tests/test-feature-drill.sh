#!/usr/bin/env bash
set -euo pipefail
BASE=${BASE:-https://127.0.0.1}
ADMIN_USER=${ADMIN_USER:-admin}
ADMIN_PASS=${ADMIN_PASS:-128tRoutes}
TMPDIR=$(mktemp -d /tmp/siem-feature-drill.XXXXXX)
COOKIE="$TMPDIR/cookie.txt"
trap 'rm -rf "$TMPDIR"' EXIT
login(){
  curl -sk -c "$COOKIE" -H 'Content-Type: application/json'     -d "{"username":"$ADMIN_USER","password":"$ADMIN_PASS"}"     "$BASE/api/auth/login" >/dev/null
}
api(){
  local method=$1 path=$2 body=${3:-}
  if [[ "$method" == GET ]]; then
    curl -sk -b "$COOKIE" "$BASE$path"
  else
    curl -sk -b "$COOKIE" -H 'Content-Type: application/json' -X "$method" -d "$body" "$BASE$path"
  fi
}
login
DRILL=$(api POST /api/admin/feature-drill '{}')
printf '%s' "$DRILL" | python3 -c 'import json,sys; obj=json.load(sys.stdin); print(f"Feature drill ok={obj.get("ok")} source={obj.get("primarySource")} injected={obj.get("injected")} geomapRows={obj.get("geomapRows")} alerts={obj.get("recentAlerts")}"); print("CVEs:", ", ".join(obj.get("cves",[])))'
EVENTS=$(api GET '/api/events?limit=10&q=CVE-2021-44228')
GEOMAP=$(api GET '/api/geomap')
printf '%s' "$EVENTS" > "$TMPDIR/events.json"
printf '%s' "$GEOMAP" > "$TMPDIR/geomap.json"
echo "Saved drill artifacts in $TMPDIR"
