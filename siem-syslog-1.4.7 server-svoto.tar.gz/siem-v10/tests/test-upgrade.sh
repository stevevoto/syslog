#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# SIEM Upgrade Path Test — v1.4.7
# Verifies that config, event data, cases, and users survive across upgrade.
#
# Usage:
#   BASE=https://127.0.0.1 APP_PORT=18080 \
#   ADMIN_USER=admin ADMIN_PASS=secret \
#   bash tests/test-upgrade.sh
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

BASE="${BASE:-https://127.0.0.1}"
APP_PORT="${APP_PORT:-18080}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-admin}"
COOKIE="/tmp/upgrade-test-$$.cookie"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'; BOLD='\033[1m'
PASS=0; FAIL=0

ok()   { echo -e "${GREEN}  ✓${NC} $*"; ((PASS++)); }
fail() { echo -e "${RED}  ✗${NC} $*"; ((FAIL++)); }
info() { echo -e "${YELLOW}  →${NC} $*"; }

cleanup() { rm -f "$COOKIE"; }
trap cleanup EXIT

api() {
  curl -sk -c "$COOKIE" -b "$COOKIE" -X "$1" "${BASE}:${APP_PORT}${2}" \
    -H "Content-Type: application/json" "${@:3}"
}

echo -e "\n${BOLD}═══ Upgrade Path Test ═══${NC}"
echo "This test verifies config and data survive a service restart (simulating upgrade)"
echo ""

# Step 1: Authenticate
LOGIN=$(api POST /api/auth/login -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}")
echo "$LOGIN" | grep -q '"ok":true' || { echo "Login failed — check ADMIN_USER/ADMIN_PASS"; exit 1; }
ok "Login successful"

# Step 2: Record pre-upgrade state
PRE_EVENTS=$(api GET "/api/events?limit=1" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))" 2>/dev/null || echo 0)
PRE_VER=$(api GET /api/admin/version | python3 -c "import json,sys; print(json.load(sys.stdin).get('version',{}).get('app','?'))" 2>/dev/null)
info "Pre-state: ${PRE_EVENTS} events, version=${PRE_VER}"

# Step 3: Create test data that must survive
CASE_RESP=$(api POST /api/cases -d '{"title":"UPGRADE-TEST-CASE-1","description":"Created by upgrade test — must survive","priority":"medium"}')
CASE_ID=$(echo "$CASE_RESP" | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
[[ -n "$CASE_ID" ]] && ok "Created test case: ${CASE_ID}" || fail "Could not create test case"

# Inject a test event
INJECT_RESP=$(api POST /api/inject -d '{"raw":"<46>Jan 01 00:00:01 upgrade-test siem: UPGRADE_MARKER_EVENT_v1.4.7"}')
echo "$INJECT_RESP" | grep -q '"ok":true' && ok "Injected marker event" || fail "Could not inject marker event"

# Create a test IOC
IOC_RESP=$(api POST /api/threatintel -d '{"ioc_value":"203.0.113.200","ioc_type":"ip","threat_type":"upgrade-test","confidence":99}')
echo "$IOC_RESP" | grep -q '"ok":true' && ok "Created test IOC" || fail "Could not create test IOC"

# Record asset count
ASSETS_BEFORE=$(api GET "/api/v2/assets?limit=1" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))" 2>/dev/null || echo 0)
info "Assets before: ${ASSETS_BEFORE}"

# Step 4: Trigger backup (upgrade rehearsal — real upgrade would restore from this)
BACKUP_RESP=$(api POST /api/admin/backup/run -d '{}')
echo "$BACKUP_RESP" | grep -q '"ok":true' && ok "Pre-upgrade backup created" || fail "Backup failed"

# Step 5: Simulate upgrade — restart simulation via settings reset (non-destructive)
# In a real upgrade: stop service, replace binary, start service
# Here we test that a fresh login after session invalidation still works
api POST /api/auth/logout -d '{}' > /dev/null
sleep 0.5
LOGIN2=$(api POST /api/auth/login -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}")
echo "$LOGIN2" | grep -q '"ok":true' && ok "Re-authentication after session reset" || fail "Re-auth failed"

# Step 6: Verify post-upgrade data integrity
POST_EVENTS=$(api GET "/api/events?limit=1" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))" 2>/dev/null || echo 0)
POST_VER=$(api GET /api/admin/version | python3 -c "import json,sys; print(json.load(sys.stdin).get('version',{}).get('app','?'))" 2>/dev/null)
[[ "$POST_VER" == "$PRE_VER" ]] && ok "Version consistent: ${POST_VER}" || fail "Version changed: ${PRE_VER} → ${POST_VER}"
[[ "$POST_EVENTS" -ge "$PRE_EVENTS" ]] && ok "Event count preserved (${POST_EVENTS} >= ${PRE_EVENTS})" || fail "Event count dropped: ${PRE_EVENTS} → ${POST_EVENTS}"

# Verify marker event survived
MARKER=$(api GET "/api/events?q=UPGRADE_MARKER_EVENT" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))" 2>/dev/null || echo 0)
[[ "$MARKER" -ge 1 ]] && ok "Marker event survived (${MARKER} found)" || fail "Marker event lost after restart"

# Verify case survived
if [[ -n "$CASE_ID" ]]; then
  CASE_CHECK=$(api GET "/api/cases?limit=100" | python3 -c "
import json,sys
cases=json.load(sys.stdin).get('cases',[])
found=any(c.get('id')=='${CASE_ID}' or 'UPGRADE-TEST' in c.get('title','') for c in cases)
print('found' if found else 'missing')
" 2>/dev/null || echo "unknown")
  [[ "$CASE_CHECK" == "found" ]] && ok "Test case survived: ${CASE_ID}" || fail "Test case lost: ${CASE_ID}"
fi

# Verify IOC survived
IOC_CHECK=$(api GET "/api/threatintel?limit=100" | python3 -c "
import json,sys
iocs=json.load(sys.stdin).get('iocs',[])
found=any(i.get('ioc_value')=='203.0.113.200' for i in iocs)
print('found' if found else 'missing')
" 2>/dev/null || echo "unknown")
[[ "$IOC_CHECK" == "found" ]] && ok "Test IOC survived" || fail "Test IOC lost"

# Verify backup is still listed
BACKUP_LIST=$(api GET /api/admin/backup/list)
BC=$(echo "$BACKUP_LIST" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('backups',[])))" 2>/dev/null || echo 0)
[[ "$BC" -ge 1 ]] && ok "Backups accessible (${BC} backup files)" || fail "Backup list empty"

# Cleanup: remove test data
[[ -n "$CASE_ID" ]] && api PATCH "/api/cases/${CASE_ID}" -d '{"status":"closed","notes":"Closed by upgrade test cleanup"}' > /dev/null

echo ""
echo "═════════════════════════════════════════════"
echo " Upgrade test: ${PASS} PASS / ${FAIL} FAIL"
echo "═════════════════════════════════════════════"
[[ $FAIL -eq 0 ]] && exit 0 || exit 1
