#!/usr/bin/env bash
# SIEM v1.4.7 — Smoke test (< 30 seconds)
# Quick pre-check: ports, login, status, version
set -Eeuo pipefail
BASE="${BASE:-https://127.0.0.1}"; APP_PORT="${APP_PORT:-18080}"
ADMIN_USER="${ADMIN_USER:-}"; ADMIN_PASS="${ADMIN_PASS:-}"
PASS=0; FAIL=0
GR='\033[0;32m'; RD='\033[0;31m'; NC='\033[0m'
ok(){ PASS=$((PASS+1)); echo -e "  ${GR}PASS${NC} $*"; }
fail(){ FAIL=$((FAIL+1)); echo -e "  ${RD}FAIL${NC} $*"; }
if [[ -z "$ADMIN_USER" ]]; then read -e -r -p "Admin user [admin]: " ADMIN_USER; ADMIN_USER="${ADMIN_USER:-admin}"; fi
if [[ -z "$ADMIN_PASS" ]]; then read -e -r -s -p "Admin pass: " ADMIN_PASS; echo; fi
COOKIE="/tmp/siem-smoke-$$.cookies"
api(){ curl -sk -c "$COOKIE" -b "$COOKIE" -H "Content-Type: application/json" -w '\n__S:%{http_code}' --max-time 8 "${@}" 2>/dev/null; }
hcode(){ grep -oP '__S:\K\d+' <<< "$1" | tail -1; }
echo "=== SIEM Smoke Test v1.4.7 ==="
ss -lntup 2>/dev/null | grep -qE ":${APP_PORT}\b" && ok "HTTP port :${APP_PORT} open" || fail "HTTP port :${APP_PORT} not open"
R=$(api -X POST "${BASE}:${APP_PORT}/api/auth/login" -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}")
[[ "$(hcode "$R")" -lt 400 ]] && ok "Login OK" || { fail "Login FAILED"; rm -f "$COOKIE"; exit 1; }
S=$(api "${BASE}:${APP_PORT}/api/status"); [[ "$(hcode "$S")" == "200" ]] && ok "Status 200" || fail "Status failed"
V=$(api "${BASE}:${APP_PORT}/api/admin/version")
VER=$(sed 's/__S:[0-9]*//' <<< "$V" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('version',{}).get('app','?'))" 2>/dev/null)
[[ "$VER" == "1.4.7" ]] && ok "Version 1.4.7" || fail "Version mismatch: got $VER"
curl -sk -c "$COOKIE" -b "$COOKIE" -X POST "${BASE}:${APP_PORT}/api/auth/logout" >/dev/null 2>&1 || true
rm -f "$COOKIE"
echo ""; echo "Smoke: PASS=${PASS} FAIL=${FAIL}"
[[ $FAIL -eq 0 ]] && exit 0 || exit 1
