#!/usr/bin/env bash
set -Eeuo pipefail

BASE="${BASE:-https://127.0.0.1}"
COOKIE="${COOKIE:-/tmp/siem-test.cookies}"
ADMIN_USER="${ADMIN_USER:-}"
ADMIN_PASS="${ADMIN_PASS:-}"
DESTRUCTIVE="${DESTRUCTIVE:-false}"
SKIP_DEMO="${SKIP_DEMO:-false}"
SKIP_EXTERNAL="${SKIP_EXTERNAL:-true}"
TEST_USER="${TEST_USER:-analyst1}"
TEST_PASS="${TEST_PASS:-Test123!}"
TMP_DIR="${TMP_DIR:-/tmp/siem-test}"
mkdir -p "$TMP_DIR"
rm -f "$COOKIE"

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
SKIP_COUNT=0

say() { echo -e "${BLUE}==>${NC} $*"; }
pass() { PASS_COUNT=$((PASS_COUNT+1)); echo -e "${GREEN}PASS${NC} $*"; }
fail() { FAIL_COUNT=$((FAIL_COUNT+1)); echo -e "${RED}FAIL${NC} $*"; }
skip() { SKIP_COUNT=$((SKIP_COUNT+1)); echo -e "${YELLOW}SKIP${NC} $*"; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "Missing required command: $1"; exit 1; }; }
for c in curl python3 openssl grep sed awk ss file timeout; do need_cmd "$c"; done

if [[ -z "$ADMIN_USER" ]]; then
  read -rp "Admin username: " ADMIN_USER
fi
if [[ -z "$ADMIN_PASS" ]]; then
  read -rsp "Admin password: " ADMIN_PASS
  echo
fi


json_payload() {
  python3 - "$1" "$2" <<'PY'
import json, sys
print(json.dumps({"username": sys.argv[1], "password": sys.argv[2]}))
PY
}

json_get() {
  local path="$1"
  python3 -c '
import json,sys
path=sys.argv[1]
raw=sys.stdin.read()
obj=json.loads(raw)
cur=obj
for part in path.split("."):
    if not part:
        continue
    if isinstance(cur, list) and part.isdigit():
        idx=int(part)
        cur=cur[idx] if idx < len(cur) else None
    elif isinstance(cur, dict):
        cur=cur.get(part)
    else:
        cur=None
        break
if isinstance(cur, bool):
    print("true" if cur else "false")
elif cur is None:
    print("")
else:
    print(cur)
' "$path"
}

save_body() {
  local name="$1" body="${2:-}"
  printf '%s' "$body" > "$TMP_DIR/$name"
}

api() {
  local method="$1" path="$2" data="${3:-}"
  if [[ -n "$data" ]]; then
    curl -sk --connect-timeout 5 --max-time 30 \
      -X "$method" -H 'Content-Type: application/json' \
      -b "$COOKIE" -c "$COOKIE" -d "$data" "$BASE$path"
  else
    curl -sk --connect-timeout 5 --max-time 30 \
      -X "$method" -b "$COOKIE" -c "$COOKIE" "$BASE$path"
  fi
}

http_code() {
  local method="$1" path="$2" data="${3:-}"
  if [[ -n "$data" ]]; then
    curl -sk --connect-timeout 5 --max-time 30 -o /dev/null -w '%{http_code}' \
      -X "$method" -H 'Content-Type: application/json' -b "$COOKIE" -c "$COOKIE" -d "$data" "$BASE$path"
  else
    curl -sk --connect-timeout 5 --max-time 30 -o /dev/null -w '%{http_code}' \
      -X "$method" -b "$COOKIE" -c "$COOKIE" "$BASE$path"
  fi
}

normalize_bool() {
  local v="${1:-}"
  printf '%s' "$v" | awk '{print tolower($0)}'
}

is_true() {
  local v
  v=$(normalize_bool "${1:-}")
  [[ "$v" == "true" || "$v" == "1" || "$v" == "yes" || "$v" == "ok" ]]
}

check_json_true() {
  local label="$1" json="$2" path="$3"
  local got
  got=$(printf '%s' "$json" | json_get "$path" 2>/dev/null || true)
  if is_true "$got"; then
    pass "$label"
    return 0
  fi
  save_body last-fail.json "$json"
  fail "$label (expected $path=true, got ${got:-<empty>}; see $TMP_DIR/last-fail.json)"
  return 1
}

check_json_path_eq() {
  local label="$1" json="$2" path="$3" expected="$4"
  local got
  got=$(printf '%s' "$json" | json_get "$path" 2>/dev/null || true)
  if [[ "$got" == "$expected" ]]; then
    pass "$label"
    return 0
  fi
  save_body last-fail.json "$json"
  fail "$label (expected $path=$expected, got ${got:-<empty>})"
  return 1
}

check_json_has_path() {
  local label="$1" json="$2" path="$3"
  local got
  got=$(printf '%s' "$json" | json_get "$path" 2>/dev/null || true)
  if [[ -n "$got" ]]; then
    pass "$label"
    return 0
  fi
  save_body last-fail.json "$json"
  fail "$label (missing path $path)"
  return 1
}

check_http_200() {
  local label="$1" path="$2"
  local code
  code=$(http_code GET "$path")
  if [[ "$code" == "200" ]]; then pass "$label"; else fail "$label (HTTP $code)"; fi
}

wait_for_status() {
  local tries=60 out
  for _ in $(seq 1 "$tries"); do
    out=$(curl -sk --connect-timeout 5 --max-time 10 -b "$COOKIE" "$BASE/api/status" || true)
    if is_true "$(printf '%s' "$out" | json_get ok 2>/dev/null || true)"; then
      echo "$out"
      return 0
    fi
    sleep 1
  done
  return 1
}

wait_for_login_and_status() {
  local tries=60 login out
  for _ in $(seq 1 "$tries"); do
    login=$(curl -sk --connect-timeout 5 --max-time 15 -c "$COOKIE" -H 'Content-Type: application/json' -d "$(json_payload "$ADMIN_USER" "$ADMIN_PASS")" "$BASE/api/auth/login" || true)
    if is_true "$(printf '%s' "$login" | json_get ok 2>/dev/null || true)"; then
      out=$(curl -sk --connect-timeout 5 --max-time 10 -b "$COOKIE" "$BASE/api/status" || true)
      if is_true "$(printf '%s' "$out" | json_get ok 2>/dev/null || true)"; then
        echo "$out"
        return 0
      fi
    fi
    sleep 2
  done
  return 1
}

require_port() {
  local label="$1" proto="$2" port="$3"
  if ss -ltnup | awk -v p=":$port" -v proto="$proto" '$1==proto && $5 ~ p {found=1} END{exit(found?0:1)}'; then
    pass "$label"
  else
    fail "$label"
  fi
}

tls_send() {
  local line="$1"
  timeout 6 bash -lc "printf '%s\\n' \"$line\" | openssl s_client -quiet -connect 127.0.0.1:6514 >/dev/null 2>&1" || true
}


udp_send() {
  local line="$1"
  MSG="$line" python3 - <<'PY'
import os, socket
msg=(os.environ.get('MSG','')+'\n').encode()
sock=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.sendto(msg, ('127.0.0.1', 55140))
sock.close()
PY
}

tcp_send() {
  local line="$1"
  MSG="$line" python3 - <<'PY'
import os, socket
msg=(os.environ.get('MSG','')+'\n').encode()
sock=socket.create_connection(('127.0.0.1', 55141), timeout=5)
sock.sendall(msg)
sock.close()
PY
}

say "Testing listener ports"
require_port "UDP 55140 listener present" udp 55140
require_port "TCP 55141 listener present" tcp 55141
require_port "TLS 6514 listener present" tcp 6514
require_port "HTTP 80 listener present" tcp 80
require_port "HTTPS 443 listener present" tcp 443
require_port "Backend 18080 listener present" tcp 18080

say "Testing admin login"
LOGIN_JSON=$(curl -sk --connect-timeout 5 --max-time 30 -c "$COOKIE" -H 'Content-Type: application/json' -d "$(json_payload "$ADMIN_USER" "$ADMIN_PASS")" "$BASE/api/auth/login")
save_body login.json "$LOGIN_JSON"
check_json_true "Admin login" "$LOGIN_JSON" ok
ME_JSON=$(api GET /api/auth/me)
check_json_true "Auth me" "$ME_JSON" ok
check_json_has_path "Auth me user.username" "$ME_JSON" user.username
STATUS_JSON=$(api GET /api/status)
check_json_true "Status API" "$STATUS_JSON" ok
SETTINGS_JSON=$(api GET /api/settings)
check_json_true "Settings API" "$SETTINGS_JSON" ok

say "Testing ingest via UDP/TCP/TLS"
TEST_TAG="cli-$(date +%s)"
udp_send "<34>Apr 02 12:00:00 udp-host app: ${TEST_TAG} udp test"
sleep 1
tcp_send "<34>Apr 02 12:00:00 tcp-host app: ${TEST_TAG} tcp test"
sleep 1
tls_send "<34>Apr 01 12:00:00 tls-host app: ${TEST_TAG} tls test"
sleep 2
EVENTS_JSON=$(api GET "/api/events?limit=100&q=${TEST_TAG}")
TOTAL_FOUND=$(printf '%s' "$EVENTS_JSON" | json_get total 2>/dev/null || echo 0)
if [[ "$TOTAL_FOUND" =~ ^[0-9]+$ ]] && (( TOTAL_FOUND >= 3 )); then
  pass "UDP/TCP/TLS ingest created at least 3 events"
else
  save_body events-after-syslog.json "$EVENTS_JSON"
  fail "UDP/TCP/TLS ingest did not produce 3 searchable events"
fi

say "Testing API injection"
INJECT_JSON=$(api POST /api/inject "{\"raw\":\"<134>Apr 01 12:05:00 api-host app: ${TEST_TAG} injected api test\",\"source\":\"127.0.0.1\"}")
check_json_true "Inject API" "$INJECT_JSON" ok
sleep 1
INJECT_QUERY=$(api GET "/api/events?limit=20&q=${TEST_TAG}%20injected")
INJECT_TOTAL=$(printf '%s' "$INJECT_QUERY" | json_get total 2>/dev/null || echo 0)
if [[ "$INJECT_TOTAL" =~ ^[0-9]+$ ]] && (( INJECT_TOTAL >= 1 )); then pass "Injected event searchable"; else fail "Injected event not found"; fi

say "Testing cloud ingest"
CLOUD_JSON=$(api POST /api/ingest/cloud '{"source":"aws-cloudtrail","events":[{"host":"aws-guardduty","message":"ConsoleLogin success for testuser","sourceIP":"198.51.100.10"},{"host":"aws-ec2","message":"Security group changed","sourceIP":"198.51.100.11"}]}')
check_json_true "Cloud ingest" "$CLOUD_JSON" ok

say "Testing user administration"
http_code DELETE "/api/admin/users/$TEST_USER" >/dev/null || true
CREATE_JSON=$(api POST /api/admin/users "{\"username\":\"$TEST_USER\",\"password\":\"$TEST_PASS\",\"role\":\"analyst\",\"displayName\":\"Analyst One\"}")
check_json_true "Create user" "$CREATE_JSON" ok
PATCH_JSON=$(api PATCH "/api/admin/users/$TEST_USER" '{"enabled":false,"displayName":"Analyst One Disabled"}')
check_json_true "Disable user" "$PATCH_JSON" ok
LOGIN_DISABLED_CODE=$(curl -sk --connect-timeout 5 --max-time 30 -o /dev/null -w '%{http_code}' -H 'Content-Type: application/json' -d "$(json_payload "$TEST_USER" "$TEST_PASS")" "$BASE/api/auth/login")
if [[ "$LOGIN_DISABLED_CODE" == "401" ]]; then pass "Disabled user login denied"; else fail "Disabled user login should be denied (HTTP $LOGIN_DISABLED_CODE)"; fi
ENABLE_JSON=$(api PATCH "/api/admin/users/$TEST_USER" "{\"enabled\":true,\"password\":\"$TEST_PASS\",\"displayName\":\"Analyst One\"}")
check_json_true "Enable user" "$ENABLE_JSON" ok
USER_COOKIE="$TMP_DIR/user.cookies"
USER_LOGIN=$(curl -sk --connect-timeout 5 --max-time 30 -c "$USER_COOKIE" -H 'Content-Type: application/json' -d "$(json_payload "$TEST_USER" "$TEST_PASS")" "$BASE/api/auth/login")
check_json_true "Enabled user login works" "$USER_LOGIN" ok
DELETE_JSON=$(api DELETE "/api/admin/users/$TEST_USER")
check_json_true "Delete user" "$DELETE_JSON" ok

say "Testing Phase 2 settings and agent ingest"
PHASE2_SET=$(api POST /api/admin/phase2/settings '{"alertDedupSeconds":120,"alertSuppressionSeconds":300,"mitreSummaryDays":14,"archiveDir":"/var/lib/siem-syslog/archive","agentSharedKey":"AgentKey123!"}')
check_json_true "Save Phase 2 settings" "$PHASE2_SET" ok
AGENT_JSON=$(curl -sk --connect-timeout 5 --max-time 30 -H 'Content-Type: application/json' -H 'X-Agent-Key: AgentKey123!' -d '{"events":["<134>Apr 01 12:10:00 agent-host osquery: phase2 agent event 1","<134>Apr 01 12:10:01 agent-host auditd: phase2 agent event 2"]}' "$BASE/api/ingest/agent")
check_json_true "Agent ingest" "$AGENT_JSON" ok

say "Testing threat intel and IOC match"
TI_ADD=$(api POST /api/threatintel '{"ioc_value":"203.0.113.77","ioc_type":"ip","threat_type":"c2","confidence":95,"source":"manual"}')
check_json_true "Add threat intel IOC" "$TI_ADD" ok
IOC_INJECT=$(api POST /api/inject '{"raw":"<134>Apr 01 12:15:00 fw-core-01 kernel: outbound session to suspicious IP","source":"203.0.113.77"}')
check_json_true "Inject IOC-matching event" "$IOC_INJECT" ok
sleep 1
IOC_EVENTS=$(api GET '/api/events?ioc=1&limit=20')
IOC_TOTAL=$(printf '%s' "$IOC_EVENTS" | json_get total 2>/dev/null || echo 0)
if [[ "$IOC_TOTAL" =~ ^[0-9]+$ ]] && (( IOC_TOTAL >= 1 )); then pass "IOC events searchable"; else fail "IOC events not found"; fi

say "Testing cases"
CASE_CREATE=$(api POST /api/cases '{"title":"Manual CLI test case","description":"Created from test-all-v3.sh","priority":"high","assignee":"soc"}')
CASE_ID=$(printf '%s' "$CASE_CREATE" | json_get id 2>/dev/null || true)
if [[ -n "$CASE_ID" ]]; then
  pass "Create case"
  CASE_PATCH=$(api PATCH "/api/cases/$CASE_ID" '{"status":"in_progress","priority":"critical","notes":"updated by test-all-v3.sh"}')
  if [[ -n "$(printf '%s' "$CASE_PATCH" | json_get id 2>/dev/null || true)" ]]; then
    pass "Update case"
  else
    save_body case-patch.json "$CASE_PATCH"
    fail "Update case"
  fi
else
  save_body case-create.json "$CASE_CREATE"
  fail "Create case"
fi

say "Testing analytics endpoints"
check_http_200 "Events API reachable" '/api/events?limit=10'
check_http_200 "Stats API reachable" '/api/stats'
check_http_200 "Alerts API reachable" '/api/alerts?limit=10'
check_http_200 "Geomap API reachable" '/api/geomap'
check_http_200 "MITRE summary API reachable" '/api/analytics/mitre-summary?days=7'
check_http_200 "UEBA API reachable" '/api/ueba'
check_http_200 "Audit API reachable" '/api/admin/audit?limit=20'
check_http_200 "Integrations status API reachable" '/api/integrations/status'
check_http_200 "Admin users API reachable" '/api/admin/users'
check_http_200 "Phase 2 settings API reachable" '/api/admin/phase2/settings'

say "Testing exports and reports"
CSV_FILE="$TMP_DIR/events.csv"
NDJ_FILE="$TMP_DIR/events.ndjson"
PDF_FILE="$TMP_DIR/summary.pdf"
COMPLIANCE_FILE="$TMP_DIR/compliance.json"
curl -sk --connect-timeout 5 --max-time 60 -b "$COOKIE" "$BASE/api/export/events.csv?limit=50" -o "$CSV_FILE"
curl -sk --connect-timeout 5 --max-time 60 -b "$COOKIE" "$BASE/api/export/events.ndjson?limit=50" -o "$NDJ_FILE"
curl -sk --connect-timeout 5 --max-time 60 -b "$COOKIE" "$BASE/api/reports/pdf?component=summary&limit=200" -o "$PDF_FILE"
curl -sk --connect-timeout 5 --max-time 60 -b "$COOKIE" "$BASE/api/reports/compliance-summary?days=7" -o "$COMPLIANCE_FILE"
if [[ -s "$CSV_FILE" ]] && head -1 "$CSV_FILE" | grep -q ','; then pass "CSV export"; else fail "CSV export"; fi
if [[ -s "$NDJ_FILE" ]] && head -1 "$NDJ_FILE" | grep -q '{'; then pass "NDJSON export"; else fail "NDJSON export"; fi
if file "$PDF_FILE" | grep -qi 'PDF'; then pass "PDF report export"; else fail "PDF report export"; fi
if [[ -s "$COMPLIANCE_FILE" ]] && grep -q 'generatedAt' "$COMPLIANCE_FILE"; then pass "Compliance summary"; else fail "Compliance summary"; fi

say "Testing demo mode toggle"
if [[ "$SKIP_DEMO" == "true" ]]; then
  skip "Demo mode toggle test skipped"
else
  CURRENT_DEMO=$(printf '%s' "$SETTINGS_JSON" | json_get demoMode 2>/dev/null || echo false)
  if is_true "$CURRENT_DEMO"; then TARGET_DEMO=false; else TARGET_DEMO=true; fi
  DEMO_TOGGLE=$(api POST /api/settings/demo-mode "{\"enabled\":$TARGET_DEMO}")
  if is_true "$(printf '%s' "$DEMO_TOGGLE" | json_get ok 2>/dev/null || true)"; then
    sleep 5
    RE_STATUS=$(wait_for_login_and_status || true)
    if [[ -n "$RE_STATUS" ]]; then
      pass "Demo mode toggle and restart"
      api POST /api/settings/demo-mode "{\"enabled\":$CURRENT_DEMO}" >/dev/null || true
      sleep 5
      wait_for_login_and_status >/dev/null || true
    else
      save_body demo-toggle-status.json "${RE_STATUS:-}"
      fail "Demo mode toggle restart did not recover status"
    fi
  else
    save_body demo-toggle.json "$DEMO_TOGGLE"
    fail "Demo mode toggle request failed"
  fi
fi



say "Testing Phase 3.1 diagnostics, backup, and schedule settings"
P3_SET=$(api POST /api/admin/phase3/settings '{"backupDir":"/var/backups/siem-syslog-test","backupCron":"17 3 * * *","backupScheduleEnabled":false,"reportOutputDir":"/var/backups/siem-syslog-test/reports","reportCron":"47 3 * * *","reportComponent":"summary","reportScheduleEnabled":false}')
check_json_true "Save Phase 3.1 settings" "$P3_SET" ok
P3_DIAG=$(api GET /api/admin/diagnostics)
check_json_true "Diagnostics API reachable" "$P3_DIAG" ok
P3_HELP=$(api GET /api/admin/helpers/status)
check_json_true "Helpers status API reachable" "$P3_HELP" ok
P3_BACKUP=$(api POST /api/admin/backup/run '{"destDir":"/var/backups/siem-syslog-test"}')
check_json_true "Run backup now" "$P3_BACKUP" ok
P3_PATH=$(printf '%s' "$P3_BACKUP" | json_get path 2>/dev/null || true)
if [[ -n "$P3_PATH" && -f "$P3_PATH" ]]; then pass "Backup archive file exists"; else fail "Backup archive file missing"; fi
P3_LIST=$(api GET '/api/admin/backups?backupDir=/var/backups/siem-syslog-test&reportDir=/var/backups/siem-syslog-test/reports')
check_json_true "Backup listing API reachable" "$P3_LIST" ok



say "Testing Phase 4.3 routing, delivery, health, and wipe guard"
P4_SET=$(api POST /api/admin/phase4/settings '{"alertRoutingEnabled":true,"routeMinSeverity":"CRIT","routeTarget":"outbox","reportDeliveryEnabled":true,"reportDeliveryMode":"spool","reportDeliveryComponent":"summary","reportDeliveryTo":"soc@example.com","outboxDir":"/var/lib/siem-syslog/outbox","healthWarnDiskPct":85,"healthWarnMemoryPct":85}')
check_json_true "Save Phase 4.3 settings" "$P4_SET" ok
check_http_200 "Phase 4.3 settings API reachable" '/api/admin/phase4/settings'
check_http_200 "Health dashboard API reachable" '/api/admin/health'
P4_ROUTE=$(api POST /api/admin/alert-routing/test '{"severity":"CRIT","rule_name":"CLI Route Test","host":"siem-cli","message":"phase 4.3 route test"}')
check_json_true "Alert routing test" "$P4_ROUTE" ok
P4_MATCH=$(printf '%s' "$P4_ROUTE" | json_get matchedCount 2>/dev/null || echo 0)
if [[ "$P4_MATCH" =~ ^[0-9]+$ ]] && (( P4_MATCH >= 1 )); then pass "Alert routing produced a match"; else fail "Alert routing did not produce a match"; fi
P4_DELIVERY=$(api POST /api/admin/report-delivery/test '{"component":"summary"}')
check_json_true "Report delivery test" "$P4_DELIVERY" ok
P4_PDF=$(printf '%s' "$P4_DELIVERY" | json_get pdfPath 2>/dev/null || true)
if [[ -n "$P4_PDF" && -f "$P4_PDF" ]]; then pass "Report delivery PDF exists"; else fail "Report delivery PDF missing"; fi
P4_OUTBOX=$(api GET '/api/admin/report-delivery/outbox')
check_json_true "Report outbox API reachable" "$P4_OUTBOX" ok
P4_OUT_COUNT=$(printf '%s' "$P4_OUTBOX" | json_get deliveries.0.name 2>/dev/null || true)
if [[ -n "$P4_OUT_COUNT" ]]; then pass "Report outbox contains at least one item"; else fail "Report outbox is empty"; fi
WIPE_GUARD_CODE=$(http_code POST /api/admin/wipe-data '{"mode":"all"}')
if [[ "$WIPE_GUARD_CODE" == "400" ]]; then pass "Wipe-all confirmation guard"; else fail "Wipe-all confirmation guard (HTTP $WIPE_GUARD_CODE)"; fi


say "Testing Phase 5.0 operations, upgrade, routes, and retention"
P5_SET=$(api POST /api/admin/phase5/settings '{"operationsEnabled":true,"upgradeChannel":"stable","retentionDays":30,"reportDeliveryEnabled":true,"reportDeliveryMode":"spool","reportDeliveryTo":"soc@example.com","reportDeliveryFrom":"siem@localhost","reportDeliveryCron":"0 7 * * *","reportDeliveryComponent":"summary","outboxDir":"/var/lib/siem-syslog/outbox","healthWarnDiskPct":85,"healthWarnMemoryPct":85}')
check_json_true "Save Phase 5.0 settings" "$P5_SET" ok
check_http_200 "Phase 5.0 settings API reachable" '/api/admin/phase5/settings'
P5_VER=$(api GET /api/admin/version)
check_json_true "Version API reachable" "$P5_VER" ok
P5_APP=$(printf '%s' "$P5_VER" | json_get version.app 2>/dev/null || true)
if [[ -n "$P5_APP" ]]; then pass "Version payload contains app version"; else fail "Version payload missing app version"; fi
P5_ADV=$(api GET /api/admin/upgrade/advisor)
check_json_true "Upgrade advisor API reachable" "$P5_ADV" ok
P5_ROUTE_UPSERT=$(api POST /api/admin/alert-routes '{"name":"warning_outbox","enabled":true,"minSeverity":"WARNING","target":"outbox"}')
check_json_true "Alert route upsert" "$P5_ROUTE_UPSERT" ok
P5_ROUTES=$(api GET /api/admin/alert-routes)
check_json_true "Alert routes list API reachable" "$P5_ROUTES" ok
P5_ROUTE_NAME=$(printf '%s' "$P5_ROUTES" | json_get routes.0.name 2>/dev/null || true)
if [[ -n "$P5_ROUTE_NAME" ]]; then pass "Alert routes list contains at least one item"; else fail "Alert routes list is empty"; fi
P5_EMAIL=$(api POST /api/admin/report-delivery/test-email '{"component":"summary","to":"soc@example.com"}')
check_json_true "Phase 5 email delivery test" "$P5_EMAIL" ok
P5_EMAIL_PDF=$(printf '%s' "$P5_EMAIL" | json_get pdfPath 2>/dev/null || true)
if [[ -n "$P5_EMAIL_PDF" && -f "$P5_EMAIL_PDF" ]]; then pass "Phase 5 email delivery PDF exists"; else fail "Phase 5 email delivery PDF missing"; fi
P5_RET=$(api POST /api/admin/maintenance/run-retention '{"days":30}')
check_json_true "Retention maintenance run" "$P5_RET" ok
P5_ROUTE_DEL_CODE=$(http_code DELETE /api/admin/alert-routes/warning_outbox)
if [[ "$P5_ROUTE_DEL_CODE" == "200" ]]; then pass "Alert route delete"; else fail "Alert route delete (HTTP $P5_ROUTE_DEL_CODE)"; fi



say "Testing Phase 6.0 fresh start, summary, and clear guards"
PHASE6_SAVE=$(api POST /api/admin/phase6/settings '{"freshStartEnabled":true,"autoDisableDemoAfterClear":true,"requireTypedConfirm":true,"clearConfirmPhrase":"WIPE ALL"}')
check_json_true "Save Phase 6.0 settings" "$PHASE6_SAVE" ok
PHASE6_GET=$(api GET /api/admin/phase6/settings)
check_json_true "Phase 6.0 settings API reachable" "$PHASE6_GET" ok
SUMMARY_JSON=$(api GET /api/admin/data-summary)
check_json_true "Data summary API reachable" "$SUMMARY_JSON" ok
check_json_has_path "Data summary contains event count" "$SUMMARY_JSON" counts.events
WIPE_GUARD_CODE=$(http_code POST /api/admin/fresh-start/all '{"confirm":"nope"}')
if [[ "$WIPE_GUARD_CODE" == "400" ]]; then pass "Clear all confirmation guard"; else fail "Clear all confirmation guard (HTTP $WIPE_GUARD_CODE)"; fi
RUNTIME_GUARD_CODE=$(http_code POST /api/admin/fresh-start/runtime '{"confirm":"wrong"}')
if [[ "$RUNTIME_GUARD_CODE" == "400" ]]; then pass "Runtime clear confirmation guard"; else fail "Runtime clear confirmation guard (HTTP $RUNTIME_GUARD_CODE)"; fi
if [[ "${DESTRUCTIVE,,}" == "true" ]]; then
  CLEAR_RT=$(api POST /api/admin/fresh-start/runtime '{"confirm":"CLEAR RUNTIME","autoDisableDemo":true}')
  check_json_true "Destructive runtime clear" "$CLEAR_RT" ok
  SUMMARY_AFTER=$(api GET /api/admin/data-summary)
  check_json_true "Data summary after destructive runtime clear reachable" "$SUMMARY_AFTER" ok
else
  skip "Destructive Phase 6 runtime clear skipped"
fi

say "Testing optional external ticket push"
INTEGRATION_JSON=$(api GET /api/integrations/status)
JIRA_ENABLED=$(printf '%s' "$INTEGRATION_JSON" | json_get jira.enabled 2>/dev/null || echo false)
SN_ENABLED=$(printf '%s' "$INTEGRATION_JSON" | json_get servicenow.enabled 2>/dev/null || echo false)
if [[ -n "${CASE_ID:-}" ]] && is_true "$JIRA_ENABLED" && [[ "$SKIP_EXTERNAL" != "true" ]]; then
  PUSH_JIRA=$(api POST "/api/cases/$CASE_ID/push-ticket" '{"target":"jira"}')
  check_json_true "Push Jira ticket" "$PUSH_JIRA" ok
else
  skip "Jira ticket push skipped"
fi
if [[ -n "${CASE_ID:-}" ]] && is_true "$SN_ENABLED" && [[ "$SKIP_EXTERNAL" != "true" ]]; then
  PUSH_SN=$(api POST "/api/cases/$CASE_ID/push-ticket" '{"target":"servicenow"}')
  check_json_true "Push ServiceNow ticket" "$PUSH_SN" ok
else
  skip "ServiceNow ticket push skipped"
fi

say "Testing optional destructive wipe"
if [[ "$DESTRUCTIVE" == "true" ]]; then
  WIPE_JSON=$(api POST /api/admin/wipe-data '{"mode":"runtime"}')
  check_json_true "Runtime wipe" "$WIPE_JSON" ok
  POST_WIPE_EVENTS=$(api GET '/api/events?limit=10')
  POST_WIPE_TOTAL=$(printf '%s' "$POST_WIPE_EVENTS" | json_get total 2>/dev/null || echo 999)
  if [[ "$POST_WIPE_TOTAL" =~ ^[0-9]+$ ]] && (( POST_WIPE_TOTAL == 0 )); then pass "Runtime wipe cleared events"; else fail "Runtime wipe did not clear events"; fi
else
  skip "Destructive wipe tests skipped"
fi

say "Logging out"
LOGOUT_JSON=$(api POST /api/auth/logout)
check_json_true "Logout" "$LOGOUT_JSON" ok

printf '\nSummary: PASS=%s FAIL=%s SKIP=%s\n' "$PASS_COUNT" "$FAIL_COUNT" "$SKIP_COUNT"
printf 'Artifacts: %s\n' "$TMP_DIR"
if (( FAIL_COUNT > 0 )); then
  exit 1
fi
