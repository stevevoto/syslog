#!/usr/bin/env bash
set -Eeuo pipefail

BASE="${BASE:-https://127.0.0.1}"
COOKIE="${COOKIE:-/tmp/siem-nav.cookies}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-}"
TMP_DIR="${TMP_DIR:-/tmp/siem-nav}"
CFG_FILE="${CFG_FILE:-/etc/siem-syslog/config.json}"
mkdir -p "$TMP_DIR"
rm -f "$COOKIE"

need_cmd(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1"; exit 1; }; }
for c in curl python3 ss; do need_cmd "$c"; done

prompt_secret(){ local __var="$1"; local __value=""; read -e -r -s -p "Admin password: " __value; echo; printf -v "$__var" '%s' "$__value"; }
if [[ -z "$ADMIN_PASS" ]]; then prompt_secret ADMIN_PASS; fi

readarray -t _PORTS < <(python3 - "$CFG_FILE" <<'PY'
import json, sys
cfg = json.load(open(sys.argv[1]))
srv = cfg.get('server', {})
tls = cfg.get('tlsSyslog', {})
print(srv.get('udpPort', 514))
print(srv.get('tcpPort', 601))
print(tls.get('port', 6514))
print(srv.get('httpPort', 18080))
PY
)
UDP_PORT="${UDP_PORT:-${_PORTS[0]}}"
TCP_PORT="${TCP_PORT:-${_PORTS[1]}}"
TLS_PORT="${TLS_PORT:-${_PORTS[2]}}"
APP_PORT="${APP_PORT:-${_PORTS[3]}}"

api(){
  local method="$1" path="$2" data="${3:-}"
  if [[ -n "$data" ]]; then
    curl -sk -X "$method" -H 'Content-Type: application/json' -b "$COOKIE" -c "$COOKIE" -d "$data" "$BASE$path"
  else
    curl -sk -X "$method" -b "$COOKIE" -c "$COOKIE" "$BASE$path"
  fi
}

json_get(){
  local path="$1"
  python3 -c '
import json,sys
path=sys.argv[1]
obj=json.loads(sys.stdin.read())
cur=obj
for part in path.split("."):
    if not part:
        continue
    if isinstance(cur,list) and part.isdigit():
        i=int(part); cur=cur[i] if i < len(cur) else None
    elif isinstance(cur,dict):
        cur=cur.get(part)
    else:
        cur=None; break
if isinstance(cur,bool): print("true" if cur else "false")
elif cur is None: print("")
else: print(cur)
' "$path"
}

json_count(){
  local path="$1"
  python3 - "$path" <<'PY'
import json, sys
path=sys.argv[1]
obj=json.loads(sys.stdin.read())
cur=obj
for part in path.split('.'):
    if not part:
        continue
    if isinstance(cur,list) and part.isdigit():
        i=int(part); cur=cur[i] if i < len(cur) else None
    elif isinstance(cur,dict):
        cur=cur.get(part)
    else:
        cur=None; break
if isinstance(cur,(list,dict)): print(len(cur))
elif cur in (None, ''): print(0)
else: print(1)
PY
}

LOGIN=$(python3 - "$ADMIN_USER" "$ADMIN_PASS" <<'PY'
import json, sys
print(json.dumps({"username": sys.argv[1], "password": sys.argv[2]}))
PY
)
RESP=$(api POST /api/auth/login "$LOGIN")
if [[ "$(printf '%s' "$RESP" | json_get ok 2>/dev/null || true)" != "true" ]]; then
  echo "Login failed"
  printf '%s\n' "$RESP"
  exit 1
fi

OUT="$TMP_DIR/top-nav-summary.txt"
: > "$OUT"
summary(){ printf '%s\n' "$*" | tee -a "$OUT"; }
summary "SIEM top navigation summary"
summary "Base: $BASE"
summary "Raw logging listeners: UDP $UDP_PORT / TCP $TCP_PORT / TLS $TLS_PORT / APP $APP_PORT"
ss -lntup 2>/dev/null | egrep ":${UDP_PORT}|:${TCP_PORT}|:${TLS_PORT}|:${APP_PORT}" | tee "$TMP_DIR/raw-listeners.txt" >/dev/null || true
summary "Raw listener snapshot: $TMP_DIR/raw-listeners.txt"

LIVE=$(api GET '/api/events?limit=5')
summary "Live Stream: rows=$(printf '%s' "$LIVE" | json_count events) first_host=$(printf '%s' "$LIVE" | json_get events.0.host) first_sev=$(printf '%s' "$LIVE" | json_get events.0.severity)"
UEBA=$(api GET '/api/ueba?hours=1')
summary "UEBA: anomalies=$(printf '%s' "$UEBA" | json_count anomalies) baseline=$(printf '%s' "$UEBA" | json_count baseline)"
CASES=$(api GET '/api/cases?limit=20')
summary "Cases: count=$(printf '%s' "$CASES" | json_count cases) top_case=$(printf '%s' "$CASES" | json_get cases.0.id)"
INTEL=$(api GET '/api/threatintel?limit=50')
summary "Threat Intel: iocs=$(printf '%s' "$INTEL" | json_count iocs) first_ioc=$(printf '%s' "$INTEL" | json_get iocs.0.ioc_value)"
GEO=$(api GET '/api/geomap')
summary "GeoMap: points=$(printf '%s' "$GEO" | json_count '')"
STATS=$(api GET '/api/stats')
MITRE=$(api GET '/api/analytics/mitre-summary?days=7')
summary "Analytics: total=$(printf '%s' "$STATS" | json_get total) alerts=$(printf '%s' "$STATS" | json_get alerts) mitre_rows=$(printf '%s' "$MITRE" | json_count rows)"
REPORTS=$(api GET '/api/reports/preview?component=summary')
summary "Reports: total_events=$(printf '%s' "$REPORTS" | json_get payload.metrics.totalEvents) open_cases=$(printf '%s' "$REPORTS" | json_get payload.metrics.openCases)"
ADMIN=$(api GET '/api/admin/version')
USERS=$(api GET '/api/admin/users')
summary "Admin: version=$(printf '%s' "$ADMIN" | json_get version) users=$(printf '%s' "$USERS" | json_count users)"
ER=$(api GET '/api/v11/entity-risk/summary')
summary "Entity Risk: hosts=$(printf '%s' "$ER" | json_count hosts) users=$(printf '%s' "$ER" | json_count users) ips=$(printf '%s' "$ER" | json_count ips)"
SIGMA=$(api GET '/api/v11/sigma/rules')
summary "Sigma: rules=$(printf '%s' "$SIGMA" | json_count rules)"
RESPA=$(api GET '/api/v11/response/actions?limit=20')
BLOCKED=$(api GET '/api/v11/response/blocked-ips')
summary "Response: actions=$(printf '%s' "$RESPA" | json_count actions) blocked_ips=$(printf '%s' "$BLOCKED" | json_count ips)"
OCSF=$(api GET '/api/v11/ocsf/summary')
summary "OCSF: rows=$(printf '%s' "$OCSF" | json_count summary)"
CLOUD=$(api GET '/api/v11/cloud/connectors')
summary "Cloud: connectors=$(printf '%s' "$CLOUD" | json_count connectors)"

api POST /api/auth/logout >/dev/null
printf '\nSaved summary to %s\n' "$OUT"
