#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
# SIEM WORM Tamper Simulation Test — v1.4.7
# Intentionally modifies a DB event and proves the chain detects it.
#
# Usage:
#   DB_PATH=/var/lib/siem-syslog/siem.db \
#   BASE=https://127.0.0.1 APP_PORT=18080 \
#   ADMIN_USER=admin ADMIN_PASS=secret \
#   bash tests/test-worm-tamper.sh
#
# ⚠ WARNING: This test MODIFIES the database. Run on a test instance only.
# It restores from backup automatically at the end.
# ═══════════════════════════════════════════════════════════════════════
set -euo pipefail
BASE="${BASE:-https://127.0.0.1}"
APP_PORT="${APP_PORT:-18080}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-admin}"
DB_PATH="${DB_PATH:-/var/lib/siem-syslog/siem.db}"
COOKIE="/tmp/worm-tamper-$$.cookie"
URL="${BASE}:${APP_PORT}"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'; BOLD='\033[1m'
PASS=0; FAIL=0
ok()   { echo -e "${GREEN}  ✓ PASS${NC} $*"; ((PASS++)); }
fail() { echo -e "${RED}  ✗ FAIL${NC} $*"; ((FAIL++)); }
info() { echo -e "${YELLOW}  →${NC} $*"; }
say()  { echo -e "\n${BOLD}$*${NC}"; }

cleanup() { rm -f "$COOKIE"; }
trap cleanup EXIT

api() {
  local method=$1 path=$2; shift 2
  curl -sk -c "$COOKIE" -b "$COOKIE" -X "$method" "${URL}${path}" \
    -H "Content-Type: application/json" "$@"
}

say "═══ WORM Tamper Simulation Test ═══"
echo "  DB: $DB_PATH"
echo "  Server: $URL"

# Login
LOGIN=$(api POST /api/auth/login -d "{\"username\":\"${ADMIN_USER}\",\"password\":\"${ADMIN_PASS}\"}")
echo "$LOGIN" | grep -q '"ok":true' && ok "Authenticated" || { fail "Login failed"; exit 1; }

# ── Step 1: Baseline verification ────────────────────────────────────────
say "Step 1 · Baseline chain verification"
BASELINE=$(api POST /api/v2/worm/verify -d '{"limit":500}')
BASELINE_OK=$(echo "$BASELINE" | python3 -c "import json,sys; print(str(json.load(sys.stdin).get('ok',False)).lower())" 2>/dev/null)
BASELINE_VER=$(echo "$BASELINE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('verified',0))" 2>/dev/null || echo 0)

if [[ "$BASELINE_OK" == "true" ]]; then
  ok "Chain intact before tamper (${BASELINE_VER} events verified)"
elif [[ "$BASELINE_VER" -eq 0 ]]; then
  info "No signed events yet — injecting test events first"
  # Inject some events to sign
  for i in 1 2 3 4 5; do
    api POST /api/inject -d "{\"raw\":\"<46>Jan 01 00:00:0${i} test-host sshd: tamper-test event ${i}\"}" > /dev/null 2>&1
    sleep 0.1
  done
  BASELINE=$(api POST /api/v2/worm/verify -d '{"limit":500}')
  BASELINE_VER=$(echo "$BASELINE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('verified',0))" 2>/dev/null || echo 0)
  ok "Injected and signed ${BASELINE_VER} events"
else
  fail "Baseline chain already broken — run on a clean instance"
  exit 1
fi

[[ "$BASELINE_VER" -lt 1 ]] && { fail "No HMAC signatures found — is WORM enabled?"; exit 1; }

# ── Step 2: Backup DB ────────────────────────────────────────────────────
say "Step 2 · Backup database before tamper"
BACKUP_PATH="/tmp/siem-worm-test-backup-$$.db"
if [[ -f "$DB_PATH" ]]; then
  cp "$DB_PATH" "$BACKUP_PATH" && ok "Backup at ${BACKUP_PATH}"
else
  info "DB not at $DB_PATH — using API-triggered backup"
  api POST /api/admin/backup/run -d '{}' > /dev/null
  BACKUP_PATH="API_BACKUP"
fi

# ── Step 3: Get target event ID ───────────────────────────────────────────
say "Step 3 · Select target event for tampering"
EVENTS=$(api GET "/api/events?limit=10&q=tamper-test")
TARGET_ID=$(echo "$EVENTS" | python3 -c "
import json,sys
evs=json.load(sys.stdin).get('events',[])
signed=[e for e in evs if e.get('hmac_hash','')]
if signed: print(signed[0]['id'])
else: print(evs[0]['id'] if evs else '')
" 2>/dev/null)

[[ -z "$TARGET_ID" ]] && { fail "No events found to tamper with"; exit 1; }
ORIG_MSG=$(echo "$EVENTS" | python3 -c "
import json,sys
evs=json.load(sys.stdin).get('events',[])
for e in evs:
  if str(e.get('id','')) == '${TARGET_ID}': print(e.get('message','')[:60])
" 2>/dev/null)
ok "Target event ID: ${TARGET_ID} — message: ${ORIG_MSG}"

# ── Step 4: Tamper the event ───────────────────────────────────────────────
say "Step 4 · Tamper with event ID ${TARGET_ID} via direct DB write"
if [[ -f "$DB_PATH" ]]; then
  sqlite3 "$DB_PATH" \
    "UPDATE events SET message='[TAMPERED by worm-test] This message was maliciously modified' WHERE id=${TARGET_ID};" \
    && ok "Event ${TARGET_ID} message tampered in DB" \
    || { fail "sqlite3 write failed (may need sqlite3 installed)"; }
else
  fail "Cannot directly tamper — DB at ${DB_PATH} not accessible (run as root or adjust DB_PATH)"
  info "Skipping direct tamper test"
fi

# ── Step 5: Verify chain detects the tamper ──────────────────────────────
say "Step 5 · Run chain verification — must detect tamper"
TAMPER_RESULT=$(api POST /api/v2/worm/verify -d '{"limit":1000,"generate_report":true}')
TAMPER_OK=$(echo "$TAMPER_RESULT" | python3 -c "import json,sys; print(str(json.load(sys.stdin).get('ok',True)).lower())" 2>/dev/null)
BROKEN_AT=$(echo "$TAMPER_RESULT" | python3 -c "import json,sys; print(json.load(sys.stdin).get('broken_at','none'))" 2>/dev/null)
HAS_REPORT=$(echo "$TAMPER_RESULT" | python3 -c "import json,sys; d=json.load(sys.stdin); print('yes' if d.get('tamper_report') else 'no')" 2>/dev/null)

if [[ "$TAMPER_OK" == "false" ]]; then
  ok "Tamper DETECTED: ok=false, broken_at=${BROKEN_AT}"
else
  fail "Tamper NOT detected — WORM chain did not report a break (ok=${TAMPER_OK})"
fi

if [[ "$HAS_REPORT" == "yes" ]]; then
  INCIDENT_TYPE=$(echo "$TAMPER_RESULT" | python3 -c "import json,sys; print(json.load(sys.stdin).get('tamper_report',{}).get('incident_type','?'))" 2>/dev/null)
  ok "Tamper report generated: incident_type=${INCIDENT_TYPE}"
else
  fail "No tamper_report in response — generateTamperReport not firing"
fi

# ── Step 6: Check tamper alert appeared in SIEM ───────────────────────────
say "Step 6 · Verify EMERG alert appeared in SIEM stream"
sleep 1
ALERTS=$(api GET "/api/alerts?limit=10")
TAMPER_ALERT=$(echo "$ALERTS" | python3 -c "
import json,sys
alerts=json.load(sys.stdin).get('alerts',[])
for a in alerts:
  if 'WORM' in a.get('rule_name','') or 'tamper' in a.get('message','').lower(): print(a.get('rule_name','')); break
" 2>/dev/null)
[[ -n "$TAMPER_ALERT" ]] && ok "EMERG alert in stream: ${TAMPER_ALERT}" || fail "No WORM tamper alert found in alerts stream"

# ── Step 7: Spot-check the specific event ──────────────────────────────────
say "Step 7 · Spot-check tampered event via verify-event API"
SPOT=$(api GET "/api/v2/worm/verify-event/${TARGET_ID}")
SPOT_OK=$(echo "$SPOT" | python3 -c "import json,sys; print(str(json.load(sys.stdin).get('ok',True)).lower())" 2>/dev/null)
[[ "$SPOT_OK" == "false" ]] && ok "Spot-check confirms: event ${TARGET_ID} fails HMAC verification" || fail "Spot-check did not detect tamper on event ${TARGET_ID}"

# ── Step 8: Restore DB ────────────────────────────────────────────────────
say "Step 8 · Restore database from backup"
if [[ -f "$BACKUP_PATH" ]]; then
  cp "$BACKUP_PATH" "$DB_PATH" && rm -f "$BACKUP_PATH"
  ok "Database restored from backup"
  # Verify chain is clean again
  sleep 1
  RESTORE_CHECK=$(api POST /api/v2/worm/verify -d '{"limit":500}')
  RESTORE_OK=$(echo "$RESTORE_CHECK" | python3 -c "import json,sys; print(str(json.load(sys.stdin).get('ok',False)).lower())" 2>/dev/null)
  [[ "$RESTORE_OK" == "true" ]] && ok "Chain verified clean after restore" || fail "Chain still broken after restore — manual inspection needed"
else
  info "No backup file to restore (skipped or API backup used)"
fi

# ── Summary ──────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════"
echo " WORM Tamper Simulation: ${PASS} PASS / ${FAIL} FAIL"
echo "════════════════════════════════════════"
[[ $FAIL -eq 0 ]] && exit 0 || exit 1
