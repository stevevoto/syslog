#!/usr/bin/env bash
# LEGACY WRAPPER — kept for backward compatibility only.
# PRIMARY regression entrypoint: tests/test-all-regress.sh
echo "NOTE: test-allv13.sh is a legacy wrapper. Using tests/test-all-regress.sh instead."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "${SCRIPT_DIR}/test-all-regress.sh" "$@"
