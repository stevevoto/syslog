# Linux Packaging

Use one application build and package it as:
- `.rpm` for Rocky / RHEL / Alma / CentOS
- `.deb` for Ubuntu / Debian
- `.tar.gz` as a universal fallback

## Quick start

```bash
bash packaging/build-native-packages.sh auto
```

Targets:

```bash
bash packaging/build-native-packages.sh rpm
bash packaging/build-native-packages.sh deb
bash packaging/build-native-packages.sh tar
```
