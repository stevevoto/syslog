#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${OUT:-$ROOT/dist-packages}"
TARGET="${1:-auto}"
PKG_NAME="siem-syslog"
VERSION="$(python3 - "$ROOT/app/package.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1])).get('version','1.4.7'))
PY
)"
mkdir -p "$OUT"
case "$TARGET" in
  auto)
    if command -v rpmbuild >/dev/null 2>&1 && { [[ -r /etc/redhat-release ]] || [[ -r /etc/rocky-release ]]; }; then TARGET=rpm;
    elif command -v dpkg-deb >/dev/null 2>&1; then TARGET=deb;
    else TARGET=tar; fi ;;
  rpm|deb|tar) ;;
  *) echo "usage: $0 [auto|rpm|deb|tar]"; exit 2 ;;
esac

if [[ "$TARGET" == tar ]]; then
  tar --exclude dist-packages -czf "$OUT/${PKG_NAME}-${VERSION}.tar.gz" -C "$(dirname "$ROOT")" "$(basename "$ROOT")"
  echo "$OUT/${PKG_NAME}-${VERSION}.tar.gz"
  exit 0
fi

if [[ "$TARGET" == deb ]]; then
  STAGE="$OUT/debroot"
  rm -rf "$STAGE"
  mkdir -p "$STAGE/opt/siem-syslog" "$STAGE/DEBIAN"
  rsync -a --delete --exclude dist-packages --exclude .git "$ROOT/" "$STAGE/opt/siem-syslog/"
  cat > "$STAGE/DEBIAN/control" <<EOC
Package: ${PKG_NAME}
Version: ${VERSION}
Section: admin
Priority: optional
Architecture: all
Maintainer: SIEM Team
Depends: bash, coreutils, rsync, systemd, nginx, openssl, curl, python3
Description: SIEM Syslog Command Center
 Commercial SIEM installer bundle for Ubuntu/Debian.
EOC
  cat > "$STAGE/DEBIAN/preinst" <<'EOP'
#!/usr/bin/env bash
set -e
if systemctl list-unit-files --type=service 2>/dev/null | awk '{print $1}' | grep -qx 'siem-syslog.service'; then
  systemctl stop siem-syslog || true
fi
EOP
  chmod 755 "$STAGE/DEBIAN/preinst"
  cat > "$STAGE/DEBIAN/postinst" <<'EOP'
#!/usr/bin/env bash
set -e
cd /opt/siem-syslog
bash scripts/install-or-upgrade.sh
EOP
  chmod 755 "$STAGE/DEBIAN/postinst"
  dpkg-deb --build "$STAGE" "$OUT/${PKG_NAME}_${VERSION}_all.deb"
  echo "$OUT/${PKG_NAME}_${VERSION}_all.deb"
  exit 0
fi

if [[ "$TARGET" == rpm ]]; then
  if ! command -v rpmbuild >/dev/null 2>&1; then
    echo "rpmbuild is required to create an RPM. Build this on Rocky/RHEL or install rpm-build." >&2
    exit 3
  fi
  RPMTOP="$OUT/rpmbuild"
  rm -rf "$RPMTOP"
  mkdir -p "$RPMTOP"/{BUILD,BUILDROOT,RPMS,SOURCES,SPECS,SRPMS}
  tar --exclude dist-packages -czf "$RPMTOP/SOURCES/${PKG_NAME}-${VERSION}.tar.gz" -C "$(dirname "$ROOT")" "$(basename "$ROOT")"
  cp "$ROOT/packaging/rpm/${PKG_NAME}.spec" "$RPMTOP/SPECS/"
  rpmbuild --define "_topdir $RPMTOP" -ba "$RPMTOP/SPECS/${PKG_NAME}.spec"
  find "$RPMTOP/RPMS" -type f -name '*.rpm' -print
fi
