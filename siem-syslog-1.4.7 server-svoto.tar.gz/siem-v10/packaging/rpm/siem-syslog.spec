Name:           siem-syslog
Version:        1.4.7
Release:        1%{?dist}
Summary:        SIEM Syslog Command Center
License:        Proprietary
BuildArch:      noarch
Requires:       bash, rsync, systemd, nginx, openssl, curl, python3
Source0:        %{name}-%{version}.tar.gz

%description
Commercial SIEM Syslog Command Center for Rocky Linux / RHEL family systems.

%prep
%setup -q -n siem-v10

%build

%install
mkdir -p %{buildroot}/opt/siem-syslog
cp -a . %{buildroot}/opt/siem-syslog/

%pre
if systemctl list-unit-files --type=service 2>/dev/null | awk '{print $1}' | grep -qx 'siem-syslog.service'; then
  systemctl stop siem-syslog || true
fi

%post
cd /opt/siem-syslog
bash scripts/install-or-upgrade.sh || true

%files
/opt/siem-syslog

%changelog
* Wed Apr 08 2026 SIEM Team - 1.4.7-1
- Initial RPM package
