#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${BASE_URL:-https://127.0.0.1}"
AGENT_KEY="${AGENT_KEY:-}"
MSG="${1:-<134>agent-host agent: test event}"
[[ -n "$AGENT_KEY" ]] || { echo "Set AGENT_KEY" >&2; exit 1; }
# Escape any double-quotes in the message then send via agent API
SAFE_MSG="${MSG//\"/\'}"
curl -sk \
  -H "Content-Type: application/json" \
  -H "X-Agent-Key: ${AGENT_KEY}" \
  -d "{\"events\":[\"${SAFE_MSG}\"]}" \
  "${BASE_URL}/api/ingest/agent"
