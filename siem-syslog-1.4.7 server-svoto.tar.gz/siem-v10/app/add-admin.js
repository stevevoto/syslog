#!/usr/bin/env node
/**
 * SIEM — Emergency Admin User Tool
 * Usage:  sudo node add-admin.js
 *         sudo node add-admin.js --username ops --password SecurePass1!
 *         sudo node add-admin.js --reset admin NewPassword1!
 *
 * Works even when auth is locked (no users, forgotten password, etc.)
 * Does NOT require a running server — reads config.json directly.
 */
'use strict';
const fs     = require('fs');
const crypto = require('crypto');
const path   = require('path');
const readline = require('readline');

const CFG_PATH = process.env.SIEM_CONFIG || '/etc/siem-syslog/config.json';

function hashPassword(password) {
  const salt    = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 64, { N:16384, r:8, p:1 });
  return `scrypt$16384$8$1$${salt.toString('base64')}$${derived.toString('base64')}`;
}

function loadConfig() {
  try {
    return JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));
  } catch (e) {
    console.error(`\n[ERROR] Cannot read config: ${CFG_PATH}\n  ${e.message}`);
    console.error('  Try: sudo node add-admin.js  (requires root or file access)\n');
    process.exit(1);
  }
}

function saveConfig(cfg) {
  try {
    if (cfg.auth && Array.isArray(cfg.auth.users) && cfg.auth.users.length > 0) { cfg.adminUser = cfg.auth.users[0].username; cfg.adminPasswordHash = cfg.auth.users[0].passwordHash; }
    fs.writeFileSync(CFG_PATH, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
    return true;
  } catch (e) {
    console.error(`\n[ERROR] Cannot write config: ${e.message}\n`);
    return false;
  }
}

function prompt(question, hidden = false) {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    if (hidden && process.stdin.isTTY) {
      process.stdout.write(question);
      process.stdin.setRawMode(true);
      let input = '';
      process.stdin.resume();
      process.stdin.on('data', ch => {
        ch = ch.toString();
        if (ch === '\n' || ch === '\r' || ch === '\u0004') {
          process.stdin.setRawMode(false);
          process.stdout.write('\n');
          rl.close();
          resolve(input);
        } else if (ch === '\u0003') {
          process.exit(0);
        } else if (ch === '\u007f') {
          if (input.length > 0) { input = input.slice(0, -1); process.stdout.clearLine(0); process.stdout.cursorTo(0); process.stdout.write(question + '*'.repeat(input.length)); }
        } else {
          input += ch;
          process.stdout.write('*');
        }
      });
    } else {
      rl.question(question, answer => { rl.close(); resolve(answer); });
    }
  });
}

async function main() {
  const args = process.argv.slice(2);
  const isReset  = args[0] === '--reset';
  const isAuto   = args[0] === '--username';

  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║  SIEM — Emergency Admin User Tool                ║');
  console.log(`╚══════════════════════════════════════════════════╝`);
  console.log(`\n  Config: ${CFG_PATH}\n`);

  const cfg = loadConfig();
  if (!cfg.auth) cfg.auth = { enabled: true, users: [] };
  if (!Array.isArray(cfg.auth.users)) cfg.auth.users = [];

  const existingUsers = cfg.auth.users;
  console.log(`  Current users: ${existingUsers.length === 0 ? '(none)' : existingUsers.map(u => `${u.username} [${u.role}]`).join(', ')}\n`);

  let username, password, displayName, role = 'admin';

  if (isReset && args[1] && args[2]) {
    // Non-interactive: node add-admin.js --reset username newpass
    username = args[1];
    password = args[2];
    const user = existingUsers.find(u => u.username === username);
    if (!user) { console.error(`  [ERROR] User '${username}' not found.\n`); process.exit(1); }
    user.passwordHash = hashPassword(password);
    user.enabled = true;
    if (saveConfig(cfg)) {
      console.log(`  ✓ Password reset for '${username}'.\n`);
      console.log('  Run: sudo systemctl restart siem-syslog\n');
    }
    return;
  }

  if (isAuto && args[1]) {
    // Non-interactive: node add-admin.js --username ops --password Pass1!
    username = args[1];
    const pwIdx = args.indexOf('--password');
    password = pwIdx !== -1 ? args[pwIdx + 1] : null;
    const roleIdx = args.indexOf('--role');
    role = roleIdx !== -1 ? args[roleIdx + 1] : 'admin';
    displayName = username;
    if (!password) { console.error('  [ERROR] --password required\n'); process.exit(1); }
  } else {
    // Interactive mode
    console.log('  Leave blank to use the default shown in [brackets].\n');

    const mode = await prompt('  Action: (1) Create user  (2) Reset password  [1]: ');
    if (mode.trim() === '2') {
      const target = await prompt('  Username to reset: ');
      const user   = existingUsers.find(u => u.username === target.trim());
      if (!user) { console.error(`\n  [ERROR] User '${target}' not found.\n`); process.exit(1); }
      const p1 = await prompt('  New password (min 8 chars): ', true);
      const p2 = await prompt('  Confirm new password: ', true);
      if (p1 !== p2)          { console.error('\n  [ERROR] Passwords do not match.\n'); process.exit(1); }
      if (p1.length < 8)      { console.error('\n  [ERROR] Password too short.\n'); process.exit(1); }
      user.passwordHash = hashPassword(p1);
      user.enabled = true;
      if (saveConfig(cfg)) {
        console.log(`\n  ✓ Password reset for '${target.trim()}'.\n`);
        console.log('  Run: sudo systemctl restart siem-syslog\n');
      }
      return;
    }

    // Create new user
    const uDefault = existingUsers.length === 0 ? 'admin' : '';
    const rawU  = await prompt(`  Username [${uDefault || 'required'}]: `);
    username    = rawU.trim().toLowerCase() || uDefault;
    if (!username) { console.error('\n  [ERROR] Username required.\n'); process.exit(1); }
    if (!/^[a-z0-9_.-]+$/.test(username)) { console.error('\n  [ERROR] Use only a-z, 0-9, _ . -\n'); process.exit(1); }
    if (existingUsers.find(u => u.username === username)) { console.error(`\n  [ERROR] User '${username}' already exists. Use --reset to change password.\n`); process.exit(1); }

    const rawD  = await prompt(`  Display name [${username}]: `);
    displayName = rawD.trim() || username;

    const rawR  = await prompt('  Role (admin/analyst/viewer) [admin]: ');
    role        = ['admin','analyst','viewer'].includes(rawR.trim()) ? rawR.trim() : 'admin';

    const p1 = await prompt('  Password (min 8 chars): ', true);
    const p2 = await prompt('  Confirm password: ', true);
    if (p1 !== p2)       { console.error('\n  [ERROR] Passwords do not match.\n'); process.exit(1); }
    if (p1.length < 8)   { console.error('\n  [ERROR] Password must be at least 8 characters.\n'); process.exit(1); }
    password = p1;
  }

  // Write user
  if (existingUsers.find(u => u.username === username)) {
    console.error(`\n  [ERROR] User '${username}' already exists.\n`);
    process.exit(1);
  }
  existingUsers.push({ username, passwordHash: hashPassword(password), role, displayName: displayName || username, enabled: true });
  cfg.auth.enabled = true;

  if (saveConfig(cfg)) {
    console.log(`\n  ✓ User created:`);
    console.log(`    Username:     ${username}`);
    console.log(`    Display name: ${displayName || username}`);
    console.log(`    Role:         ${role}`);
    console.log('\n  Run this to apply:');
    console.log('    sudo systemctl restart siem-syslog\n');
  } else {
    console.error('  [ERROR] Failed to save. Try running with sudo.\n');
    process.exit(1);
  }
}

main().catch(e => { console.error('\n[FATAL]', e.message); process.exit(1); });
