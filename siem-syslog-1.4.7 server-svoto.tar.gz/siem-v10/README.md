# SIEM Syslog Command Center v1.4.7

Real-time security event monitoring with live filtering, AI-powered analysis, and automated response.

---

## Requirements

| Item | Minimum |
|------|---------|
| OS | Ubuntu 20.04 / 22.04 / 24.04 LTS (64-bit) |
| CPU | 2 cores |
| RAM | 4 GB |
| Disk | 50 GB |
| Node.js | 18 or 20 (installed automatically if missing) |

---

## Quick Install (Fresh Server)

```bash
# 1. Extract the package
tar -xzf siem-syslog-1.4.7-*.tar.gz
cd siem-v10

# 2. Run the installer (requires sudo)
sudo bash install.sh
```

The installer will prompt for:
- **Admin username** — your first admin account
- **Admin password** — must be strong (8+ chars, mixed case)
- **Agent shared key** — used by the syslog agent scripts

It then:
- Creates a `siem-syslog` system user
- Installs Node.js 20 if not present
- Installs npm dependencies
- Sets up data directory at `/var/lib/siem-syslog/`
- Creates and starts the `siem-syslog` systemd service
- Generates a self-signed TLS certificate for encrypted syslog

---

## Upgrade (Existing Install)

```bash
# Extract new package alongside existing files
tar -xzf siem-syslog-1.4.7-*.tar.gz
cd siem-v10

# Push new code into the live install — preserves config and data
sudo bash ./sync-after-install.sh
sudo systemctl restart siem-syslog
```

---

## Optional: HTTPS via Nginx Reverse Proxy

The app listens on HTTP port 18080 internally. For a browser-accessible HTTPS endpoint:

```bash
sudo bash extras/https-selfsigned/apply-siem-https-selfsigned.sh
```

This installs nginx, generates a self-signed certificate, and proxies `https://YOUR_IP/` → `http://127.0.0.1:18080`.

> **Do not** browse directly to `https://127.0.0.1:18080` — that port is plain HTTP.

---

## Access the Dashboard

```
http://YOUR_SERVER_IP:18080        # direct (if no nginx)
https://YOUR_SERVER_IP             # after nginx overlay
```

Log in with the admin credentials you set during install.

---

## Validate the Install

```bash
sudo env ADMIN_USER='admin' ADMIN_PASS='YOUR_PASSWORD' STRICT=true \
  /opt/siem-syslog/scripts/run-post-install-validation.sh
```

Expected: all sections PASS. The CMDB sync section requires at least one configured source — it's yellow by default on a fresh install.

---

## Send Logs to the SIEM

### rsyslog (recommended)

Add to `/etc/rsyslog.conf` or `/etc/rsyslog.d/99-siem.conf`:

```
# UDP (fast, no guarantee)
*.* @YOUR_SIEM_IP:55140

# TCP (reliable)
*.* @@YOUR_SIEM_IP:55141

# TCP + TLS (encrypted)
$DefaultNetstreamDriver gtls
$ActionSendStreamDriverMode 1
$ActionSendStreamDriverAuthMode anon
*.* @@YOUR_SIEM_IP:6514
```

Then restart: `sudo systemctl restart rsyslog`

### syslog-ng

```
destination d_siem {
  network("YOUR_SIEM_IP" port(55141) transport("tcp"));
};
log { source(s_local); destination(d_siem); };
```

### Windows Event Forwarding (Winlogbeat / NXLog)

Send to `YOUR_SIEM_IP:55141` (TCP) or `55140` (UDP) in CEF or raw syslog format.

### Direct API inject (any HTTP client)

```bash
curl -sk -H "Content-Type: application/json" \
  -d '{"raw":"<134>Apr 09 12:00:00 myhost myapp: test event"}' \
  http://YOUR_SIEM_IP:18080/api/inject
```

### Agent script (Linux hosts)

```bash
AGENT_KEY='your-shared-key' \
BASE_URL='https://YOUR_SIEM_IP' \
bash /opt/siem-syslog/agents/linux/siem-agent.sh "<134>$(date) $(hostname) myapp: test"
```

---

## Ports

| Port | Protocol | Purpose |
|------|----------|---------|
| 18080 | TCP | Dashboard and REST API |
| 55140 | UDP | Syslog ingest |
| 55141 | TCP | Syslog ingest (reliable) |
| 6514 | TCP/TLS | Syslog ingest (encrypted) |
| 80 | TCP | HTTP redirect (nginx only) |
| 443 | TCP | HTTPS dashboard (nginx only) |

**Firewall (ufw):**
```bash
sudo ufw allow 18080/tcp
sudo ufw allow 55140/udp
sudo ufw allow 55141/tcp
sudo ufw allow 6514/tcp
# If using nginx:
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

---

## Service Management

```bash
sudo systemctl status siem-syslog      # check running
sudo systemctl restart siem-syslog     # restart
sudo systemctl stop siem-syslog        # stop
sudo journalctl -u siem-syslog -f      # tail logs
```

---

## Add or Reset an Admin Account

```bash
node /opt/siem-syslog/app/add-admin.js USERNAME PASSWORD
```

---

## Backup and Restore

```bash
# Trigger a backup via API (with active session cookie)
curl -sk -b /tmp/siem.cookie \
  -X POST http://localhost:18080/api/admin/backup/run

# Or using the system helper
sudo siem-syslog-backup-node /var/backups/siem-syslog

# Schedule nightly at 02:15
sudo siem-syslog-install-backup-cron /var/backups/siem-syslog '15 2 * * *'

# Restore
sudo systemctl stop siem-syslog
sudo siem-syslog-restore-node /path/to/backup.tar.gz
sudo systemctl start siem-syslog
```

---

## AI Analyst (Optional — Free)

The built-in AI Analyst connects to Claude to answer questions about your live security data.

**Setup:**
1. Get a free API key at [console.anthropic.com](https://console.anthropic.com) (free credits, no card required)
2. Either set it before starting the service:
   ```bash
   # Add to /etc/systemd/system/siem-syslog.service under [Service]:
   Environment="ANTHROPIC_API_KEY=sk-ant-..."
   sudo systemctl daemon-reload && sudo systemctl restart siem-syslog
   ```
3. Or paste it directly in the dashboard: click **🤖 AI Analyst** → enter key in the banner

**Example questions you can ask:**
- *"What are the most critical alerts right now?"*
- *"Are there signs of brute force activity?"*
- *"Which host has the highest risk score?"*
- *"Summarize the last 24 hours of authentication events"*

---

## Live Stream Filtering

The live stream works like a packet capture — all events are buffered (up to 5,000), and the visible stream shows only matching events in real time.

**Severity chips** — click any of `EMERG ALERT CRIT ERR WARNING NOTICE INFO DEBUG` to toggle that level on/off instantly.

**Column scope chips** — control what columns the search box searches:

| Chip | Searches |
|------|---------|
| Time | `HH:MM:SS` displayed timestamp |
| Host | Source hostname |
| Facility | Syslog facility (auth, kern, local0…) |
| Severity | CRIT, WARNING, INFO… |
| ECS Cat | authentication, network, intrusion_detection… |
| Message | Full event message body |

**Examples:**
- Type `auth` with only **ECS Cat** → all authentication events only
- Type `185.220` with only **Message** → events containing that IP in the message
- Type `10:30` with only **Time** → events in the 10:30 minute
- Type `kern` with only **Facility** → kernel syslog events only

Changing a filter instantly rebuilds the visible stream from the buffer — no page reload, no scroll jump.

---

## Compliance Reports

```bash
# SOC 2 evidence report (last 30 days)
curl -sk -b /tmp/siem.cookie \
  "http://localhost:18080/api/reports/compliance/soc2?hours=720"

# ISO 27001 / NIS2 / DORA also available
# Download as Markdown file:
curl -sk -b /tmp/siem.cookie \
  "http://localhost:18080/api/reports/compliance/nis2/download" \
  -o nis2-evidence.md
```

Supported frameworks: `soc2`, `iso27001`, `nis2`, `dora`

---

## Key Directories

| Path | Contents |
|------|---------|
| `/opt/siem-syslog/` | Application code |
| `/var/lib/siem-syslog/` | Database, backups |
| `/etc/siem-syslog/` | Config, TLS certificates |
| `/var/log/siem-syslog/` | Validation and service logs |
| `/opt/siem-syslog/compliance/` | Compliance artifact templates |

---

## ⚠️ Security Notes

- **Rotate credentials immediately** after install — do not use default or test passwords in production
- The admin password set during install is the only credential — store it securely
- The agent shared key should be rotated if it was ever logged or shared
- WORM chain key is at `~/.siem-hmac-key` for the service account — **back this up separately**. If lost, the integrity chain cannot be re-verified
- TLS syslog (port 6514) uses a self-signed certificate — configure your senders to accept it or replace with a CA-signed cert

---

## OpenAPI / REST API

Interactive API docs available at:
```
http://YOUR_SIEM_IP:18080/api/docs
```

Or download the spec:
```
http://YOUR_SIEM_IP:18080/api/docs/openapi.yaml
```

61 endpoints documented including ingest, search, cases, compliance, WORM, cloud connectors, LDAP sync, response actions, and the AI analyst.

---

## Support & Known Limits

| Limit | Value |
|-------|-------|
| Max sustained ingest | ~5,000 EPS (single node) |
| Practical DB size | ~10 GB (~50M events) |
| Live stream buffer | 5,000 events |
| Visible stream rows | 400 matching events |
| Backup type | Full snapshot (not incremental) |
| Live response actions | Require `sudo` on SIEM host |
| Cloud connectors | Need live credential validation per tenant |
| Multi-node / HA | Not supported in v1.4.7 |

For LDAP setup: `docs/LDAP_VALIDATION_GUIDE.md`
For WORM incident response: `docs/WORM_TAMPER_RUNBOOK.md`
For admin operations: `docs/ADMIN_GUIDE.md`
For commercial scope and support boundaries: `COMMERCIAL_SCOPE.md`
