# Enterprise standard ports

Recommended enterprise profile:
- HTTPS UI/API: 443/tcp
- HTTP redirect: 80/tcp
- Syslog UDP: 514/udp
- Syslog TCP (reliable syslog-conn): 601/tcp
- Syslog TLS: 6514/tcp

Current lab/test profile in this build:
- Syslog UDP: 55140/udp
- Syslog TCP: 55141/tcp
- Syslog TLS: 6514/tcp
- Internal app: 18080/tcp
- HTTPS: 443/tcp
- HTTP redirect: 80/tcp

Recommendation:
Keep the current lab profile for validation, then add an installer port-profile switch
so operators can choose Lab or Enterprise Standard Ports.
