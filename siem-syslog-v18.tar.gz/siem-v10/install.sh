#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/siem-syslog}"
CONFIG_DIR="${CONFIG_DIR:-/etc/siem-syslog}"
CONFIG_FILE="${CONFIG_FILE:-$CONFIG_DIR/config.json}"
LOG_DIR="${LOG_DIR:-/var/log/siem-syslog}"
DATA_DIR="${DATA_DIR:-/var/lib/siem-syslog}"
SSL_DIR="${SSL_DIR:-$CONFIG_DIR/ssl}"
APP_USER="${APP_USER:-siem-syslog}"
APP_GROUP="${APP_GROUP:-siem-syslog}"
SERVICE_NAME="${SERVICE_NAME:-siem-syslog}"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
NGINX_SITE_DEB="/etc/nginx/sites-available/${SERVICE_NAME}.conf"
NGINX_SITE_RHEL="/etc/nginx/conf.d/${SERVICE_NAME}.conf"
NGINX_SITE="${NGINX_SITE_DEB}"
NGINX_ENABLED="/etc/nginx/sites-enabled/${SERVICE_NAME}.conf"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RELEASE_VERSION="${RELEASE_VERSION:-1.4.7}"

APP_HTTP_PORT="${APP_HTTP_PORT:-18080}"
UDP_PORT="${UDP_PORT:-55140}"
TCP_PORT="${TCP_PORT:-55141}"
TLS_SYSLOG_PORT="${TLS_SYSLOG_PORT:-6514}"
DEMO_MODE="${DEMO_MODE:-false}"
DEMO_INTERVAL_MS="${DEMO_INTERVAL_MS:-500}"
PUBLIC_HTTP_PORT="${PUBLIC_HTTP_PORT:-80}"
PUBLIC_HTTPS_PORT="${PUBLIC_HTTPS_PORT:-443}"
prompt_text() {
  local __var="$1"
  local __label="$2"
  local __default="${3:-}"
  local __value=""
  if [[ -n "$__default" ]]; then
    read -e -r -p "$__label [$__default]: " __value
    __value="${__value:-$__default}"
  else
    read -e -r -p "$__label: " __value
  fi
  printf -v "$__var" '%s' "$__value"
}

prompt_secret_confirm() {
  local __var="$1"
  local __label="$2"
  local __a="" __b=""
  while true; do
    read -e -r -s -p "$__label: " __a; echo
    read -e -r -s -p "Confirm $__label: " __b; echo
    if [[ -z "${__a}" ]]; then
      echo "Password cannot be blank."
      continue
    fi
    if [[ "${__a}" != "${__b}" ]]; then
      echo "Passwords do not match. Try again."
      continue
    fi
    printf -v "$__var" '%s' "$__a"
    break
  done
}

PORT_PROFILE_DEFAULT="${PORT_PROFILE_DEFAULT:-enterprise}"
CERT_DAYS="${CERT_DAYS:-825}"
CERT_CN="${CERT_CN:-$(hostname -f 2>/dev/null || hostname)}"
ADMIN_USERNAME="${ADMIN_USERNAME:-admin}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-}"
AGENT_SHARED_KEY="${AGENT_SHARED_KEY:-$(openssl rand -hex 24)}"
WIPE_EXISTING="${WIPE_EXISTING:-true}"
SUDOERS_FILE="/etc/sudoers.d/${SERVICE_NAME}-restart"
RESTART_HELPER="/usr/local/bin/${SERVICE_NAME}-self-restart"
SNAPSHOT_HELPER="/usr/local/bin/siem-syslog-snapshot-export"
BACKUP_HELPER="/usr/local/bin/siem-syslog-backup-node"
RESTORE_HELPER="/usr/local/bin/siem-syslog-restore-node"
BACKUP_CRON_HELPER="/usr/local/bin/siem-syslog-install-backup-cron"
REPORT_CRON_HELPER="/usr/local/bin/siem-syslog-install-report-cron"
REPORT_RUN_HELPER="/usr/local/bin/siem-syslog-run-report"
SYNC_HELPER="/usr/local/bin/siem-syslog-sync-live"
REPORT_ENV_FILE="${CONFIG_DIR}/report-scheduler.env"
BACKUP_DIR_DEFAULT="${BACKUP_DIR_DEFAULT:-/var/backups/siem-syslog}"
REPORT_OUTPUT_DEFAULT="${REPORT_OUTPUT_DEFAULT:-/var/backups/siem-syslog/reports}"
BACKUP_CRON_EXPR="${BACKUP_CRON_EXPR:-15 2 * * *}"
REPORT_CRON_EXPR="${REPORT_CRON_EXPR:-30 2 * * *}"
REPORT_COMPONENT_DEFAULT="${REPORT_COMPONENT_DEFAULT:-summary}"
RUN_POST_INSTALL_VALIDATION="${RUN_POST_INSTALL_VALIDATION:-true}"
VALIDATION_STRICT="${VALIDATION_STRICT:-true}"
VALIDATION_LOG_DIR="${VALIDATION_LOG_DIR:-/var/log/siem-syslog/validation}"
COMPLIANCE_DIR="${COMPLIANCE_DIR:-$APP_DIR/compliance}"

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo or as root."
  exit 1
fi


detect_os_family() {
  if [[ -r /etc/os-release ]]; then
    . /etc/os-release
    local like="${ID_LIKE:-}"
    local id="${ID:-}"
    if [[ "$like" == *debian* ]] || [[ "$id" == "ubuntu" ]] || [[ "$id" == "debian" ]]; then
      OS_FAMILY="debian"
    elif [[ "$like" == *rhel*   ]] || [[ "$like" == *fedora* ]] ||          [[ "$id"   == "rhel"   ]] || [[ "$id"   == "rocky"     ]] ||          [[ "$id"   == "almalinux" ]] || [[ "$id" == "centos"   ]] ||          [[ "$id"   == "ol"     ]] || [[ "$id"   == "fedora"    ]] ||          [[ "$id"   == "amzn"   ]]; then
      OS_FAMILY="rhel"
    else
      OS_FAMILY="unknown"
    fi
    OS_ID="${id}"
    OS_VERSION_ID="${VERSION_ID:-}"
  else
    OS_FAMILY="unknown"
    OS_ID="unknown"
    OS_VERSION_ID=""
  fi
  echo "[INFO] Detected OS: ID=${OS_ID} VERSION=${OS_VERSION_ID} family=${OS_FAMILY}"
}



service_exists() {
  systemctl list-unit-files --type=service 2>/dev/null | awk '{print $1}' | grep -qx "${1}.service"
}

our_nginx_site_present() {
  [[ -f "$NGINX_ENABLED" || -f "$NGINX_SITE" ||      -f "/etc/nginx/conf.d/${SERVICE_NAME}.conf" ||      -f "/etc/nginx/sites-available/${SERVICE_NAME}.conf" ]]
}

seed_default_asset_identity() {
  local app_dir="${APP_DIR:-/opt/siem-syslog}"
  local db_path="${DATA_DIR:-/var/lib/siem-syslog}/events.db"

  python3 - "$db_path" <<'PY'
import json, sqlite3, sys, time
from pathlib import Path

db = Path(sys.argv[1])
db.parent.mkdir(parents=True, exist_ok=True)
conn = sqlite3.connect(str(db))
cur = conn.cursor()

# asset / identity tables are created defensively if missing
cur.execute("""
CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hostname TEXT,
  ip TEXT,
  type TEXT,
  source TEXT,
  raw_json TEXT,
  created_at INTEGER
)
""")
cur.execute("""
CREATE TABLE IF NOT EXISTS identities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  display_name TEXT,
  source TEXT,
  raw_json TEXT,
  created_at INTEGER
)
""")

now = int(time.time())

# seed asset if none with hostname exists
row = cur.execute("SELECT id FROM assets WHERE COALESCE(hostname,'') <> '' LIMIT 1").fetchone()
if not row:
    asset = {
        "hostname": "siem-localhost",
        "ip": "127.0.0.1",
        "type": "server",
        "source": "installer-seed"
    }
    cur.execute(
        "INSERT INTO assets (hostname, ip, type, source, raw_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (asset["hostname"], asset["ip"], asset["type"], asset["source"], json.dumps(asset), now)
    )

# seed identity if none with username exists
row = cur.execute("SELECT id FROM identities WHERE COALESCE(username,'') <> '' LIMIT 1").fetchone()
if not row:
    ident = {
        "username": "admin",
        "displayName": "Primary Admin",
        "source": "installer-seed"
    }
    cur.execute(
        "INSERT INTO identities (username, display_name, source, raw_json, created_at) VALUES (?, ?, ?, ?, ?)",
        (ident["username"], ident["displayName"], ident["source"], json.dumps(ident), now)
    )

conn.commit()
conn.close()
print("Seeded default asset/identity if needed")
PY
}

stop_our_stack_for_upgrade() {
  local stopped_any=false
  if service_exists "$SERVICE_NAME"; then
    if systemctl is-active --quiet "$SERVICE_NAME" || systemctl is-failed --quiet "$SERVICE_NAME"; then
      echo "Detected existing ${SERVICE_NAME}; stopping it temporarily for upgrade port checks..."
      systemctl stop "$SERVICE_NAME" || true
      systemctl reset-failed "$SERVICE_NAME" || true
      stopped_any=true
    fi
  fi
  # Do not stop nginx globally unless our site appears to be installed and enabled.
  if our_nginx_site_present && systemctl is-active --quiet nginx; then
    echo "Detected nginx with ${SERVICE_NAME} site; stopping nginx temporarily for upgrade port checks..."
    systemctl stop nginx || true
    stopped_any=true
  fi
  if [[ "$stopped_any" == true ]]; then
    sleep 2
  fi
}


# ════════════════════════════════════════════════════════════════════════════
# PRE-INSTALL: FULL PORT + PROCESS CLEANUP
# Runs BEFORE any port selection so all target ports are guaranteed free.
# ════════════════════════════════════════════════════════════════════════════
pre_install_cleanup() {
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Pre-install check — clearing previous SIEM installation"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # ── 1. Stop and disable the systemd service ─────────────────────────────
  for svc in siem-syslog siem_syslog SIEMSyslog; do
    if systemctl list-units --full -all 2>/dev/null | grep -q "${svc}"; then
      echo "  [stop]   Stopping service: ${svc}"
      systemctl stop    "${svc}" 2>/dev/null || true
      systemctl disable "${svc}" 2>/dev/null || true
      systemctl reset-failed "${svc}" 2>/dev/null || true
      sleep 1
    fi
  done

  # ── 2. Kill any remaining node/siem processes on SIEM ports ────────────
  echo "  [kill]   Killing stray node / siem processes..."
  # Kill by name first
  pkill -9 -f "server-v3.js"       2>/dev/null || true
  pkill -9 -f "siem-syslog"        2>/dev/null || true
  pkill -9 -f "siem-service.js"    2>/dev/null || true
  sleep 1

  # Kill anything still holding our default ports
  for port in 18080 8443 55140 55141 6514 514 601 80 443; do
    _pids="$(lsof -ti :"${port}" 2>/dev/null || fuser "${port}/tcp" 2>/dev/null || true)"
    if [[ -n "$_pids" ]]; then
      # Don't kill nginx or apache — they're system services we manage separately
      for _pid in $_pids; do
        _comm="$(ps -p "$_pid" -o comm= 2>/dev/null || true)"
        if [[ "$_comm" == "node" || "$_comm" == "node.js" ]]; then
          echo "  [kill]   Port ${port} held by node (pid ${_pid}) — killing"
          kill -9 "$_pid" 2>/dev/null || true
        fi
      done
    fi
  done
  sleep 1

  # ── 3. Remove old systemd unit file ─────────────────────────────────────
  for unit_file in /etc/systemd/system/siem-syslog.service \
                   /etc/systemd/system/SIEMSyslog.service \
                   /lib/systemd/system/siem-syslog.service; do
    if [[ -f "$unit_file" ]]; then
      echo "  [remove] Old unit file: ${unit_file}"
      rm -f "$unit_file"
    fi
  done
  systemctl daemon-reload 2>/dev/null || true

  # ── 4. Flush old iptables PREROUTING rules for ports 514/601 ────────────
  echo "  [flush]  Clearing old port-514 iptables redirect rules..."
  for attempt in 1 2 3 4 5; do
    _rule="$(iptables -t nat -L PREROUTING --line-numbers -n 2>/dev/null \
              | grep -E ':(514|601)' | awk '{print $1}' | head -1 || true)"
    [[ -z "$_rule" ]] && break
    iptables -t nat -D PREROUTING "$_rule" 2>/dev/null || break
  done

  # ── 5. Stop nginx if our site config is present (will be rewritten) ─────
  if our_nginx_site_present && systemctl is-active --quiet nginx 2>/dev/null; then
    echo "  [stop]   Stopping nginx (SIEM site config will be refreshed)"
    systemctl stop nginx 2>/dev/null || true
  fi

  # ── 6. Verify ports are now free ──────────────────────────────────────────
  echo "  [check]  Verifying ports are free..."
  local any_blocked=false
  for chk_port in 18080 8443 55140 55141 6514; do
    _holder="$(ss -ltnpH "sport = :${chk_port}" 2>/dev/null | head -1 || true)"
    if [[ -n "$_holder" ]]; then
      # Ignore nginx holding 80/443 — we configure that ourselves
      if [[ "$_holder" == *'"nginx"'* && ( "$chk_port" == "80" || "$chk_port" == "443" ) ]]; then
        continue
      fi
      echo "  [warn]   Port ${chk_port} still in use by: ${_holder}"
      any_blocked=true
    else
      echo "  [ok]     Port ${chk_port} is free"
    fi
  done

  if [[ "$any_blocked" == "true" ]]; then
    echo ""
    echo "  [warn]   Some ports are still occupied."
    echo "           The installer will prompt you to choose alternate ports."
  fi

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
}

port_owner_line() {
  local port="$1" proto="$2"
  if [[ "$proto" == "udp" ]]; then
    ss -lunpH "sport = :${port}" 2>/dev/null | head -n1 || true
  else
    ss -ltnpH "sport = :${port}" 2>/dev/null | head -n1 || true
  fi
}

choose_port_if_busy() {
  local var_name="$1" port="$2" proto="$3" label="$4"
  local line alt owner_pid service_pid
  line="$(port_owner_line "$port" "$proto")"
  [[ -z "$line" ]] && return 0

  service_pid="$(systemctl show -p MainPID --value "$SERVICE_NAME" 2>/dev/null || true)"

  # If the listener is clearly ours, reuse it without prompting.
  if [[ -n "${service_pid:-}" && "$service_pid" != "0" && "$line" == *"pid=${service_pid}"* ]]; then
    echo "$label port ${port}/${proto} is currently used by ${SERVICE_NAME}. Reusing it."
    return 0
  fi
  if [[ "$line" == *"users:((\"node\""* ]] && service_exists "$SERVICE_NAME"; then
    echo "$label port ${port}/${proto} appears to be used by an installed ${SERVICE_NAME} instance. Reusing it."
    return 0
  fi
  if [[ "$line" == *"users:((\"nginx\""* ]] && our_nginx_site_present; then
    echo "$label port ${port}/${proto} is currently used by nginx with the ${SERVICE_NAME} site. Reusing it."
    return 0
  fi

  echo "$label port ${port}/${proto} is busy: $line"
  while true; do
    read -e -r -p "Enter alternate ${label} port: " alt
    alt="${alt//$''/}"
    alt="${alt//$''/}"
    if [[ -z "${alt:-}" ]]; then
      echo "Port cannot be blank."
      continue
    fi
    if ! [[ "$alt" =~ ^[0-9]+$ ]] || (( alt < 1 || alt > 65535 )); then
      echo "Enter a valid port number between 1 and 65535."
      continue
    fi
    line="$(port_owner_line "$alt" "$proto")"
    if [[ -n "$line" ]]; then
      echo "Port ${alt}/${proto} is also busy: $line"
      continue
    fi
    printf -v "$var_name" '%s' "$alt"
    break
  done
}



ask_yes_no() {
  local prompt="$1"
  local default="${2:-n}"
  local answer
  read -e -r -p "  ${prompt} " answer
  answer="${answer:-$default}"
  [[ "${answer,,}" == "y" || "${answer,,}" == "yes" ]]
}

log_info() { echo "[INFO] $*"; }
log_warn() { echo "[WARN] $*"; }
log_err()  { echo "[ERROR] $*"; }

command_missing() { ! command -v "$1" >/dev/null 2>&1; }


rhel_missing_packages() {
  local pkgs=()
  command_missing curl     && pkgs+=(curl)
  command_missing python3  && pkgs+=(python3)
  command_missing unzip    && pkgs+=(unzip)
  command_missing openssl  && pkgs+=(openssl)
  command_missing gcc      && pkgs+=(gcc)
  command_missing make     && pkgs+=(make)
  ! rpm -q gcc-c++ &>/dev/null && pkgs+=(gcc-c++)
  ! rpm -q ca-certificates &>/dev/null && pkgs+=(ca-certificates)
  printf '%s
' "${pkgs[@]}" | awk 'NF && !seen[$0]++'
}

debian_missing_packages() {
  local pkgs=()
  command_missing curl && pkgs+=(curl)
  command_missing gpg && pkgs+=(gnupg)
  command_missing python3 && pkgs+=(python3)
  command_missing unzip && pkgs+=(unzip)
  command_missing openssl && pkgs+=(openssl)
  command_missing nginx && pkgs+=(nginx)
  command_missing make && pkgs+=(make)
  command_missing gcc && pkgs+=(gcc)
  command_missing g++ || dpkg -l g++ >/dev/null 2>&1 || pkgs+=(g++)
  dpkg -l build-essential >/dev/null 2>&1 || pkgs+=(build-essential)
  [[ ! -x /usr/sbin/update-ca-certificates && ! -x /usr/bin/update-ca-certificates ]] && pkgs+=(ca-certificates)
  printf '%s
' "${pkgs[@]}" | awk 'NF && !seen[$0]++'
}

quiesce_apt_services() {
  local units=(
    apt-daily.timer
    apt-daily-upgrade.timer
    apt-daily.service
    apt-daily-upgrade.service
    unattended-upgrades.service
    packagekit.service
    packagekit-offline-update.service
  )
  local unit
  for unit in "${units[@]}"; do
    if systemctl list-unit-files "$unit" >/dev/null 2>&1; then
      systemctl stop "$unit" >/dev/null 2>&1 || true
      systemctl reset-failed "$unit" >/dev/null 2>&1 || true
    fi
  done
}

apt_lock_holders() {
  local lock_files=(
    /var/lib/dpkg/lock-frontend
    /var/lib/dpkg/lock
    /var/lib/apt/lists/lock
    /var/cache/apt/archives/lock
  )
  local file pids pid comm
  declare -A seen=()

  for file in "${lock_files[@]}"; do
    [[ -e "$file" ]] || continue
    if command -v fuser >/dev/null 2>&1; then
      for pid in $(fuser "$file" 2>/dev/null); do
        [[ -n "$pid" ]] || continue
        seen["$pid"]=1
      done
    elif command -v lsof >/dev/null 2>&1; then
      for pid in $(lsof -t "$file" 2>/dev/null); do
        [[ -n "$pid" ]] || continue
        seen["$pid"]=1
      done
    fi
  done

  for pid in "${!seen[@]}"; do
    comm="$(ps -p "$pid" -o comm= 2>/dev/null | awk '{print $1}' || true)"
    [[ -n "$comm" ]] || comm="unknown"
    printf '%s:%s\n' "$pid" "$comm"
  done | sort -n
}

wait_for_apt_activity() {
  local timeout="${1:-120}"
  local start now pids
  start="$(date +%s)"
  while true; do
    pids="$(apt_lock_holders)"
    if [[ -z "${pids}" ]]; then
      return 0
    fi
    now="$(date +%s)"
    if (( now - start >= timeout )); then
      log_err "Timed out waiting for package manager lock holders to exit: ${pids//$'
'/, }"
      return 1
    fi
    log_warn "Package manager busy, waiting for lock holders to finish: ${pids//$'
'/, }"
    sleep 5
  done
}

force_recover_apt_state() {
  local pids="$(apt_lock_holders)"
  [[ -n "$pids" ]] || return 0

  log_warn "APT remained locked too long. Attempting safe recovery from lingering auto-update processes."
  quiesce_apt_services

  pkill -TERM -x unattended-upgr >/dev/null 2>&1 || true
  pkill -TERM -x apt >/dev/null 2>&1 || true
  pkill -TERM -x apt-get >/dev/null 2>&1 || true
  pkill -TERM -x aptitude >/dev/null 2>&1 || true
  pkill -TERM -x packagekitd >/dev/null 2>&1 || true
  sleep 8

  pids="$(apt_lock_holders)"
  if [[ -n "$pids" ]]; then
    log_warn "Still locked after graceful stop attempt: ${pids//$'
'/, }"
    pkill -KILL -x unattended-upgr >/dev/null 2>&1 || true
    pkill -KILL -x apt >/dev/null 2>&1 || true
    pkill -KILL -x apt-get >/dev/null 2>&1 || true
    pkill -KILL -x aptitude >/dev/null 2>&1 || true
    pkill -KILL -x packagekitd >/dev/null 2>&1 || true
    sleep 3
  fi

  if pgrep -x dpkg >/dev/null 2>&1; then
    log_warn "dpkg is still present after stopping auto-updates. Attempting package database recovery."
  fi
  dpkg --configure -a >/dev/null 2>&1 || true
  apt-get -f install -y >/dev/null 2>&1 || true

  pids="$(apt_lock_holders)"
  if [[ -n "$pids" ]]; then
    log_err "APT/dpkg lock holders remain after recovery attempt: ${pids//$'
'/, }"
    return 1
  fi
  return 0
}

repair_google_linux_repo() {
  local key_url="https://dl.google.com/linux/linux_signing_key.pub"
  local keyring="/etc/apt/keyrings/google-linux.gpg"
  local trusted="/etc/apt/trusted.gpg.d/google.gpg"
  local found=false
  if grep -RqsE 'dl\.google\.com/linux/(chrome|packages)/deb' /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null; then
    found=true
  fi
  [[ "$found" == true ]] || return 0

  install -d -m 0755 /etc/apt/keyrings /etc/apt/trusted.gpg.d
  if curl -fsSL "$key_url" | gpg --dearmor > "$keyring.tmp"; then
    install -m 0644 "$keyring.tmp" "$keyring"
    install -m 0644 "$keyring.tmp" "$trusted"
    rm -f "$keyring.tmp"
    log_info "Refreshed Google Linux repository signing key."
  else
    rm -f "$keyring.tmp"
    log_warn "Could not refresh Google Linux repository signing key; continuing with existing key material."
  fi

  # Normalize common google-chrome .list entries to use signed-by and https.
  if [[ -f /etc/apt/sources.list.d/google-chrome.list ]]; then
    cat > /etc/apt/sources.list.d/google-chrome.list <<EOF
# managed by siem-syslog installer to keep Chrome repo key current
deb [arch=amd64 signed-by=${keyring}] https://dl.google.com/linux/chrome/deb/ stable main
EOF
  fi

  # For deb822 sources files, ensure Signed-By is present when the Google repo is used.
  while IFS= read -r f; do
    if grep -qs 'dl.google.com/linux/chrome/deb' "$f" && ! grep -qs '^Signed-By:' "$f"; then
      cp -a "$f" "$f.bak.$(date +%s)"
      awk -v keyring="$keyring" '
        BEGIN{done=0}
        {print}
        /^URIs:[[:space:]]*https:\/\/dl\.google\.com\/linux\/chrome\/deb\/?$/ && !done {print "Signed-By: " keyring; done=1}
      ' "$f" > "$f.tmp" && mv "$f.tmp" "$f"
    fi
  done < <(find /etc/apt/sources.list.d -maxdepth 1 -type f \( -name '*.sources' -o -name '*.list' \) 2>/dev/null)
}

apt_get_safe() {
  quiesce_apt_services
  if ! wait_for_apt_activity 20; then
    force_recover_apt_state || true
    wait_for_apt_activity 20 || {
      log_err "Package manager is still locked after recovery attempts."
      return 1
    }
  fi
  repair_google_linux_repo || true
  apt-get \
    -o DPkg::Lock::Timeout=60 \
    -o Acquire::Retries=5 \
    -o Acquire::https::Timeout=30 \
    -o Acquire::http::Timeout=30 \
    "$@"
}

install_os_deps() {
  # ── Force IPv4 for apt to prevent IPv6 timeout hangs ──────────────────
  # Many Ubuntu machines have IPv6 configured but non-functional.
  # apt tries IPv6 first and hangs for 60+ seconds per mirror.
  if [[ ! -f /etc/apt/apt.conf.d/99force-ipv4 ]]; then
    echo 'Acquire::ForceIPv4 "true";' > /etc/apt/apt.conf.d/99force-ipv4
    log_info "Set apt to IPv4-only (avoids IPv6 timeout hangs)"
  fi
  # Also set a short connection timeout so failures are fast
  if [[ ! -f /etc/apt/apt.conf.d/99timeout ]]; then
    printf 'Acquire::http::Timeout "30";
Acquire::https::Timeout "30";
Acquire::Retries "2";
' \
      > /etc/apt/apt.conf.d/99timeout
  fi
  echo "[1/14] Installing OS dependencies..."
  detect_os_family
  export DEBIAN_FRONTEND=noninteractive
  case "${OS_FAMILY}" in
    debian)
      mapfile -t missing_pkgs < <(debian_missing_packages)
      if (( ${#missing_pkgs[@]} == 0 )); then
        log_info "Required OS dependencies already present. Skipping apt package install."
      else
        log_info "Missing Debian/Ubuntu packages: ${missing_pkgs[*]}"
        apt_get_safe update
        apt_get_safe install -y "${missing_pkgs[@]}"
      fi
      ;;
    rhel)
      if command -v dnf >/dev/null 2>&1; then PM=dnf; else PM=yum; fi
      mapfile -t rhel_pkgs < <(rhel_missing_packages)
      if (( ${#rhel_pkgs[@]} > 0 )); then
        $PM -y install "${rhel_pkgs[@]}" gnupg2 tar || true
      fi
      $PM -y install curl ca-certificates gnupg2 gcc gcc-c++ make python3 tar unzip openssl
      # nginx: official nginx.org/rhel/ repo (correct path for OL8/OL9, RHEL8/9, Rocky, Alma)
      install_nginx_rhel() {
        command -v nginx >/dev/null 2>&1 && { log_info "nginx already present: $(nginx -v 2>&1)"; return 0; }
        cat > /etc/yum.repos.d/nginx-official.repo <<'REPO'
[nginx-stable]
name=nginx stable repo
baseurl=https://nginx.org/packages/rhel/$releasever/$basearch/
gpgcheck=1
enabled=1
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true
REPO
        rpm --import https://nginx.org/keys/nginx_signing.key 2>/dev/null || true
        log_info "Trying nginx from nginx.org/packages/rhel/..."
        if $PM -y install nginx 2>/dev/null; then log_info "nginx installed from nginx.org"; return 0; fi
        log_warn "nginx.org repo failed — trying dnf module nginx:mainline"
        rm -f /etc/yum.repos.d/nginx-official.repo
        $PM module reset nginx -y 2>/dev/null || true
        $PM module enable nginx:mainline -y 2>/dev/null || $PM module enable nginx:stable -y 2>/dev/null || true
        if $PM -y install nginx 2>/dev/null; then log_info "nginx installed via dnf module"; return 0; fi
        log_warn "dnf module failed — trying EPEL"
        $PM -y install epel-release 2>/dev/null ||           $PM -y install oracle-epel-release-el"${OS_VERSION_ID%%.*}" 2>/dev/null || true
        $PM -y install nginx && log_info "nginx installed via EPEL" && return 0
        log_err "All nginx install methods failed. Try: dnf module enable nginx:mainline && dnf install nginx"
        return 1
      }
      install_nginx_rhel
      update-ca-trust extract 2>/dev/null || true
      ;;
    *)
      echo "Unsupported OS family. Supported: Debian/Ubuntu and RHEL/Rocky/Alma/CentOS Stream."
      exit 1
      ;;
  esac
}

install_node20_if_needed() {
  echo "[2/14] Installing Node.js 20 if needed..."
  local need=yes
  if command -v node >/dev/null 2>&1; then
    local major
    major="$(node -v 2>/dev/null | sed 's/^v//' | cut -d. -f1 || echo 0)"
    if [[ "${major}" -ge 18 ]]; then need=no; fi
  fi
  [[ "$need" == "yes" ]] || return 0
  case "${OS_FAMILY}" in
    debian)
      install -d -m 0755 /etc/apt/keyrings
      if [[ ! -f /etc/apt/keyrings/nodesource.gpg ]]; then
        curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
      fi
      echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
      apt_get_safe update
      apt_get_safe install -y nodejs
      ;;
    rhel)
      curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
      if command -v dnf >/dev/null 2>&1; then dnf -y install nodejs; else yum -y install nodejs; fi
      ;;
  esac
}

required_files=(
  "$BUNDLE_DIR/app/server-v3.js"
  "$BUNDLE_DIR/app/dashboard-v3.html"
  "$BUNDLE_DIR/app/package.json"
  "$BUNDLE_DIR/app/add-admin.js"
  "$BUNDLE_DIR/app/lib/ocsf-mapper.js"
  "$BUNDLE_DIR/app/lib/sigma-engine.js"
  "$BUNDLE_DIR/app/lib/entity-risk.js"
  "$BUNDLE_DIR/app/lib/response-actions.js"
  "$BUNDLE_DIR/app/lib/storage-policy.js"
  "$BUNDLE_DIR/app/lib/cloud-connectors.js"
  "$BUNDLE_DIR/app/lib/v11-extensions.js"
  "$BUNDLE_DIR/app/public/index.html"
  "$BUNDLE_DIR/wipe-data.sh"
  "$BUNDLE_DIR/scripts/schema-migrate.py"
  "$BUNDLE_DIR/scripts/snapshot-export.sh"
  "$BUNDLE_DIR/scripts/backup-node.sh"
  "$BUNDLE_DIR/scripts/restore-node.sh"
  "$BUNDLE_DIR/scripts/install-backup-cron.sh"
  "$BUNDLE_DIR/scripts/install-report-cron.sh"
  "$BUNDLE_DIR/scripts/run-report-scheduled.sh"
  "$BUNDLE_DIR/scripts/generate-third-party-notices.py"
  "$BUNDLE_DIR/scripts/generate-compliance-artifacts.py"
  "$BUNDLE_DIR/scripts/check-license-policy.py"
  "$BUNDLE_DIR/scripts/run-post-install-validation.sh"
  "$BUNDLE_DIR/scripts/build-sea-binary.sh"
  "$BUNDLE_DIR/PROPRIETARY_NOTICE.md"
  "$BUNDLE_DIR/OPEN_SOURCE_COMPLIANCE.md"
  "$BUNDLE_DIR/COMPLIANCE_RELEASE_GUIDE.md"
  "$BUNDLE_DIR/LICENSES/README.md"
  "$BUNDLE_DIR/LICENSES/SOURCE_DISCLOSURE_TEMPLATE.md"
  "$BUNDLE_DIR/agents/linux/siem-agent.sh"
  "$BUNDLE_DIR/tests/test-all.sh"
  "$BUNDLE_DIR/tests/test-quick.sh"
  "$BUNDLE_DIR/tests/test-allv13v3.sh"
)
for f in "${required_files[@]}"; do
  [[ -f "$f" ]] || { echo "Bundle file missing: $f"; exit 1; }
done

# ── Global defaults (apply whether interactive or non-interactive) ─────
HTTP_BIND_ADDR="${HTTP_BIND_ADDR:-0.0.0.0}"
UDP_BIND_ADDR="${UDP_BIND_ADDR:-0.0.0.0}"
TCP_BIND_ADDR="${TCP_BIND_ADDR:-0.0.0.0}"
HTTPS_ENABLED="${HTTPS_ENABLED:-true}"
HTTPS_PORT="${HTTPS_PORT:-8443}"

if [[ -t 0 ]]; then
  echo "siem-v${RELEASE_VERSION} installer setup"
  echo "Press Enter to accept the enterprise/default path shown in brackets."
  echo "Line editing is enabled for visible prompts (arrow keys/backspace)."
  echo "Fast path defaults: enterprise ports, default directories, [Y/n] prompts default to Yes, scheduled backups/reports enabled, and post-install validation enabled."
  echo
  prompt_text ADMIN_USERNAME_IN "Admin username" "${ADMIN_USERNAME}"
  if [[ -n "${ADMIN_USERNAME_IN}" ]]; then ADMIN_USERNAME="${ADMIN_USERNAME_IN}"; fi

  
if [[ -z "${ADMIN_PASSWORD}" ]]; then
    prompt_secret_confirm ADMIN_PASSWORD "Admin password"
  fi
  DEMO_MODE=false

  echo "Port profiles: enterprise=514/601/6514 + 80/443, lab=55140/55141/6514 + 80/443, custom=prompt per port. If our service is already using a port, the installer will stop it temporarily and reuse the same port."
  prompt_text PORT_PROFILE_IN "Port profile [enterprise/lab/custom]" "${PORT_PROFILE_DEFAULT}"
if [[ -n "${PORT_PROFILE_IN}" ]]; then PORT_PROFILE_DEFAULT="${PORT_PROFILE_IN,,}"; fi
pre_install_cleanup
stop_our_stack_for_upgrade
# Existing siem-syslog listeners are treated as upgrade/reuse, not foreign conflicts.

case "${PORT_PROFILE_DEFAULT}" in
  lab)
    UDP_PORT=55140; TCP_PORT=55141; TLS_SYSLOG_PORT=6514; APP_HTTP_PORT=18080; PUBLIC_HTTP_PORT=80; PUBLIC_HTTPS_PORT=443 ;;
  enterprise)
    UDP_PORT=514; TCP_PORT=601; TLS_SYSLOG_PORT=6514; APP_HTTP_PORT=18080; PUBLIC_HTTP_PORT=80; PUBLIC_HTTPS_PORT=443 ;;
  custom)
    read -erp "UDP syslog port [${UDP_PORT}]: " UDP_IN; [[ -n "${UDP_IN}" ]] && UDP_PORT="${UDP_IN}"
    read -erp "TCP syslog port [${TCP_PORT}]: " TCP_IN; [[ -n "${TCP_IN}" ]] && TCP_PORT="${TCP_IN}"
    read -erp "TLS syslog port [${TLS_SYSLOG_PORT}]: " TLS_IN; [[ -n "${TLS_IN}" ]] && TLS_SYSLOG_PORT="${TLS_IN}"
    read -erp "Internal app HTTP port [${APP_HTTP_PORT}]: " APPHTTP_IN; [[ -n "${APPHTTP_IN}" ]] && APP_HTTP_PORT="${APPHTTP_IN}"
    read -erp "Public HTTP port [${PUBLIC_HTTP_PORT}]: " PHTTP_IN; [[ -n "${PHTTP_IN}" ]] && PUBLIC_HTTP_PORT="${PHTTP_IN}"
    read -erp "Public HTTPS port [${PUBLIC_HTTPS_PORT}]: " PHTTPS_IN; [[ -n "${PHTTPS_IN}" ]] && PUBLIC_HTTPS_PORT="${PHTTPS_IN}" ;;
  *)
    echo "Unknown profile. Using enterprise."
    PORT_PROFILE_DEFAULT=enterprise
    UDP_PORT=514; TCP_PORT=601; TLS_SYSLOG_PORT=6514; APP_HTTP_PORT=18080; PUBLIC_HTTP_PORT=80; PUBLIC_HTTPS_PORT=443 ;;
esac

# ── HTTPS port selection ─────────────────────────────────────────────────────
HTTPS_CHOICE="1"
if [[ -t 0 ]]; then
  echo ""
  echo "HTTPS for the web dashboard:"
  echo "  1) Port 8443  — HTTPS on :8443, no root needed (recommended)"
  echo "  2) Port 443   — HTTPS on :443 via setcap"
  echo "  3) Skip       — HTTP only on :${APP_HTTP_PORT} (enable later)"
  read -e -r -p "  Choose [1/2/3, default=1]: " HTTPS_CHOICE
  HTTPS_CHOICE="${HTTPS_CHOICE:-1}"
fi

HTTPS_ENABLED="true"
HTTPS_PORT="8443"
case "$HTTPS_CHOICE" in
  2)
    HTTPS_PORT="443"
    NODE_BIN="$(command -v node 2>/dev/null || true)"
    if [[ -n "$NODE_BIN" ]]; then
      if setcap cap_net_bind_service=+ep "$NODE_BIN" 2>/dev/null; then
        echo "  [OK] setcap applied — Node.js can bind port 443 directly"
      else
        echo "  [WARN] setcap failed. Falling back to 8443."
        HTTPS_PORT="8443"
      fi
    fi
    ;;
  3)
    HTTPS_ENABLED="false"
    HTTPS_PORT="8443"
    echo "  [OK] Skipping HTTPS — dashboard will be HTTP only on :${APP_HTTP_PORT}"
    ;;
  *)
    echo "  [OK] HTTPS on port 8443"
    ;;
esac
echo ""

# (setcap handled above in HTTPS port selection)

# ── Interface / bind address selection ───────────────────────────────────────
if [[ -t 0 ]]; then
  echo ""
  echo "Network interface binding:"
  mapfile -t _IFACES < <(ip -4 addr show 2>/dev/null | grep -oP '(?<=inet )[0-9.]+' 2>/dev/null | grep -v '^127\.' 2>/dev/null || true)
  if [[ ${#_IFACES[@]} -gt 1 ]]; then
    echo "  Available IPs:"
    for _ip in "${_IFACES[@]}"; do echo "    $_ip"; done
  fi
  if ask_yes_no "Bind to all interfaces (0.0.0.0)? Recommended. [Y/n]" "y"; then
    HTTP_BIND_ADDR="0.0.0.0"; UDP_BIND_ADDR="0.0.0.0"; TCP_BIND_ADDR="0.0.0.0"
  else
    read -e -r -p "  HTTP bind IP [${_IFACES[0]:-0.0.0.0}]: " HTTP_BIND_ADDR
    HTTP_BIND_ADDR="${HTTP_BIND_ADDR:-${_IFACES[0]:-0.0.0.0}}"
    read -e -r -p "  Syslog bind IP [0.0.0.0=all]: " SYSLOG_BIND_ADDR
    SYSLOG_BIND_ADDR="${SYSLOG_BIND_ADDR:-0.0.0.0}"
    UDP_BIND_ADDR="$SYSLOG_BIND_ADDR"; TCP_BIND_ADDR="$SYSLOG_BIND_ADDR"
  fi
  echo "  HTTP: ${HTTP_BIND_ADDR}:${APP_HTTP_PORT}  UDP: ${UDP_BIND_ADDR}:${UDP_PORT}  TCP: ${TCP_BIND_ADDR}:${TCP_PORT}"
fi


choose_port_if_busy UDP_PORT "$UDP_PORT" udp "UDP syslog" 'users:\(\("node"|\("rsyslogd"'
choose_port_if_busy TCP_PORT "$TCP_PORT" tcp "TCP syslog" 'users:\(\("node"|\("rsyslogd"'
choose_port_if_busy TLS_SYSLOG_PORT "$TLS_SYSLOG_PORT" tcp "TLS syslog" 'users:\(\("node"'
choose_port_if_busy APP_HTTP_PORT "$APP_HTTP_PORT" tcp "internal app HTTP" 'users:\(\("node"'
choose_port_if_busy PUBLIC_HTTP_PORT "$PUBLIC_HTTP_PORT" tcp "public HTTP" 'users:\(\("nginx"'
choose_port_if_busy PUBLIC_HTTPS_PORT "$PUBLIC_HTTPS_PORT" tcp "public HTTPS" 'users:\(\("nginx"'

  read -e -r -p "Wipe existing runtime data before install? [Y/n]: " WIPE_IN
  case "${WIPE_IN,,}" in
    n|no) WIPE_EXISTING=false ;;
    *) WIPE_EXISTING=true ;;
  esac
  read -e -r -p "Backup directory [${BACKUP_DIR_DEFAULT}]: " BACKUP_DIR_IN
  if [[ -n "${BACKUP_DIR_IN}" ]]; then BACKUP_DIR_DEFAULT="${BACKUP_DIR_IN}"; fi
  read -e -r -p "Enable scheduled daily backups? [Y/n]: " BKS_IN
  case "${BKS_IN,,}" in
    n|no) BACKUP_SCHEDULE_ENABLED=false ;;
    *) BACKUP_SCHEDULE_ENABLED=true ;;
  esac
  read -e -r -p "Backup cron expression [${BACKUP_CRON_EXPR}]: " BKCRON_IN
  if [[ -n "${BKCRON_IN}" ]]; then BACKUP_CRON_EXPR="${BKCRON_IN}"; fi
  read -e -r -p "Report output directory [${REPORT_OUTPUT_DEFAULT}]: " RPTDIR_IN
  if [[ -n "${RPTDIR_IN}" ]]; then REPORT_OUTPUT_DEFAULT="${RPTDIR_IN}"; fi
  read -rp "Enable scheduled PDF reports? [Y/n]: " RPT_IN
  case "${RPT_IN,,}" in
    n|no) REPORT_SCHEDULE_ENABLED=false ;;
    *) REPORT_SCHEDULE_ENABLED=true ;;
  esac
  read -rp "Report cron expression [${REPORT_CRON_EXPR}]: " RPCRON_IN
  if [[ -n "${RPCRON_IN}" ]]; then REPORT_CRON_EXPR="${RPCRON_IN}"; fi
  read -rp "Scheduled report component [${REPORT_COMPONENT_DEFAULT}]: " RPCOMP_IN
  if [[ -n "${RPCOMP_IN}" ]]; then REPORT_COMPONENT_DEFAULT="${RPCOMP_IN}"; fi
  read -rp "Run full post-install validation now? [Y/n]: " VALIDATE_IN
  case "${VALIDATE_IN,,}" in
    n|no) RUN_POST_INSTALL_VALIDATION=false ;;
    *) RUN_POST_INSTALL_VALIDATION=true ;;
  esac
  read -rp "Fail install if validation fails? [Y/n]: " VSTRICT_IN
  case "${VSTRICT_IN,,}" in
    n|no) VALIDATION_STRICT=false ;;
    *) VALIDATION_STRICT=true ;;
  esac
  echo
fi
BACKUP_SCHEDULE_ENABLED="${BACKUP_SCHEDULE_ENABLED:-true}"
REPORT_SCHEDULE_ENABLED="${REPORT_SCHEDULE_ENABLED:-true}"
RUN_POST_INSTALL_VALIDATION="${RUN_POST_INSTALL_VALIDATION:-true}"
VALIDATION_STRICT="${VALIDATION_STRICT:-true}"

if [[ -z "$ADMIN_PASSWORD" ]]; then
  ADMIN_PASSWORD="$(openssl rand -base64 18 | tr -d '=+/' | cut -c1-20)"
  GENERATED_ADMIN_PASSWORD=true
else
  GENERATED_ADMIN_PASSWORD=false
fi
export ADMIN_PASSWORD
ADMIN_PASSWORD_HASH="$(python3 - <<'PY2'
import os, base64, hashlib
pw=os.environ['ADMIN_PASSWORD'].encode()
salt=os.urandom(16)
dk=hashlib.scrypt(pw, salt=salt, n=16384, r=8, p=1, dklen=64)
print(f"scrypt$16384$8$1${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}")
PY2
)"

install_os_deps
install_node20_if_needed

echo "[3/14] Creating service account and directories..."
getent group "$APP_GROUP" >/dev/null 2>&1 || groupadd --system "$APP_GROUP" || true
if ! id -u "$APP_USER" >/dev/null 2>&1; then
  NOLOGIN_SHELL="/sbin/nologin"
  [[ -x "/usr/sbin/nologin" ]] && NOLOGIN_SHELL="/usr/sbin/nologin"
  [[ -x "/sbin/nologin"     ]] && NOLOGIN_SHELL="/sbin/nologin"
  useradd --system --gid "$APP_GROUP" --home-dir "$DATA_DIR" --shell "$NOLOGIN_SHELL" "$APP_USER" || true
else
  log_info "User $APP_USER already exists — skipping useradd"
fi
mkdir -p "$APP_DIR/public" "$APP_DIR/tests" "$APP_DIR/scripts" "$CONFIG_DIR" "$LOG_DIR" "$DATA_DIR" "$SSL_DIR" "$DATA_DIR/archive" "$BACKUP_DIR_DEFAULT" "$REPORT_OUTPUT_DEFAULT"

if [[ "$WIPE_EXISTING" == "true" ]]; then
  echo "[4/14] Wiping existing runtime data before install..."
  rm -f "$DATA_DIR"/events.db "$DATA_DIR"/events.db-wal "$DATA_DIR"/events.db-shm
  rm -f "$LOG_DIR"/*.log || true
else
  echo "[4/14] Keeping existing runtime data..."
fi

echo "[5/14] Copying application and helper files..."
install -m 0755 "$BUNDLE_DIR/app/server-v3.js" "$APP_DIR/server-v3.js"
install -m 0644 "$BUNDLE_DIR/app/dashboard-v3.html" "$APP_DIR/dashboard-v3.html"
install -m 0644 "$BUNDLE_DIR/app/package.json" "$APP_DIR/package.json"
install -m 0755 "$BUNDLE_DIR/app/add-admin.js" "$APP_DIR/add-admin.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/cep-engine.js" "$APP_DIR/lib/cep-engine.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/cloud-connectors.js" "$APP_DIR/lib/cloud-connectors.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/cloud-demo.js" "$APP_DIR/lib/cloud-demo.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/cmdb-sync.js" "$APP_DIR/lib/cmdb-sync.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/enrichment-pipeline.js" "$APP_DIR/lib/enrichment-pipeline.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/entity-risk.js" "$APP_DIR/lib/entity-risk.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/event-parser.js" "$APP_DIR/lib/event-parser.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/genai-analyst.js" "$APP_DIR/lib/genai-analyst.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/identity-demo.js" "$APP_DIR/lib/identity-demo.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/ldap-sync.js" "$APP_DIR/lib/ldap-sync.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/log-forward.js" "$APP_DIR/lib/log-forward.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/ocsf-mapper.js" "$APP_DIR/lib/ocsf-mapper.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/okta-sync.js" "$APP_DIR/lib/okta-sync.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/pipeline-engine.js" "$APP_DIR/lib/pipeline-engine.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/playbook-engine.js" "$APP_DIR/lib/playbook-engine.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/remote-actions.js" "$APP_DIR/lib/remote-actions.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/response-actions.js" "$APP_DIR/lib/response-actions.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/saml.js" "$APP_DIR/lib/saml.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/sigma-engine.js" "$APP_DIR/lib/sigma-engine.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/sso.js" "$APP_DIR/lib/sso.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/storage-policy.js" "$APP_DIR/lib/storage-policy.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/totp.js" "$APP_DIR/lib/totp.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/v11-extensions.js" "$APP_DIR/lib/v11-extensions.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/webauthn.js" "$APP_DIR/lib/webauthn.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/webhooks.js" "$APP_DIR/lib/webhooks.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/worm-chain.js" "$APP_DIR/lib/worm-chain.js"
install -D -m 0644 "$BUNDLE_DIR/app/public/index.html" "$APP_DIR/public/index.html"
install -D -m 0644 "$BUNDLE_DIR/app/lib/event-parser.js" "$APP_DIR/lib/event-parser.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/enrichment-pipeline.js" "$APP_DIR/lib/enrichment-pipeline.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/ldap-sync.js" "$APP_DIR/lib/ldap-sync.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/okta-sync.js" "$APP_DIR/lib/okta-sync.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/playbook-engine.js" "$APP_DIR/lib/playbook-engine.js"
install -D -m 0644 "$BUNDLE_DIR/app/lib/worm-chain.js" "$APP_DIR/lib/worm-chain.js"
install -D -m 0644 "$BUNDLE_DIR/app/openapi.yaml" "$APP_DIR/openapi.yaml"
install -m 0755 "$BUNDLE_DIR/wipe-data.sh" "$APP_DIR/wipe-data.sh"
install -m 0755 "$BUNDLE_DIR/scripts/schema-migrate.py" "$APP_DIR/scripts/schema-migrate.py"
install -m 0755 "$BUNDLE_DIR/scripts/snapshot-export.sh" "$SNAPSHOT_HELPER"
install -m 0755 "$BUNDLE_DIR/scripts/backup-node.sh" "$BACKUP_HELPER"
install -m 0755 "$BUNDLE_DIR/scripts/restore-node.sh" "$RESTORE_HELPER"
install -m 0755 "$BUNDLE_DIR/scripts/install-backup-cron.sh" "$BACKUP_CRON_HELPER"
install -m 0755 "$BUNDLE_DIR/scripts/install-report-cron.sh" "$REPORT_CRON_HELPER"
install -m 0755 "$BUNDLE_DIR/scripts/run-report-scheduled.sh" "$REPORT_RUN_HELPER"
install -m 0755 "$BUNDLE_DIR/scripts/sync-live-tree.sh" "$SYNC_HELPER"
install -m 0755 "$BUNDLE_DIR/agents/linux/siem-agent.sh" /usr/local/share/siem-syslog-agent.sh
# Install siem-test command
if [[ -f "$BUNDLE_DIR/siem-test" ]]; then
  install -m 0755 "$BUNDLE_DIR/siem-test" /usr/local/bin/siem-test
  install -m 0755 "$BUNDLE_DIR/siem-test" "$APP_DIR/siem-test"
  log_info "siem-test installed -> run: siem-test"
fi
# Copy all test scripts to app dir
for _ts in "$BUNDLE_DIR/tests/"test-*.sh; do
  [[ -f "$_ts" ]] && install -D -m 0755 "$_ts" "$APP_DIR/tests/$(basename "$_ts")" || true
done
# Copy windows/ directory
if [[ -d "$BUNDLE_DIR/windows" ]]; then
  cp -r "$BUNDLE_DIR/windows" "$APP_DIR/windows"
  log_info "Windows scripts installed to $APP_DIR/windows/"
fi
# Install siem-test as a system-wide command
install -m 0755 "$APP_DIR/siem-test" /usr/local/bin/siem-test
# Also symlink into the app dir for relative use
ln -sf /usr/local/bin/siem-test "$APP_DIR/siem-test" 2>/dev/null || true
log_info "siem-test command installed → run: siem-test"


install -D -m 0644 "$BUNDLE_DIR/PROPRIETARY_NOTICE.md" "$APP_DIR/PROPRIETARY_NOTICE.md"
install -D -m 0644 "$BUNDLE_DIR/OPEN_SOURCE_COMPLIANCE.md" "$APP_DIR/OPEN_SOURCE_COMPLIANCE.md"
install -D -m 0644 "$BUNDLE_DIR/COMPLIANCE_RELEASE_GUIDE.md" "$APP_DIR/COMPLIANCE_RELEASE_GUIDE.md"
install -D -m 0644 "$BUNDLE_DIR/LICENSES/README.md" "$APP_DIR/LICENSES/README.md"
install -D -m 0644 "$BUNDLE_DIR/LICENSES/SOURCE_DISCLOSURE_TEMPLATE.md" "$APP_DIR/LICENSES/SOURCE_DISCLOSURE_TEMPLATE.md"
install -D -m 0644 "$BUNDLE_DIR/ENTERPRISE_PORT_PROFILES.md" "$APP_DIR/ENTERPRISE_PORT_PROFILES.md"
install -m 0755 "$BUNDLE_DIR/scripts/generate-third-party-notices.py" "$APP_DIR/scripts/generate-third-party-notices.py"
install -m 0755 "$BUNDLE_DIR/scripts/generate-compliance-artifacts.py" "$APP_DIR/scripts/generate-compliance-artifacts.py"
install -m 0755 "$BUNDLE_DIR/scripts/check-license-policy.py" "$APP_DIR/scripts/check-license-policy.py"
install -m 0755 "$BUNDLE_DIR/scripts/run-post-install-validation.sh" "$APP_DIR/scripts/run-post-install-validation.sh"
install -m 0755 "$BUNDLE_DIR/scripts/build-sea-binary.sh" "$APP_DIR/scripts/build-sea-binary.sh"
install -m 0755 "$BUNDLE_DIR/scripts/sync-live-tree.sh" "$APP_DIR/scripts/sync-live-tree.sh"
install -D -m 0644 "$BUNDLE_DIR/docs/ADMIN_GUIDE.md" "$APP_DIR/docs/ADMIN_GUIDE.md"
install -D -m 0644 "$BUNDLE_DIR/docs/LDAP_VALIDATION_GUIDE.md" "$APP_DIR/docs/LDAP_VALIDATION_GUIDE.md"
install -D -m 0644 "$BUNDLE_DIR/docs/WORM_TAMPER_RUNBOOK.md" "$APP_DIR/docs/WORM_TAMPER_RUNBOOK.md"
# Primary regression suite (commercial GA entrypoint)
install -D -m 0755 "$BUNDLE_DIR/tests/test-all-regress.sh" "$APP_DIR/tests/test-all-regress.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-smoke.sh"       "$APP_DIR/tests/test-smoke.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-destructive.sh" "$APP_DIR/tests/test-destructive.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-ui-e2e.sh"      "$APP_DIR/tests/test-ui-e2e.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-allv14.sh"      "$APP_DIR/tests/test-allv14.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-upgrade.sh"    "$APP_DIR/tests/test-upgrade.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-worm-tamper.sh" "$APP_DIR/tests/test-worm-tamper.sh"
# Supporting / legacy test scripts
install -D -m 0755 "$BUNDLE_DIR/tests/test-all.sh"         "$APP_DIR/tests/test-all.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-quick.sh"       "$APP_DIR/tests/test-quick.sh"
install -D -m 0755 "$BUNDLE_DIR/tests/test-allv13v3.sh"    "$APP_DIR/tests/test-allv13v3.sh"

echo "[5b/14] Syncing full bundle into live tree (deletes stale files)..."
APP_DIR="$APP_DIR" APP_USER="$APP_USER" APP_GROUP="$APP_GROUP" BUNDLE_DIR="$BUNDLE_DIR" SYNC_DELETE=true "$BUNDLE_DIR/scripts/sync-live-tree.sh"

echo "[6/14] Writing config file..."
cat > "$CONFIG_FILE" <<JSON
{
  "server": {
    "httpPort": ${APP_HTTP_PORT},
    "udpPort": ${UDP_PORT},
    "tcpPort": ${TCP_PORT},
    "maxEvents": 50000,
    "demoMode": ${DEMO_MODE},
    "demoIntervalMs": ${DEMO_INTERVAL_MS},
    "httpBindAddress": "${HTTP_BIND_ADDR:-0.0.0.0}",
    "udpBindAddress": "${UDP_BIND_ADDR:-0.0.0.0}",
    "tcpBindAddress": "${TCP_BIND_ADDR:-0.0.0.0}",
    "httpsEnabled": ${HTTPS_ENABLED:-true},
    "httpsPort": ${HTTPS_PORT:-8443}
  },
  "database": {
    "path": "${DATA_DIR}/events.db",
    "retainDays": 30,
    "vacuumHours": 6
  },
  "geoip": { "enabled": true },
  "slack": { "enabled": false, "webhookUrl": "", "minSeverity": "CRIT" },
  "email": {
    "enabled": false,
    "to": "",
    "from": "siem@localhost",
    "smtp": { "host": "localhost", "port": 25, "user": "", "pass": "" },
    "minSeverity": "CRIT",
    "throttleMin": 5
  },
  "ueba": { "enabled": true, "windowHours": 24, "stdDevThreshold": 2.5 },
  "threatIntel": { "enabled": true, "refreshMinutes": 60 },
  "correlation": { "windowSeconds": 300, "bruteForceThreshold": 5 },
  "normalization": { "schema": "ecs" },
  "cases": { "enabled": true, "autoCreateSeverity": "CRIT" },
  "tlsSyslog": {
    "enabled": true,
    "port": ${TLS_SYSLOG_PORT},
    "certPath": "${SSL_DIR}/selfsigned.crt",
    "keyPath": "${SSL_DIR}/selfsigned.key",
    "requestCert": false
  },
  "auth": {
    "enabled": true,
    "sessionSecret": "$(openssl rand -hex 32)",
    "sessionTtlHours": 12,
    "users": [
      {
        "username": "${ADMIN_USERNAME}",
        "passwordHash": "${ADMIN_PASSWORD_HASH}",
        "role": "admin",
        "displayName": "Primary Admin",
        "enabled": true
      }
    ]
  },
  "integrations": {
    "restartHelper": "${RESTART_HELPER}",
    "servicenow": {
      "enabled": false,
      "instanceUrl": "",
      "username": "",
      "password": "",
      "table": "incident",
      "assignmentGroup": "",
      "category": "security"
    },
    "jira": {
      "enabled": false,
      "baseUrl": "",
      "username": "",
      "apiToken": "",
      "projectKey": "",
      "issueType": "Incident"
    }
  },
  "phase2": {
    "alertDedupSeconds": 300,
    "alertSuppressionSeconds": 900,
    "agentSharedKey": "${AGENT_SHARED_KEY}",
    "archiveDir": "${DATA_DIR}/archive",
    "mitreSummaryDays": 7
  },
  "phase3": {
    "backupDir": "${BACKUP_DIR_DEFAULT}",
    "backupScheduleEnabled": ${BACKUP_SCHEDULE_ENABLED},
    "backupCron": "${BACKUP_CRON_EXPR}",
    "reportOutputDir": "${REPORT_OUTPUT_DEFAULT}",
    "reportScheduleEnabled": ${REPORT_SCHEDULE_ENABLED},
    "reportCron": "${REPORT_CRON_EXPR}",
    "reportComponent": "${REPORT_COMPONENT_DEFAULT}"
  },
  "phase4": {
    "alertRoutingEnabled": false,
    "alertRoutes": [{"name":"crit_to_outbox","enabled":true,"minSeverity":"CRIT","target":"outbox"}],
    "reportDeliveryEnabled": false,
    "reportDeliveryMode": "spool",
    "reportDeliveryTo": "",
    "reportDeliveryFrom": "siem@localhost",
    "outboxDir": "${DATA_DIR}/outbox",
    "reportDeliveryCron": "0 7 * * *",
    "reportDeliveryComponent": "summary",
    "healthWarnDiskPct": 85,
    "healthWarnMemoryPct": 85
},
"phase5": {
  "operationsEnabled": true,
  "upgradeChannel": "stable",
  "retentionDays": 30,
  "reportDeliveryEnabled": false,
  "reportDeliveryMode": "spool",
  "reportDeliveryTo": "",
  "reportDeliveryFrom": "siem@localhost",
  "reportDeliveryCron": "0 7 * * *",
  "reportDeliveryComponent": "summary",
  "outboxDir": "${DATA_DIR}/outbox",
  "healthWarnDiskPct": 85,
  "healthWarnMemoryPct": 85,
  "alertRoutes": [{"name":"crit_to_outbox","enabled":true,"minSeverity":"CRIT","target":"outbox"}]
},
"phase6": {
  "autoDisableDemoAfterClear": true,
  "requireTypedConfirm": true,
  "clearConfirmPhrase": "WIPE ALL",
  "freshStartEnabled": true
  },
  "phase7": {
    "keepDataOnRefresh": true,
    "liveResetEnabled": true,
    "reportsUiEnabled": true,
    "reportDefaultHours": 24
  },
  "phase8": {
    "themeSelectionEnabled": true,
    "enterpriseMatrixEnabled": true,
    "cloudConnectorProfiles": ["aws","azure","m365"],
    "playbookFoundationEnabled": true,
    "identityEnrichmentEnabled": false,
    "assetEnrichmentEnabled": false,
    "currentTheme": "dark"
  }

  ,
  "phase10": {
    "portProfile": "${PORT_PROFILE_DEFAULT}",
    "enterprisePorts": {
      "udp": ${UDP_PORT},
      "tcp": ${TCP_PORT},
      "tls": ${TLS_SYSLOG_PORT},
      "http": ${PUBLIC_HTTP_PORT},
      "https": ${PUBLIC_HTTPS_PORT},
      "appHttp": ${APP_HTTP_PORT}
    },
    "cveIntelEnabled": true,
    "cveLinkMode": "official",
    "cveSources": ["cve.org", "nvd"]
  }

,
  "phase11": {
    "ocsfEnabled": true,
    "sigmaEnabled": true,
    "entityRiskEnabled": true,
    "cloudCollectors": { "aws": false, "azure": false, "m365": false },
    "enrichment": { "identity": false, "asset": false, "cveLinks": true },
    "responseActionsSimulation": true,
    "storagePolicy": { "immutable": false, "tiering": "hot" }
  }
}
JSON

echo "[7/14] Installing Node dependencies..."
cd "$APP_DIR"

# ── Pre-npm: ensure build tools exist for native modules (better-sqlite3) ──
if ! command -v make >/dev/null 2>&1; then
  log_info "make not found — installing build tools (needed by better-sqlite3)..."
  if [[ "${OS_FAMILY}" == "debian" ]]; then
    # Try cache-only first (no network), then network
    apt-get install -y --no-download build-essential make g++ python3 2>/dev/null ||
    apt-get install -y build-essential make g++ python3 2>/dev/null || true
  elif [[ "${OS_FAMILY}" == "rhel" ]]; then
    if command -v dnf >/dev/null 2>&1; then dnf -y install make gcc gcc-c++ python3 2>/dev/null || true
    else yum -y install make gcc gcc-c++ python3 2>/dev/null || true; fi
  fi
fi

# ── Try to use prebuilt better-sqlite3 binary to skip compilation ──────────
BSQ_MOD="$APP_DIR/node_modules/better-sqlite3"
BSQ_VER=""
if [[ -f "$APP_DIR/node_modules/better-sqlite3/package.json" ]]; then
  BSQ_VER="$(node -e "try{console.log(require('./node_modules/better-sqlite3/package.json').version)}catch(e){}" 2>/dev/null || true)"
fi

# Fix permissions on any existing .bin entries
find "$APP_DIR/node_modules/.bin" -type f -exec chmod +x {} \; 2>/dev/null || true

if ! npm install --omit=dev; then
  if [[ "${OS_FAMILY}" == "debian" ]]; then
    log_warn "npm install failed. Attempting one-time install of native build prerequisites for Node modules."
    apt_get_safe install -y build-essential make g++ python3 2>/dev/null || {
      log_warn "Could not install build tools (network may be offline). Trying apt-cache..."
      apt-get install -y --no-download build-essential make g++ python3 2>/dev/null || true
    }
    npm install --omit=dev
  elif [[ "${OS_FAMILY}" == "rhel" ]]; then
    if command -v dnf >/dev/null 2>&1; then PM=dnf; else PM=yum; fi
    $PM -y install gcc gcc-c++ make python3
    npm install --omit=dev || {
      log_warn "npm install failed after installing build tools."
      log_warn "The SIEM will start but better-sqlite3 may not work."
      log_warn ""
      log_warn ">>> MANUAL FIX (run these commands):"
      log_warn "    apt-get install -y build-essential make g++"
      log_warn "    cd /opt/siem-syslog && npm install --omit=dev"
      log_warn "    systemctl restart siem-syslog"
      log_warn ""
    }
  else
    log_warn "npm install failed. Install build-essential manually and run: cd /opt/siem-syslog && npm install"
  fi
fi

# Fix executable permissions on all npm .bin entries (prevents Permission denied)
find "$APP_DIR/node_modules/.bin" -type f -exec chmod +x {} \; 2>/dev/null || true
find "$APP_DIR/node_modules" -name "prebuild-install" -exec chmod +x {} \; 2>/dev/null || true

echo "[8/14] Running schema migration helper..."
python3 "$APP_DIR/scripts/schema-migrate.py" "$CONFIG_FILE" || true

echo "[9/14] Applying permissions..."
chown -R root:root "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} \;
find "$APP_DIR" -type f -exec chmod 644 {} \;
chmod 755 "$APP_DIR/server-v3.js" "$APP_DIR/wipe-data.sh" "$APP_DIR/siem-test" \
  "$APP_DIR/scripts/schema-migrate.py" "$APP_DIR/scripts/generate-third-party-notices.py" \
  "$APP_DIR/scripts/generate-compliance-artifacts.py" "$APP_DIR/scripts/check-license-policy.py" \
  "$APP_DIR/scripts/run-post-install-validation.sh" "$APP_DIR/scripts/build-sea-binary.sh" \
  "$APP_DIR/scripts/release-gate.sh" \
  "$APP_DIR/tests/test-all-regress.sh" "$APP_DIR/tests/test-smoke.sh" \
  "$APP_DIR/tests/test-destructive.sh" "$APP_DIR/tests/test-ui-e2e.sh" \
  "$APP_DIR/tests/test-allv14.sh" "$APP_DIR/tests/test-all.sh" \
  "$APP_DIR/tests/test-quick.sh" "$APP_DIR/tests/test-allv13v3.sh" \
  "$APP_DIR/tests/test-worm-tamper.sh" "$APP_DIR/tests/test-golden-corpus.sh" \
  "$APP_DIR/tests/test-upgrade.sh" "$APP_DIR/tests/test-nav-panels.sh" 2>/dev/null || true
chmod 755 "$SNAPSHOT_HELPER" "$BACKUP_HELPER" "$RESTORE_HELPER" "$BACKUP_CRON_HELPER" "$REPORT_CRON_HELPER" "$REPORT_RUN_HELPER" /usr/local/share/siem-syslog-agent.sh 2>/dev/null || true
chown -R "$APP_USER:$APP_GROUP" "$LOG_DIR" "$DATA_DIR"
chown root:"$APP_GROUP" "$CONFIG_FILE"
chmod 660 "$CONFIG_FILE"

echo "[11/14] Creating systemd service..."
cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=SIEM Syslog Server v${RELEASE_VERSION}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${APP_DIR}
Environment=NODE_ENV=production
Environment=SIEM_CONFIG=${CONFIG_FILE}
Environment=PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/sbin
ExecStartPre=-/usr/bin/python3 ${APP_DIR}/scripts/schema-migrate.py ${CONFIG_FILE}
ExecStart=/usr/bin/env node ${APP_DIR}/server-v3.js
Restart=always
RestartSec=3
AmbientCapabilities=CAP_NET_BIND_SERVICE CAP_SETUID CAP_SETGID
CapabilityBoundingSet=CAP_NET_BIND_SERVICE CAP_SETUID CAP_SETGID
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
SERVICE

echo "[12/14] Generating self-signed certificate..."
IP_ADDR="$(hostname -I 2>/dev/null | awk '{print $1}' || hostname -i 2>/dev/null | awk '{print $1}' || echo 127.0.0.1)"
SSL_KEY="$SSL_DIR/selfsigned.key"
SSL_CERT="$SSL_DIR/selfsigned.crt"
SAN_FILE="$SSL_DIR/openssl-san.cnf"
SHORT_HOST="$(hostname -s 2>/dev/null || hostname)"
# Collect ALL interface IPs for the SAN
mapfile -t ALL_IPS < <(ip -4 addr show 2>/dev/null | grep -oP '(?<=inet )[0-9.]+' 2>/dev/null | sort -u || true)
# Build IP SAN entries
IP_SAN_LINES="IP.1=127.0.0.1"$'\n'"IP.2=${IP_ADDR}"
_ip_idx=3
for _ip in "${ALL_IPS[@]}"; do
  [[ "$_ip" == "127.0.0.1" || "$_ip" == "$IP_ADDR" ]] && continue
  IP_SAN_LINES+=$'\n'"IP.${_ip_idx}=${_ip}"
  (( _ip_idx++ ))
done

cat > "$SAN_FILE" <<SAN
[req]
distinguished_name=req_distinguished_name
x509_extensions=v3_req
prompt=no

[req_distinguished_name]
CN=${CERT_CN}

[v3_req]
subjectAltName=@alt_names
extendedKeyUsage=serverAuth

[alt_names]
DNS.1=localhost
DNS.2=${CERT_CN}
DNS.3=${SHORT_HOST}
${IP_SAN_LINES}
SAN
openssl req -x509 -nodes -newkey rsa:2048 -days "$CERT_DAYS" -keyout "$SSL_KEY" -out "$SSL_CERT" -config "$SAN_FILE" >/dev/null 2>&1
chmod 640 "$SSL_KEY" "$SSL_CERT"; chown root:"$APP_GROUP" "$SSL_KEY" "$SSL_CERT"; chown root:"$APP_GROUP" "$SSL_DIR"; chmod 750 "$SSL_DIR"

echo "[12/14] Configuring nginx reverse proxy on ${PUBLIC_HTTP_PORT}/${PUBLIC_HTTPS_PORT}..."
if [[ "${OS_FAMILY}" == "rhel" ]]; then
  NGINX_SITE="${NGINX_SITE_RHEL}"
  NGINX_ENABLED="${NGINX_SITE_RHEL}"
  # Strip default server{} block from nginx.conf to avoid duplicate default_server errors
  local main_conf="/etc/nginx/nginx.conf"
  if [[ -f "$main_conf" ]]; then
    [[ ! -f "${main_conf}.siem-orig" ]] && cp "$main_conf" "${main_conf}.siem-orig"
    python3 - "$main_conf" <<'PYSTRIP'
import re, sys
path = sys.argv[1]
text = open(path).read()
def strip_server_blocks(t):
    result = []; i = 0
    while i < len(t):
        m = re.search(r'(?:^|
)[ 	]*server[ 	]*\{', t[i:])
        if not m: result.append(t[i:]); break
        result.append(t[i:i+m.start()])
        start = i + m.start(); depth = 0; j = start
        while j < len(t):
            if t[j] == '{': depth += 1
            elif t[j] == '}':
                depth -= 1
                if depth == 0: j += 1; break
            j += 1
        while j < len(t) and t[j] in ('
', '
'): j += 1
        i = j
    return ''.join(result)
open(path, 'w').write(strip_server_blocks(text))
print('Stripped inline server{} from ' + path)
PYSTRIP
  fi
  for f in /etc/nginx/conf.d/default.conf /etc/nginx/conf.d/ssl.conf             /etc/nginx/conf.d/virtual.conf; do
    [[ -f "$f" ]] && mv "$f" "${f}.siem-disabled" && log_info "Disabled: $f" || true
  done
else
  NGINX_SITE="${NGINX_SITE_DEB}"
  NGINX_ENABLED="/etc/nginx/sites-enabled/${SERVICE_NAME}.conf"
  mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled
fi
if [[ "$PUBLIC_HTTPS_PORT" == "443" ]]; then
  HTTPS_REDIRECT='https://$host$request_uri'
else
  HTTPS_REDIRECT='https://$host:__PUBLIC_HTTPS_PORT__$request_uri'
fi
cat > "$NGINX_SITE" <<'NGINX'
map $http_upgrade $connection_upgrade {
    default upgrade;
    '' close;
}
server {
    listen __PUBLIC_HTTP_PORT__ default_server;
    listen [::]:__PUBLIC_HTTP_PORT__ default_server;
    server_name _;
    return 301 __HTTPS_REDIRECT__;
}
server {
    listen __PUBLIC_HTTPS_PORT__ ssl http2 default_server;
    listen [::]:__PUBLIC_HTTPS_PORT__ ssl http2 default_server;
    server_name _;

    ssl_certificate __SSL_CERT__;
    ssl_certificate_key __SSL_KEY__;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    client_max_body_size 10m;

    location / {
        proxy_pass http://127.0.0.1:__APP_HTTP_PORT__;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
        proxy_read_timeout 3600;
    }
}
NGINX
sed -i \
  -e "s|__PUBLIC_HTTP_PORT__|${PUBLIC_HTTP_PORT}|g" \
  -e "s|__PUBLIC_HTTPS_PORT__|${PUBLIC_HTTPS_PORT}|g" \
  -e "s|__APP_HTTP_PORT__|${APP_HTTP_PORT}|g" \
  -e "s|__SSL_CERT__|${SSL_CERT}|g" \
  -e "s|__SSL_KEY__|${SSL_KEY}|g" \
  -e "s|__HTTPS_REDIRECT__|${HTTPS_REDIRECT}|g" \
  "$NGINX_SITE"
if [[ "${OS_FAMILY}" == "debian" ]]; then
  rm -f /etc/nginx/sites-enabled/default
  rm -f "$NGINX_ENABLED" 2>/dev/null || true
  ln -sf "$NGINX_SITE" "$NGINX_ENABLED" || true
fi  # RHEL: conf.d files are used directly — no symlink needed
if ! nginx -t 2>&1; then
  log_err "nginx config test FAILED:"
  nginx -T 2>&1 | head -40 || true
  exit 1
fi
systemctl enable nginx 2>/dev/null || true
systemctl stop nginx 2>/dev/null || true
sleep 1
systemctl start nginx
systemctl is-active --quiet nginx || { log_err "nginx failed to start"; journalctl -u nginx -n 20 --no-pager || true; exit 1; }
log_info "nginx started OK"

echo "[14/14] Installing restart helper and sudoers..."
echo "Phase 7.1 enterprise track: refreshing helper permissions for restart, backup, restore, scheduling, and preserving refresh-safe data behavior."
cat > "$RESTART_HELPER" <<HELPER
#!/usr/bin/env bash
set -euo pipefail
SERVICE_NAME="${SERVICE_NAME}"
( sleep 1; /bin/systemctl restart "$SERVICE_NAME" ) >/dev/null 2>&1 &
HELPER
chmod 755 "$RESTART_HELPER"
cat > "$SUDOERS_FILE" <<SUDOERS
Defaults:${APP_USER} !requiretty
${APP_USER} ALL=(root) NOPASSWD: ${RESTART_HELPER}, ${BACKUP_HELPER}, ${RESTORE_HELPER}, ${BACKUP_CRON_HELPER}, ${REPORT_CRON_HELPER}, ${REPORT_RUN_HELPER}
SUDOERS
chmod 440 "$SUDOERS_FILE"
if command -v visudo >/dev/null 2>&1; then
  visudo -cf "$SUDOERS_FILE" >/dev/null || { echo "Invalid sudoers file: $SUDOERS_FILE"; exit 1; }
fi
python3 - "$REPORT_ENV_FILE" "$ADMIN_USERNAME" "$ADMIN_PASSWORD" <<'PY'
import sys
from pathlib import Path
out = Path(sys.argv[1])
user = sys.argv[2]
pw = sys.argv[3]
out.write_text(f"BASE_URL=https://127.0.0.1\nADMIN_USER={user!r}\nADMIN_PASS={pw!r}\n")
PY
chmod 600 "$REPORT_ENV_FILE"

export SIEM_CONFIG="$CONFIG_FILE"
log_info "Writing admin account '${ADMIN_USERNAME}' to ${CONFIG_FILE}"
if node "$APP_DIR/add-admin.js" --reset "$ADMIN_USERNAME" "$ADMIN_PASSWORD" 2>&1; then
  log_info "Admin account set via --reset"
elif node "$APP_DIR/add-admin.js" "$ADMIN_USERNAME" "$ADMIN_PASSWORD" 2>&1; then
  log_info "Admin account set via positional args"
else
  log_warn "add-admin.js failed — verifying config"
  python3 -c "
import json,sys
cfg=json.load(open('${CONFIG_FILE}'))
u=[x for x in cfg.get('auth',{}).get('users',[]) if x.get('username')=='${ADMIN_USERNAME}']
print('User in config:',bool(u))
sys.exit(0 if u else 1)
" && log_info "Admin user '${ADMIN_USERNAME}' confirmed in config" || log_err "Admin user missing — run: sudo SIEM_CONFIG=${CONFIG_FILE} node ${APP_DIR}/add-admin.js --reset ${ADMIN_USERNAME} NEWPASSWORD"
fi

echo "[15/18] Applying Phase 3.1 schedules..."
if [[ "${BACKUP_SCHEDULE_ENABLED}" == "true" ]]; then
  "$BACKUP_CRON_HELPER" "$BACKUP_DIR_DEFAULT" "$BACKUP_CRON_EXPR" enable
else
  "$BACKUP_CRON_HELPER" "$BACKUP_DIR_DEFAULT" "$BACKUP_CRON_EXPR" disable
fi
if [[ "${REPORT_SCHEDULE_ENABLED}" == "true" ]]; then
  "$REPORT_CRON_HELPER" "$REPORT_OUTPUT_DEFAULT" "$REPORT_CRON_EXPR" "$REPORT_COMPONENT_DEFAULT" enable
else
  "$REPORT_CRON_HELPER" "$REPORT_OUTPUT_DEFAULT" "$REPORT_CRON_EXPR" "$REPORT_COMPONENT_DEFAULT" disable
fi

echo "[16/18] Verifying bundled server syntax..."
node --check "$APP_DIR/server-v3.js"

echo "[17/18] Starting services..."
systemctl daemon-reload 2>/dev/null || true
systemctl enable "$SERVICE_NAME" 2>/dev/null || true
systemctl restart "$SERVICE_NAME"

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PUBLIC_HTTP_PORT}/tcp"   || true
  ufw allow "${PUBLIC_HTTPS_PORT}/tcp"  || true
  ufw allow "${APP_HTTP_PORT}/tcp"      || true
  ufw allow "${HTTPS_PORT:-8443}/tcp"   || true
  ufw allow "${UDP_PORT}/udp"           || true
  ufw allow "${TCP_PORT}/tcp"           || true
  ufw allow "${TLS_SYSLOG_PORT}/tcp"    || true
  log_info "ufw: ports opened"
elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld 2>/dev/null; then
  for port in "${PUBLIC_HTTP_PORT}/tcp" "${PUBLIC_HTTPS_PORT}/tcp" "${APP_HTTP_PORT}/tcp" "${HTTPS_PORT:-8443}/tcp" "${TCP_PORT}/tcp" "${TLS_SYSLOG_PORT}/tcp"; do
    firewall-cmd --permanent --add-port="${port}" 2>/dev/null || true
  done
  firewall-cmd --permanent --add-port="${UDP_PORT}/udp" 2>/dev/null || true
  [[ "${PUBLIC_HTTP_PORT}"  == "80"  ]] && firewall-cmd --permanent --add-service=http  2>/dev/null || true
  [[ "${PUBLIC_HTTPS_PORT}" == "443" ]] && firewall-cmd --permanent --add-service=https 2>/dev/null || true
  firewall-cmd --reload 2>/dev/null || true
  log_info "firewalld: ports opened"
fi




# ── Port 514 iptables redirect (per-interface) ─────────────────────────────────
# If the configured ports are NOT 514/601, set up iptables to redirect
# standard syslog port 514 → our actual listener port.
# This lets clients send to the standard port without root binding.
setup_514_redirect() {
  local iface="${1:-}"   # empty = all interfaces
  local udp_target="$UDP_PORT"
  local tcp_target="$TCP_PORT"
  local iface_flag=""
  [[ -n "$iface" ]] && iface_flag="-i $iface"

  # UDP 514 → UDP_PORT
  iptables -t nat -D PREROUTING $iface_flag -p udp --dport 514 -j REDIRECT --to-port "$udp_target" 2>/dev/null || true
  iptables -t nat -A PREROUTING $iface_flag -p udp --dport 514 -j REDIRECT --to-port "$udp_target"
  # TCP 514 → TCP_PORT
  iptables -t nat -D PREROUTING $iface_flag -p tcp --dport 514 -j REDIRECT --to-port "$tcp_target" 2>/dev/null || true
  iptables -t nat -A PREROUTING $iface_flag -p tcp --dport 514 -j REDIRECT --to-port "$tcp_target"
  # TCP 601 (reliable syslog) → TCP_PORT
  iptables -t nat -D PREROUTING $iface_flag -p tcp --dport 601 -j REDIRECT --to-port "$tcp_target" 2>/dev/null || true
  iptables -t nat -A PREROUTING $iface_flag -p tcp --dport 601 -j REDIRECT --to-port "$tcp_target"

  # Also open firewall for 514/601 if firewall is active
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow 514/udp >/dev/null 2>&1 || true
    ufw allow 514/tcp >/dev/null 2>&1 || true
    ufw allow 601/tcp >/dev/null 2>&1 || true
  elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld 2>/dev/null; then
    firewall-cmd --permanent --add-port=514/udp >/dev/null 2>&1 || true
    firewall-cmd --permanent --add-port=514/tcp >/dev/null 2>&1 || true
    firewall-cmd --permanent --add-port=601/tcp >/dev/null 2>&1 || true
    firewall-cmd --reload >/dev/null 2>&1 || true
  fi

  # Make persistent (survives reboot)
  if command -v iptables-save >/dev/null 2>&1; then
    mkdir -p /etc/iptables
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
    # RHEL: use iptables-services if available
    if command -v service >/dev/null 2>&1 && service iptables status >/dev/null 2>&1; then
      service iptables save 2>/dev/null || true
    fi
  fi
  local iface_label="${iface:-all interfaces}"
  echo "  [OK] Port 514 redirect: 514→${udp_target}(UDP) 514/601→${tcp_target}(TCP) on ${iface_label}"
}

# Port 514 redirect setup
if [[ "$UDP_PORT" != "514" || "$TCP_PORT" != "514" ]]; then
  if [[ -t 0 ]]; then
    echo ""
    echo "Port 514 (standard syslog) redirect:"
    mapfile -t _IFACES514 < <(ip link show 2>/dev/null | awk -F': ' '/^[0-9]+:/{print $2}' 2>/dev/null | grep -v '^lo' 2>/dev/null | tr -d ' @.*' 2>/dev/null | head -8 || true)
    if [[ ${#_IFACES514[@]} -le 1 ]]; then
      echo "  Applying port 514 redirect on all interfaces..."
      setup_514_redirect "" || true
    else
      echo "  Network interfaces:"
      for i in "${!_IFACES514[@]}"; do
        _ip514="$(ip -4 addr show "${_IFACES514[$i]}" 2>/dev/null | grep -oP '(?<=inet )[0-9.]+' 2>/dev/null | head -1 || true)"
        printf "    [%d] %s %s
" "$((i+1))" "${_IFACES514[$i]}" "${_ip514:+(${_ip514})}"
      done
      echo "    [A] All interfaces"
      read -e -r -p "  Port 514 on which interface? [A/1/2/...]: " _514_CHOICE
      _514_CHOICE="${_514_CHOICE:-A}"
      if [[ "${_514_CHOICE^^}" == "A" || -z "$_514_CHOICE" ]]; then
        setup_514_redirect ""
      else
        _514_IDX=$(( _514_CHOICE - 1 ))
        _514_IFACE="${_IFACES514[$_514_IDX]:-}"
        if [[ -n "$_514_IFACE" ]]; then
          setup_514_redirect "$_514_IFACE"
          _514_IP="$(ip -4 addr show "$_514_IFACE" 2>/dev/null | grep -oP '(?<=inet )[0-9.]+' 2>/dev/null | head -1 || true)"
          [[ -n "$_514_IP" ]] && UDP_BIND_ADDR="$_514_IP" && TCP_BIND_ADDR="$_514_IP"
        else
          setup_514_redirect ""
        fi
      fi
    fi
  else
    # Non-interactive: apply to all interfaces automatically
    setup_514_redirect "" || true
  fi
fi

if command -v setsebool >/dev/null 2>&1 && command -v getenforce >/dev/null 2>&1; then
  if getenforce 2>/dev/null | grep -qi "Enforcing"; then
    log_info "SELinux enforcing — applying policies"
    setsebool -P httpd_can_network_connect 1 2>/dev/null || true
    if command -v semanage >/dev/null 2>&1; then
      semanage port -a -t http_port_t      -p tcp "${APP_HTTP_PORT}"    2>/dev/null || semanage port -m -t http_port_t      -p tcp "${APP_HTTP_PORT}"    2>/dev/null || true
      semanage port -a -t http_port_t      -p tcp "${HTTPS_PORT:-8443}" 2>/dev/null || semanage port -m -t http_port_t      -p tcp "${HTTPS_PORT:-8443}" 2>/dev/null || true
      semanage port -a -t syslogd_port_t   -p udp "${UDP_PORT}"         2>/dev/null || semanage port -m -t syslogd_port_t   -p udp "${UDP_PORT}"         2>/dev/null || true
      semanage port -a -t syslogd_port_t   -p tcp "${TCP_PORT}"         2>/dev/null || semanage port -m -t syslogd_port_t   -p tcp "${TCP_PORT}"         2>/dev/null || true
      semanage port -a -t syslogd_port_t   -p tcp "${TLS_SYSLOG_PORT}"  2>/dev/null || semanage port -m -t syslogd_port_t   -p tcp "${TLS_SYSLOG_PORT}"  2>/dev/null || true
    else
      log_warn "semanage not available — install policycoreutils-python-utils for full SELinux port labeling"
    fi
  fi
fi

echo "[18/18] Verifying service health and listeners..."

# Wait up to 20 seconds for service to become healthy and ports to open
_WAIT_MAX=20
_waited=0
_http_up=false
while [[ $_waited -lt $_WAIT_MAX ]]; do
  sleep 2; _waited=$(( _waited + 2 ))
  if systemctl is-active --quiet "$SERVICE_NAME"; then
    # Check HTTP port is actually accepting connections
    if curl -sk --max-time 3 "http://127.0.0.1:${APP_HTTP_PORT}/api/health" >/dev/null 2>&1; then
      _http_up=true
      echo "  [ok] Service healthy — HTTP responding on :${APP_HTTP_PORT} (after ${_waited}s)"
      break
    fi
    echo "  [wait] Service running, waiting for HTTP port :${APP_HTTP_PORT} (${_waited}s)..."
  else
    echo "  [wait] Waiting for service to start (${_waited}s)..."
  fi
done

if ! systemctl is-active --quiet "$SERVICE_NAME"; then

  log_err "${SERVICE_NAME} failed to start. Recent journal output:"
  journalctl -u "$SERVICE_NAME" -n 80 --no-pager || true
  echo ""
  echo "  Troubleshoot with: sudo journalctl -u ${SERVICE_NAME} -f"
  exit 1
fi
if ! systemctl is-active --quiet nginx; then
  log_err "nginx failed to start. Recent journal output:"
  journalctl -u nginx -n 80 --no-pager || true
  exit 1
fi
require_listener() {
  local proto="$1" port="$2" label="$3"
  if [[ "$proto" == "udp" ]]; then
    ss -lunH "sport = :${port}" 2>/dev/null | grep -Eq ":[0-9A-Fa-f.:]*${port}([[:space:]]|$)" || { log_err "Missing ${label} listener on UDP ${port}"; return 1; }
  else
    ss -ltnH "sport = :${port}" 2>/dev/null | grep -Eq ":[0-9A-Fa-f.:]*${port}([[:space:]]|$)" || { log_err "Missing ${label} listener on TCP ${port}"; return 1; }
  fi
}
require_listener udp "$UDP_PORT" "syslog UDP"
require_listener tcp "$TCP_PORT" "syslog TCP"
require_listener tcp "$TLS_SYSLOG_PORT" "syslog TLS"
require_listener tcp "$APP_HTTP_PORT" "backend HTTP"
require_listener tcp "$PUBLIC_HTTP_PORT" "public HTTP"
require_listener tcp "$PUBLIC_HTTPS_PORT" "public HTTPS"

systemctl --no-pager --full status "$SERVICE_NAME" || true
echo
systemctl --no-pager --full status nginx || true

echo
echo "Installed successfully. siem-v${RELEASE_VERSION} bundle is ready."
echo

# ── Check nginx and print HTTPS status ────────────────────────────────────────
echo ""
if systemctl is-active --quiet nginx 2>/dev/null; then
  echo "  nginx:  ✅ RUNNING — HTTPS port 443 is active"
  echo "  ➜  https://${IP_ADDR}          (via nginx, self-signed cert)"
  echo "  ➜  https://${IP_ADDR}:443      (same)"
  echo ""
  echo "  Browser warning 'Not Secure' or 'Your connection is not private'?"
  echo "  Click Advanced → Proceed to ${IP_ADDR} (unsafe)  — this is normal for self-signed certs."
  echo "  For a trusted cert: sudo certbot --nginx -d your-domain.com"
else
  echo "  nginx:  ⬜ NOT RUNNING"
  echo "  Start nginx for HTTPS on 443:"
  echo "    sudo systemctl start nginx && sudo systemctl enable nginx"
fi
echo ""
echo "════════════════════════════════════════════════════════"
echo "  OPEN THIS URL IN YOUR BROWSER:"
echo ""
if [[ "${HTTPS_ENABLED:-true}" == "true" ]]; then
  echo "  -> https://${IP_ADDR}:${HTTPS_PORT:-8443}   (HTTPS - recommended)"
  if [[ "${HTTPS_PORT:-8443}" == "443" ]]; then
    echo "  -> https://${IP_ADDR}   (no port needed when on 443)"
  fi
fi
echo "  -> http://${IP_ADDR}:${APP_HTTP_PORT}   (HTTP - always works)"
echo ""
if systemctl is-active --quiet nginx 2>/dev/null; then
  echo "  -> https://${IP_ADDR}   (nginx proxy on 443 - active)"
fi
echo ""
if [[ "${HTTPS_ENABLED:-true}" == "true" ]]; then
  echo "  Browser shows a certificate warning? That is normal for self-signed certs."
  echo "  Chrome:  click Advanced then Proceed to ${IP_ADDR}"
  echo "  Firefox: click Accept the Risk and Continue"
fi
echo "════════════════════════════════════════════════════════"
echo ""
echo "Demo mode:       ${DEMO_MODE}"
echo
echo "Useful commands:"
echo "  siem-test                               # interactive test menu"
echo "  siem-test smoke                         # quick 5-check health test"
echo "  siem-test full                          # all 113 regression sections"
echo "  sudo systemctl status ${SERVICE_NAME}"
echo "  sudo journalctl -u ${SERVICE_NAME} -f"
echo "  sudo systemctl status nginx"
echo
echo "Port status at startup:"
for _chk_port in "${APP_HTTP_PORT}" "${HTTPS_PORT:-8443}" "${UDP_PORT}" "${TCP_PORT}" "${TLS_SYSLOG_PORT}"; do
  [[ -z "$_chk_port" ]] && continue
  _status="$(ss -ltnpH "sport = :${_chk_port}" 2>/dev/null | head -1)"
  _udp_status="$(ss -lunpH "sport = :${_chk_port}" 2>/dev/null | head -1)"
  if [[ -n "$_status" || -n "$_udp_status" ]]; then
    echo "  OPEN   :${_chk_port}"
  else
    echo "  CLOSED :${_chk_port}  (may still be starting)"
  fi
done
echo
echo ""
echo "Quick test — run this to verify the dashboard is reachable:"
echo "  curl -sk https://127.0.0.1:${HTTPS_PORT:-8443}/api/health | python3 -m json.tool"
echo "  curl -s  http://127.0.0.1:${APP_HTTP_PORT}/api/health      | python3 -m json.tool"
echo ""
echo "Admin username:   ${ADMIN_USERNAME}"
echo "Admin password:   ${ADMIN_PASSWORD}"
echo "Agent shared key: ${AGENT_SHARED_KEY}"
echo "Snapshot export:  sudo ${SNAPSHOT_HELPER} ${DATA_DIR}/archive"
echo "Wipe runtime:     sudo ${APP_DIR}/wipe-data.sh runtime"
echo "Phase 3.1 helpers:"
echo "  sudo siem-syslog-backup-node ${BACKUP_DIR_DEFAULT}"
echo "  sudo siem-syslog-restore-node /path/to/backup.tar.gz"
echo "  sudo siem-syslog-install-backup-cron ${BACKUP_DIR_DEFAULT} '${BACKUP_CRON_EXPR}'"
echo "  sudo siem-syslog-install-report-cron ${REPORT_OUTPUT_DEFAULT} '${REPORT_CRON_EXPR}' ${REPORT_COMPONENT_DEFAULT}"
echo "  sudo siem-syslog-run-report ${REPORT_OUTPUT_DEFAULT} ${REPORT_COMPONENT_DEFAULT}"
echo "Compliance artifacts: ${COMPLIANCE_DIR}"
echo "Validation logs:     ${VALIDATION_LOG_DIR}"
echo "  sudo ${APP_DIR}/scripts/run-post-install-validation.sh"
echo "  sudo ${APP_DIR}/scripts/build-sea-binary.sh"
if [[ "$GENERATED_ADMIN_PASSWORD" == "true" ]]; then
  echo "Password was generated for this install. Save it now."
fi

if [[ "$RUN_POST_INSTALL_VALIDATION" == "true" ]]; then
  echo "[post] Running full post-install validation..."
  if ! ADMIN_USER="$ADMIN_USERNAME" ADMIN_PASS="$ADMIN_PASSWORD" VALIDATION_DIR="$VALIDATION_LOG_DIR" STRICT="$VALIDATION_STRICT" "$APP_DIR/scripts/run-post-install-validation.sh"; then
    if [[ "$VALIDATION_STRICT" == "true" ]]; then
      log_err "Post-install validation failed in strict mode."
      exit 1
    fi
    log_warn "Post-install validation reported failures. Review logs in $VALIDATION_LOG_DIR"
  fi
fi


echo "[route-check] Seed default asset/identity..."
seed_default_asset_identity

echo "[route-check] Phase 8 route checks..."
if grep -q "/api/admin/phase8/settings" "$APP_DIR/server-v3.js" && grep -q "/api/admin/theme-settings" "$APP_DIR/server-v3.js" && grep -q "/api/admin/enterprise-matrix" "$APP_DIR/server-v3.js"; then
  echo "Phase 8 routes present."
else
  echo "ERROR: Phase 8 routes missing after install."
  exit 1
fi

echo "[route-check] Phase 9 route checks..."
if grep -q "/api/admin/phase9/settings" "$APP_DIR/server-v3.js" && grep -q "/api/admin/cloud-connectors" "$APP_DIR/server-v3.js" && grep -q "/api/admin/playbooks/test" "$APP_DIR/server-v3.js"; then
  echo "Phase 9 routes present."
else
  echo "ERROR: Phase 9 routes missing after install."
  exit 1
fi




echo "[route-check] Phase 10 route checks..."
if grep -q "/api/admin/phase10/settings" "$APP_DIR/server-v3.js" &&        grep -q "/api/admin/port-profile/check" "$APP_DIR/server-v3.js" &&        grep -q "/api/admin/cve/lookup" "$APP_DIR/server-v3.js"; then
  echo "Phase 10 routes present."
else
  echo "ERROR: Phase 10 routes missing after install."
  exit 1
fi


echo "[route-check] Phase 11 route checks..."
if grep -q "/api/admin/v11/settings" "$APP_DIR/lib/v11-extensions.js" && grep -q "/api/admin/ocsf/map-sample" "$APP_DIR/lib/v11-extensions.js" && grep -q "/api/admin/sigma/validate" "$APP_DIR/lib/v11-extensions.js" && grep -q "/api/admin/entity-risk/summary" "$APP_DIR/lib/v11-extensions.js"; then
  echo "Phase 11 routes present."
else
  echo "ERROR: Phase 11 routes missing after install."
  exit 1
fi
echo "[route-check] Phase 12 route checks..."
if grep -q "/api/admin/v12/settings" "$APP_DIR/server-v3.js" && grep -q "/api/admin/data-observability/settings" "$APP_DIR/server-v3.js" && grep -q "/api/admin/genai/ask" "$APP_DIR/server-v3.js"; then
  echo "Phase 12 routes present."
else
  echo "ERROR: Phase 12 routes missing after install."
  exit 1
fi
